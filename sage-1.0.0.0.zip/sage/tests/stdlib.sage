import math
import json
import csv
import re
import os
from collections import Stack, Counter
say math.sqrt(16), math.floor(2.7), math.pi > 3.14
say json.stringify({"a": [1, 2, nothing], "t": "hi\n"})
say json.parse("{\"x\": [1, 2.5, true, null, \"u\\u00e9\"]}")
say json.stringify([1, {"k": (2, 3)}], 2)
say csv.parse("a,b\n1,\"x,y\"\n")
say csv.dicts(csv.parse("n,v\nx,1\ny,2\n"))
say re.test("^[a-z]+[0-9]$", "abc1"), re.find_all("\\d+", "a1 b22 c333")
say re.replace("(\\w+)@(\\w+)", "bob@home x@y", "\\2:\\1"), re.split("[, ]+", "a, b  c,d")
say os.join("a", "b"), os.basename("/x/y.sage"), os.exists("/definitely/not/here")
let s = Stack()
s.push(1)
s.push(2)
say s.pop(), len(s)
say Counter("banana").most_common(2)
try:
    json.parse("{bad")
catch ValueError as e:
    say "bad json caught"
try:
    import nosuchmodule
catch ImportError as e:
    say "no module caught"
say "héllo wörld".upper(), "ÀÉ ПРИВЕТ".lower(), "élan vital".title()
