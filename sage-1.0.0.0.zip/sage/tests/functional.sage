# functions, closures, lambdas, higher-order, comprehensions, pipes
define add(a, b = 10):
    return a + b
say add(1), add(1, 2)

define make_counter():
    let count = 0
    define bump():
        nonlocal count
        count += 1
        return count
    return bump
let c1 = make_counter()
let c2 = make_counter()
say c1(), c1(), c1(), c2()

let square = lambda x: x * x
say square(7)
say map([1, 2, 3], square), filter(range(10), lambda v: v % 3 == 0)
say reduce([1, 2, 3, 4], lambda a, b: a * b), reduce([], lambda a, b: a + b, 99)
say sorted([3, 1, 2]), sorted(["bb", "a", "ccc"], lambda w: -len(w)), reversed([1, 2, 3])
say [x * 2 for x in [1, 2, 3, 4] if x > 1]
say [a + b for a, b in [[1, 2], [3, 4]]]
say range(5) |> map(lambda v: v + 1) |> filter(lambda v: v > 2) |> sum()
say 16 |> sqrt
define compose(f, g):
    return lambda x: f(g(x))
say compose(lambda x: x + 1, lambda x: x * 2)(5)
say any([0, 0, 1]), all([1, 1, 0]), zip([1, 2], ["a", "b"]), enumerate(["x", "y"])
say min(3, 1, 2), max([4, 9, 2]), sum([1, 2, 3], 10), abs(-3), round(2.567, 2)

define fact(n):
    if n <= 1:
        return 1
    return n * fact(n - 1)
say fact(10)
define deep(n):
    if n == 0:
        return 0
    return 1 + deep(n - 1)
say deep(2000)
