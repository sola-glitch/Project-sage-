# the collector frees garbage but keeps everything that is still reachable
let keep = []
for i in range(20000):
    let junk = [i, "text " + str(i), {"k": [i]}]
    if i % 1000 == 0:
        keep.add(junk)
say len(keep), keep[3][1], keep[19][2]

class Node:
    define init(v, nxt):
        self.v = v
        self.nxt = nxt
let chain = nothing
for i in range(5000):
    chain = Node(i, chain)
let n = 0
let cur = chain
while cur is not nothing:
    n += 1
    cur = cur.nxt
say n, chain.v

define make_adders():
    return [lambda x: x + i for i in range(3)]
let adders = make_adders()
for i in range(3000):
    let waste = "x" * 50
say adders[0](10), adders[2](10)

let big = sorted([str(i * 7919 % 1000) for i in range(2000)], key = lambda s: len(s) * 10000 + num(s))
say big[0], big[-1], len(big)
let before = gc()
for i in range(50000):
    let t = [i, str(i)]
let after = gc()
say after - before < 20
