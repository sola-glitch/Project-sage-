# classes, inheritance, super, polymorphism, to_text
class Shape:
    define init(name):
        self.name = name
    define area():
        return 0
    define describe():
        return f"{self.name} with area {fixed(self.area(), 2)}"

class Circle extends Shape:
    define init(r):
        super.init("circle")
        self.r = r
    define area():
        return 3.14159265 * self.r ** 2

class Rect(Shape):
    define init(w, h):
        super.init("rect")
        self.w = w
        self.h = h
    define area():
        return self.w * self.h
    define to_text():
        return f"Rect({self.w}x{self.h})"

class Square(Rect):
    define init(s):
        super.init(s, s)
        self.name = "square"

let shapes = [Circle(1), Rect(2, 3), Square(4)]
for sh in shapes:
    say sh.describe()
say shapes[1], shapes[2]
say [s.area() for s in shapes |> filter(lambda s: s.area() > 5)]
say isinstance(shapes[2], Rect), isinstance(shapes[2], Shape), isinstance(shapes[0], Rect)
say type(shapes[0]), hasattr(shapes[0], "r"), hasattr(shapes[0], "zzz")

class Counter:
    define init():
        self.n = 0
    define bump():
        self.n += 1
        return self
let k = Counter()
k.bump().bump().bump()
say k.n
let m = k.bump
say m(), k.n

class Stack:
    define init():
        self.items = []
    define push(x):
        self.items.add(x)
    define pop():
        return self.items.pop()
let st = Stack()
st.push(1)
st.push(2)
say st.pop(), st.pop(), len(st.items)
