class MyErr(Error):
    pass
define risky(n):
    if n == 0:
        raise MyErr("zero!")
    if n == 1:
        return 1 / 0
    if n == 2:
        raise ValueError("bad value")
    return n
for i in range(4):
    try:
        say "got", risky(i)
    catch MyErr as e:
        say "mine:", e
    catch ZeroDivisionError, ValueError as e:
        say "math/value:", e
    finally:
        say "done", i
define f():
    try:
        return "from try"
    finally:
        say "cleanup"
say f()
try:
    try:
        raise Error("inner")
    finally:
        say "inner finally"
catch e:
    say "outer caught", e
class Res:
    define __enter__():
        say "enter"
        return self
    define __exit__(err):
        say "exit", err
        return true
with Res() as r:
    say "body"
    raise Error("swallowed")
say "after"
with open("/tmp/sage_test_o.txt", "w") as fh:
    fh.write("a\nb\n")
with open("/tmp/sage_test_o.txt") as fh:
    say fh.lines()
try:
    open("/nonexistent/x")
catch IOError as e:
    say "io:", e
define logged(fn):
    define wrapper(x):
        say "calling"
        return fn(x)
    return wrapper
@logged
define sq(x):
    return x * x
say sq(5)
class K:
    @logged
    define m(x):
        return x + 1
say K().m(1)
