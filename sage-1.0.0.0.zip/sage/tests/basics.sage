# numbers, text, control flow
say 1 + 2 * 3, 7 // 2, -7 // 2, 7 % 3, -7 % 3, 2 ** 10, 10 / 4
say "a" + "b", "ab" * 3, "n=" + 5
say 0.1 + 0.2, 1 / 3, 1e3, 100000000000000000000
say true and false, true or false, not true, nothing
say 1 is 1, 1 is not 2, 5 is greater than 3, 2 is at most 2, 3 is less than 1
say "x" in "xyz", 4 in [1, 2, 3], "k" in {"k": 1}, 9 not in [1, 2]
let n = 0
while n < 5:
    n += 1
    if n == 2:
        continue
    if n == 4:
        break
    say "n:", n
for i in range(3):
    say i
for i in range(10, 0, -4):
    say i
repeat 2 times:
    say "hi"
if n > 10:
    say "big"
else if n > 3:
    say "medium"
else:
    say "small"
say 5 if n > 1 else 6
let s = "hello"
say s[0], s[-1], s[1:3], s[:2], s[3:], len(s)
say f"{s.upper()} has {len(s)} letters, {{braces}}"
say """multi
line"""
