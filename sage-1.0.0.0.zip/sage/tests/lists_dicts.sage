# lists, dicts, strings
let xs = [5, 3, 8]
xs.add(1)
xs.push(9)
say xs, len(xs), xs.pop(), xs.pop(0), xs
xs.insert(1, 100)
xs.sort()
say xs, xs.index(100), xs.index(555), xs.contains(3), xs.count(3)
xs.reverse()
say xs, xs.first(), xs.last(), xs + [0], [0] * 3
xs[0] = 42
xs[-1] = 7
say xs, xs[1:], xs[:-1]
xs.remove(42)
say xs.join("-"), xs.copy(), [1, 2] == [1, 2], [1, 2] == [2, 1]

let d = {"a": 1, "b": 2}
d["c"] = 3
say d, len(d), d.get("a"), d.get("zz", "none"), d.has("b"), "b" in d
say keys(d), values(d), items(d)
d.remove("a")
for k, v in d.items():
    say k, "=", v
for k in d:
    say k
let nested = {"list": [1, {"x": nothing}], 5: "five", true: "yes"}
say nested, nested[5], nested[true]
say {1: 2} == {1: 2}

let t = "  Hello, World  "
say t.strip(), t.strip().lower(), t.strip().upper(), "a b  c".split()
say "a,b,c".split(","), "x".join(["1", 2, 3]), "banana".replace("an", "AN")
say "hello".starts_with("he"), "hello".ends_with("lo"), "hello".find("l"), "hello".find("z")
say "banana".count("an"), "hello world".title(), "hello".contains("ell")
say chr(65), ord("A"), chr(233), str(42) + "!", num("3.5") + 1, int(7.9), type([]), type({}), type("s"), type(1)
for ch in "héy":
    say ch
