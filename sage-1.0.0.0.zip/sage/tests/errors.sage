# error handling: try / catch / raise / assert
try:
    say 1 / 0
catch e:
    say "caught:", e

try:
    say undefined_thing
catch e:
    say "caught:", e

try:
    raise "custom failure"
catch e:
    say "caught:", e

try:
    say [1, 2][5]
catch e:
    say "caught:", e

try:
    say {"a": 1}["b"]
catch e:
    say "caught:", e

try:
    say "a" - 1
catch e:
    say "caught:", e

try:
    say num("abc")
catch e:
    say "caught:", e

define boom():
    raise "from inside"
define wrapper():
    try:
        boom()
    catch err:
        say "wrapper saw:", err
        raise "re-raised"
try:
    wrapper()
catch e:
    say "outer saw:", e

class AppError:
    define init(msg, code):
        self.msg = msg
        self.code = code
try:
    raise AppError("bad thing", 42)
catch e:
    say e.msg, e.code, isinstance(e, AppError)

try:
    assert 1 == 2, "math is broken"
catch e:
    say e

define loop_forever(n):
    return loop_forever(n + 1)
try:
    loop_forever(0)
catch e:
    say e

define early():
    for i in range(10):
        try:
            if i == 3:
                return i
        catch e:
            say "no"
    return -1
say early()

try:
    say add_nothing(1, 2)
catch e:
    say "caught:", e
define two(a, b):
    return a
try:
    two(1)
catch e:
    say "caught:", e
say "done"
