let t = (1, 2, 3)
say t, t[0], t[1:], len(t), t + (4,), (1,) * 3, ()
let a, b = 10, 20
say a, b
define mm(xs):
    return min(xs), max(xs)
let lo, hi = mm([3, 1, 2])
say lo, hi, mm([5, 9])
let s = {1, 2, 3, 2}
say s, len(s), 2 in s, 9 in s
say s | {5}, s & {2, 3, 4}, s - {1}
s.add(7)
s.discard(1)
say sorted(s), set([1, 1, 2]), set()
say {x * x for x in range(4)}
say {k: len(k) for k in ["a", "bb"]}
let d = {(1, 2): "pt"}
say d[(1, 2)], (1, 2) == (1, 2), {1, 2} == {2, 1}
for k, v in {"x": 1}.items():
    say k, v
for i, ch in enumerate("ab"):
    say i, ch
say tuple([1, 2]), list((3, 4)), type((1,)), type({1})
try:
    t[0] = 9
catch e:
    say "err:", e
