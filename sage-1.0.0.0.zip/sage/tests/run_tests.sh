#!/bin/sh
# Runs every tests/*.sage and compares stdout with the matching .out file.
cd "$(dirname "$0")/.." || exit 1
pass=0; fail=0
for f in tests/*.sage; do
    exp="${f%.sage}.out"
    if ./sage "$f" 2>&1 | cmp -s - "$exp"; then
        pass=$((pass+1))
    else
        fail=$((fail+1)); echo "FAIL: $f"
    fi
done
echo "$pass passed, $fail failed"
[ "$fail" -eq 0 ]
