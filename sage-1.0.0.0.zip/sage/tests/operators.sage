class Vec:
    define init(x, y):
        self.x = x
        self.y = y
    define __add__(o):
        return Vec(self.x + o.x, self.y + o.y)
    define __mul__(k):
        return Vec(self.x * k, self.y * k)
    define __rmul__(k):
        return Vec(self.x * k, self.y * k)
    define __eq__(o):
        return self.x == o.x and self.y == o.y
    define __lt__(o):
        return self.x < o.x
    define __neg__():
        return Vec(-self.x, -self.y)
    define __len__():
        return 2
    define __str__():
        return f"Vec({self.x}, {self.y})"
    define __getitem__(i):
        return [self.x, self.y][i]
    define __contains__(v):
        return v == self.x or v == self.y
    define __iter__():
        return [self.x, self.y]
    define __call__(a):
        return a + self.x
a = Vec(1, 2)
b = Vec(3, 4)
say a + b, a * 3, 3 * a, -a
say a == Vec(1, 2), a != b, a < b, a > b
say len(a), a[1], 2 in a, 9 not in a
for v in a:
    say v
say a(10)
let d = {a: "first"}
say d[a]
