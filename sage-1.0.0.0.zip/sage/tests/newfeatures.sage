# keyword arguments, *args / **kwargs, spreading, unpacking, scoping, unicode
define greet(name, greeting = "Hello", punctuation = "!"):
    return f"{greeting}, {name}{punctuation}"
say greet("Ada")
say greet("Ada", punctuation = "?")
say greet(greeting = "Hi", name = "Grace")
say greet("Linus", "Yo", "...")

define total(*numbers):
    return sum(numbers)
say total(), total(1), total(1, 2, 3)
let nums = [4, 5, 6]
say total(*nums), total(1, *nums, 10)

define describe(first, *rest, sep = ", ", **extras):
    let parts = [first] + rest
    say sep.join(parts), extras
describe("a", "b", "c")
describe("a", "b", sep = "|", color = "red", size = 3)
let opts = {"sep": "-", "flag": true}
describe("x", "y", **opts)

let double = lambda *xs: [x * 2 for x in xs]
say double(1, 2, 3)

class Pt:
    define init(x = 0, y = 0):
        self.x = x
        self.y = y
    define move(dx = 0, dy = 0):
        self.x += dx
        self.y += dy
        return self
    define to_text():
        return f"({self.x}, {self.y})"
say Pt(y = 5), Pt(1).move(dy = 2), Pt(3, 4).move(*[1, 1])
say sorted(["bb", "a", "ccc"], key = lambda w: -len(w))
let words = ["pear", "fig"]
words.sort(key = lambda w: len(w))
say words

try:
    greet()
catch e:
    say e
try:
    greet("x", nope = 1)
catch e:
    say e
try:
    greet("x", name = "y")
catch e:
    say e
try:
    total(sep = 1)
catch e:
    say e

# unpacking
let a, b = 1, 2
a, b = b, a
say a, b
let first, second, third = "xyz"
say first, second, third
let pair = [10, 20]
let lo, hi = pair
lo, hi = hi + 1, lo + 1
say lo, hi
let box = {"v": 0}
box["v"], a = 99, 7
say box, a
for k, v in {"p": 1}.items():
    say k, v
try:
    let p, q = [1, 2, 3]
catch e:
    say e

# scoping
let counter = 0
define bad():
    counter += 1
try:
    bad()
catch e:
    say e
define local_only():
    counter = 100
    return counter
say local_only(), counter
define bump_global():
    global counter
    counter += 5
bump_global()
say counter
define make():
    let n = 0
    define inc():
        nonlocal n
        n += 1
        return n
    return inc
let c = make()
say c(), c(), c()
define shadow():
    let counter = "mine"
    return counter
say shadow(), counter
define new_global():
    global created
    created = "now exists"
new_global()
say created
try:
    define oops():
        nonlocal missing
    oops()
catch e:
    say e

# unicode text
let s = "héllo wörld ✓"
say len(s), s[1], s[-1], s[0:5], s[6:], s.find("w"), s.find("ö")
for ch in "añb":
    say ch
say "日本語"[1], len("日本語"), "日本語" + "!"
say chr(26085), ord("日")
