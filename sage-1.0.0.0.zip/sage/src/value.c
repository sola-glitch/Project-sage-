/* Values, strings, lists, dictionaries, equality, printing, environments. */
#include "sage.h"

int cur_line = 0, exc_line = 0, call_depth = 0;
int cur_file = 0, exc_file = 0, parse_file = 0;
char *file_names[64];
static int n_files = 1;
Env *builtins;

int register_file(const char *path) {
    if (n_files >= 64) return 0;
    file_names[n_files] = strdup(path);
    return n_files++;
}
Handler *handlers = NULL;
Value exc_value;
Str *S_self, *S_home, *S_init, *S_totext, *S_range;

void *xmalloc(size_t n) {
    void *p = malloc(n ? n : 1);
    if (!p) { fprintf(stderr, "sage: out of memory\n"); exit(1); }
    return p;
}
void *xrealloc(void *p, size_t n) {
    p = realloc(p, n ? n : 1);
    if (!p) { fprintf(stderr, "sage: out of memory\n"); exit(1); }
    return p;
}

/* ---------- errors ---------- */
void sage_throw(Value v) {
    exc_value = v;
    exc_line = cur_line;
    exc_file = cur_file;
    gc_perm = 0;                      /* an error inside the parser must not leave allocations permanent */
    if (!handlers) { fprintf(stderr, "sage: uncaught error\n"); exit(1); }
    longjmp(handlers->jb, 1);
}
void sage_error(const char *fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    sage_throw(v_str(str_cstr(buf)));
}

/* ---------- string builder ---------- */
void sb_init(SB *b) { b->cap = 64; b->len = 0; b->s = xmalloc(b->cap); b->s[0] = 0; }
void sb_add(SB *b, const char *s, int n) {
    if (b->len + n + 1 > b->cap) {
        while (b->len + n + 1 > b->cap) b->cap *= 2;
        b->s = xrealloc(b->s, b->cap);
    }
    memcpy(b->s + b->len, s, n);
    b->len += n;
    b->s[b->len] = 0;
}
void sb_addc(SB *b, char c) { sb_add(b, &c, 1); }
void sb_adds(SB *b, const char *s) { sb_add(b, s, (int)strlen(s)); }
Str *sb_finish(SB *b) { Str *r = str_new(b->s, b->len); free(b->s); return r; }

/* ---------- strings ---------- */
static unsigned hash_bytes(const char *s, int n) {
    unsigned h = 2166136261u;
    for (int i = 0; i < n; i++) { h ^= (unsigned char)s[i]; h *= 16777619u; }
    return h;
}
int u8len(unsigned char c) { return c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 1; }

Str *str_new(const char *s, int len) {
    Str *r = gc_alloc(sizeof(Str), GC_STR);
    r->s = xmalloc(len + 1);
    memcpy(r->s, s, len);
    r->s[len] = 0;
    r->len = len;
    r->hash = hash_bytes(s, len);
    int chars = 0;
    for (int i = 0; i < len; i += u8len((unsigned char)s[i])) chars++;
    r->ulen = chars;
    gc_grow((size_t)len / 256);
    return r;
}

/* Byte offset of character number `ci` (0..ulen). */
long str_offset(Str *s, long ci) {
    if (s->ulen == s->len) return ci;
    long off = 0;
    for (long k = 0; k < ci && off < s->len; k++) off += u8len((unsigned char)s->s[off]);
    return off > s->len ? s->len : off;
}
Str *str_cstr(const char *s) { return str_new(s, (int)strlen(s)); }

static Str **itab; static int icap, icount;
Str *intern(const char *s, int len) {
    if (icount * 2 >= icap) {
        int nc = icap ? icap * 2 : 512;
        Str **nt = xmalloc(sizeof(Str *) * nc);
        for (int i = 0; i < nc; i++) nt[i] = NULL;
        for (int i = 0; i < icap; i++)
            if (itab[i]) {
                int j = itab[i]->hash & (nc - 1);
                while (nt[j]) j = (j + 1) & (nc - 1);
                nt[j] = itab[i];
            }
        free(itab); itab = nt; icap = nc;
    }
    unsigned h = hash_bytes(s, len);
    int i = h & (icap - 1);
    while (itab[i]) {
        if (itab[i]->len == len && memcmp(itab[i]->s, s, len) == 0) return itab[i];
        i = (i + 1) & (icap - 1);
    }
    gc_perm++;
    itab[i] = str_new(s, len);
    gc_perm--;
    icount++;
    return itab[i];
}

void init_names(void) {
    S_self = intern("self", 4);
    S_home = intern("__home__", 8);
    S_init = intern("init", 4);
    S_totext = intern("to_text", 7);
    S_range = intern("range", 5);
}

/* ---------- lists ---------- */
List *list_new(int cap) {
    List *l = gc_alloc(sizeof(List), GC_LIST);
    l->len = 0; l->cap = cap; l->items = cap ? xmalloc(sizeof(Value) * cap) : NULL;
    return l;
}
void list_push(List *l, Value v) {
    if (l->len == l->cap) {
        gc_grow((size_t)l->cap / 32 + 1);
        l->cap = l->cap ? l->cap * 2 : 4;
        l->items = xrealloc(l->items, sizeof(Value) * l->cap);
    }
    l->items[l->len++] = v;
}

/* ---------- dictionaries (insertion ordered, open-addressing index) ---------- */
static unsigned hash_value(Value k) {
    switch (k.t) {
    case T_STR: return AS_STR(k)->hash;
    case T_NUM: {
        double d = k.u.n; if (d == 0) d = 0;
        unsigned long long b; memcpy(&b, &d, 8);
        return (unsigned)(b ^ (b >> 32)) * 2654435761u;
    }
    case T_BOOL: return k.u.b ? 1 : 2;
    case T_TUPLE: {
        unsigned h = 7;
        List *l = AS_LIST(k);
        for (int i = 0; i < l->len; i++) h = h * 31u + hash_value(l->items[i]);
        return h;
    }
    case T_NOTHING: return 3;
    case T_INST: case T_CLASS: case T_FUNC: case T_NATIVE: {
        unsigned long long x = (unsigned long long)(size_t)k.u.p >> 4;
        return (unsigned)(x ^ (x >> 32)) * 2654435761u;
    }
    default: sage_error("a %s cannot be used as a dictionary key", type_name(k));
    }
    return 0;
}
static bool key_equal(Value a, Value b) { return a.t == b.t && values_equal(a, b); }

Dict *dict_new(void) {
    Dict *d = gc_alloc(sizeof(Dict), GC_DICT);
    d->len = d->used = d->cap = d->icap = 0; d->e = NULL; d->idx = NULL;
    return d;
}
static int dict_find(Dict *d, Value k) {
    if (!d->icap) return -1;
    int i = hash_value(k) & (d->icap - 1);
    while (d->idx[i] != -1) {
        Entry *e = &d->e[d->idx[i]];
        if (e->live && key_equal(e->k, k)) return d->idx[i];
        i = (i + 1) & (d->icap - 1);
    }
    return -1;
}
static void dict_rebuild(Dict *d, int icap) {
    int j = 0;
    for (int i = 0; i < d->used; i++) if (d->e[i].live) d->e[j++] = d->e[i];
    d->used = j;
    free(d->idx);
    d->icap = icap;
    d->idx = xmalloc(sizeof(int) * icap);
    for (int i = 0; i < icap; i++) d->idx[i] = -1;
    for (int i = 0; i < d->used; i++) {
        int s = hash_value(d->e[i].k) & (icap - 1);
        while (d->idx[s] != -1) s = (s + 1) & (icap - 1);
        d->idx[s] = i;
    }
}
bool dict_get(Dict *d, Value k, Value *out) {
    int i = dict_find(d, k);
    if (i < 0) return false;
    if (out) *out = d->e[i].v;
    return true;
}
void dict_set(Dict *d, Value k, Value v) {
    int i = dict_find(d, k);
    if (i >= 0) { d->e[i].v = v; return; }
    if ((d->used + 1) * 2 > d->icap) {
        int nc = d->icap ? d->icap : 8;
        while ((d->len + 1) * 2 > nc) nc *= 2;
        dict_rebuild(d, nc);
    }
    if (d->used == d->cap) {
        gc_grow((size_t)d->cap / 16 + 1);
        d->cap = d->cap ? d->cap * 2 : 4;
        d->e = xrealloc(d->e, sizeof(Entry) * d->cap);
    }
    d->e[d->used].k = k; d->e[d->used].v = v; d->e[d->used].live = true;
    int s = hash_value(k) & (d->icap - 1);
    while (d->idx[s] != -1) s = (s + 1) & (d->icap - 1);
    d->idx[s] = d->used++;
    d->len++;
}
bool dict_del(Dict *d, Value k) {
    int i = dict_find(d, k);
    if (i < 0) return false;
    d->e[i].live = false;
    d->len--;
    return true;
}

/* ---------- semantics helpers ---------- */
bool truthy(Value v) {
    switch (v.t) {
    case T_NOTHING: return false;
    case T_BOOL: return v.u.b;
    case T_NUM: return v.u.n != 0;
    case T_STR: return AS_STR(v)->len > 0;
    case T_LIST: case T_TUPLE: return AS_LIST(v)->len > 0;
    case T_DICT: case T_SET: return AS_DICT(v)->len > 0;
    default: return true;
    }
}

bool values_equal(Value a, Value b) {
    if (a.t != b.t) return false;
    switch (a.t) {
    case T_NOTHING: return true;
    case T_BOOL: return a.u.b == b.u.b;
    case T_NUM: return a.u.n == b.u.n;
    case T_STR: return AS_STR(a)->len == AS_STR(b)->len &&
                       memcmp(AS_STR(a)->s, AS_STR(b)->s, AS_STR(a)->len) == 0;
    case T_LIST: case T_TUPLE: {
        List *x = AS_LIST(a), *y = AS_LIST(b);
        if (x == y) return true;
        if (x->len != y->len) return false;
        for (int i = 0; i < x->len; i++) if (!values_equal(x->items[i], y->items[i])) return false;
        return true;
    }
    case T_SET: {
        Dict *x = AS_DICT(a), *y = AS_DICT(b);
        if (x == y) return true;
        if (x->len != y->len) return false;
        DICT_EACH(x, i) if (!dict_get(y, x->e[i].k, NULL)) return false;
        return true;
    }
    case T_DICT: {
        Dict *x = AS_DICT(a), *y = AS_DICT(b);
        if (x == y) return true;
        if (x->len != y->len) return false;
        DICT_EACH(x, i) {
            Value o;
            if (!dict_get(y, x->e[i].k, &o) || !values_equal(x->e[i].v, o)) return false;
        }
        return true;
    }
    default: return a.u.p == b.u.p;
    }
}

int compare_values(Value a, Value b) {
    if (a.t == T_NUM && b.t == T_NUM) return a.u.n < b.u.n ? -1 : a.u.n > b.u.n ? 1 : 0;
    if (a.t == T_STR && b.t == T_STR) {
        int c = strcmp(AS_STR(a)->s, AS_STR(b)->s);
        return c < 0 ? -1 : c > 0 ? 1 : 0;
    }
    if ((a.t == T_LIST || a.t == T_TUPLE) && a.t == b.t) {
        List *x = AS_LIST(a), *y = AS_LIST(b);
        for (int i = 0; i < x->len && i < y->len; i++) {
            int c = compare_values(x->items[i], y->items[i]);
            if (c) return c;
        }
        return x->len < y->len ? -1 : x->len > y->len ? 1 : 0;
    }
    sage_error("cannot compare %s with %s", type_name(a), type_name(b));
}

const char *type_name(Value v) {
    switch (v.t) {
    case T_NOTHING: return "nothing";
    case T_BOOL: return "boolean";
    case T_NUM: return "number";
    case T_STR: return "text";
    case T_LIST: return "list";
    case T_DICT: return "dict";
    case T_TUPLE: return "tuple";
    case T_SET: return "set";
    case T_FUNC: case T_NATIVE: case T_BOUND: return "function";
    case T_CLASS: return "class";
    case T_INST: return AS_INST(v)->cls->name->s;
    case T_ALIAS: return "?";
    }
    return "?";
}

bool class_find(Class *c, Str *name, Value *out) {
    for (; c; c = c->parent)
        if (dict_get(c->methods, v_str(name), out)) return true;
    return false;
}
bool class_is(Class *c, Class *target) {
    for (; c; c = c->parent) if (c == target) return true;
    return false;
}

/* ---------- printing ---------- */
static void fmt_num(char *buf, size_t n, double d) {
    if (isnan(d)) snprintf(buf, n, "nan");
    else if (isinf(d)) snprintf(buf, n, d > 0 ? "inf" : "-inf");
    else if (d == 0) snprintf(buf, n, "0");
    else if (d == floor(d) && fabs(d) < 1e15) snprintf(buf, n, "%.0f", d);
    else snprintf(buf, n, "%.14g", d);
}

static void repr_into(SB *b, Value v, bool nested, int depth) {
    char buf[64];
    if (depth > 8) { sb_adds(b, "..."); return; }
    switch (v.t) {
    case T_NOTHING: sb_adds(b, "nothing"); break;
    case T_BOOL: sb_adds(b, v.u.b ? "true" : "false"); break;
    case T_NUM: fmt_num(buf, sizeof buf, v.u.n); sb_adds(b, buf); break;
    case T_STR:
        if (!nested) { sb_add(b, AS_STR(v)->s, AS_STR(v)->len); break; }
        sb_addc(b, '"');
        for (int i = 0; i < AS_STR(v)->len; i++) {
            char c = AS_STR(v)->s[i];
            if (c == '"') sb_adds(b, "\\\"");
            else if (c == '\\') sb_adds(b, "\\\\");
            else if (c == '\n') sb_adds(b, "\\n");
            else if (c == '\t') sb_adds(b, "\\t");
            else sb_addc(b, c);
        }
        sb_addc(b, '"');
        break;
    case T_LIST: {
        List *l = AS_LIST(v);
        sb_addc(b, '[');
        for (int i = 0; i < l->len; i++) {
            if (i) sb_adds(b, ", ");
            repr_into(b, l->items[i], true, depth + 1);
        }
        sb_addc(b, ']');
        break;
    }
    case T_TUPLE: {
        List *l = AS_LIST(v);
        sb_addc(b, '(');
        for (int i = 0; i < l->len; i++) {
            if (i) sb_adds(b, ", ");
            repr_into(b, l->items[i], true, depth + 1);
        }
        if (l->len == 1) sb_addc(b, ',');
        sb_addc(b, ')');
        break;
    }
    case T_SET: {
        Dict *d = AS_DICT(v);
        if (d->len == 0) { sb_adds(b, "set()"); break; }
        bool first = true;
        sb_addc(b, '{');
        DICT_EACH(d, i) {
            if (!first) sb_adds(b, ", ");
            first = false;
            repr_into(b, d->e[i].k, true, depth + 1);
        }
        sb_addc(b, '}');
        break;
    }
    case T_DICT: {
        Dict *d = AS_DICT(v);
        bool first = true;
        sb_addc(b, '{');
        DICT_EACH(d, i) {
            if (!first) sb_adds(b, ", ");
            first = false;
            repr_into(b, d->e[i].k, true, depth + 1);
            sb_adds(b, ": ");
            repr_into(b, d->e[i].v, true, depth + 1);
        }
        sb_addc(b, '}');
        break;
    }
    case T_FUNC: {
        Node *d = AS_FUNC(v)->def;
        sb_adds(b, "<function "); sb_adds(b, d->name ? d->name->s : "lambda"); sb_addc(b, '>');
        break;
    }
    case T_NATIVE: sb_adds(b, "<builtin "); sb_adds(b, AS_NATIVE(v)->name); sb_addc(b, '>'); break;
    case T_ALIAS: break;
    case T_BOUND: sb_adds(b, "<method>"); break;
    case T_CLASS: sb_adds(b, "<class "); sb_adds(b, AS_CLASS(v)->name->s); sb_addc(b, '>'); break;
    case T_INST: {
        Value m;
        if (class_find(AS_INST(v)->cls, S_totext, &m)) {
            Value r = call_method(v, m, 0, NULL);
            Str *s = to_str(r);
            sb_add(b, s->s, s->len);
        } else if (class_find(AS_INST(v)->cls, intern("__str__", 7), &m)) {
            Str *s = to_str(call_method(v, m, 0, NULL));
            sb_add(b, s->s, s->len);
        } else {
            sb_adds(b, "<"); sb_adds(b, AS_INST(v)->cls->name->s); sb_adds(b, " object>");
        }
        break;
    }
    }
}

Str *to_str(Value v) {
    if (v.t == T_STR) return AS_STR(v);
    SB b; sb_init(&b);
    repr_into(&b, v, false, 0);
    return sb_finish(&b);
}
Str *repr_str(Value v) {
    SB b; sb_init(&b);
    repr_into(&b, v, true, 0);
    return sb_finish(&b);
}

/* ---------- environments ---------- */
Env *env_new(Env *parent) {
    Env *e = gc_alloc(sizeof(Env), GC_ENV);
    e->parent = parent; e->n = e->cap = 0; e->names = NULL; e->vals = NULL;
    return e;
}
static Value *find_slot(Env *e, Str *name) {
    for (int i = e->n - 1; i >= 0; i--)
        if (e->names[i] == name) return &e->vals[i];
    return NULL;
}
bool env_has_local(Env *e, Str *name) { return find_slot(e, name) != NULL; }
bool env_lookup_local(Env *e, Str *name, Value *out) {
    Value *s = find_slot(e, name);
    if (!s || s->t == T_ALIAS) return false;
    *out = *s;
    return true;
}
/* The scope of the file (module) that e belongs to: the one just inside the builtins. */
Env *module_root(Env *e) {
    while (e->parent && e->parent != builtins) e = e->parent;
    return e;
}

/* Look a name up through the scope chain, following 'global' / 'nonlocal' markers. */
bool env_get(Env *e, Str *name, Value *out) {
    for (; e; e = e->parent) {
        Value *s = find_slot(e, name);
        if (!s) continue;
        if (s->t != T_ALIAS) { *out = *s; return true; }
        if (s->u.b) {                                   /* global: look only in the global scope */
            Value *g = find_slot(module_root(e), name);
            if (g && g->t != T_ALIAS) { *out = *g; return true; }
            return false;
        }
        /* nonlocal: keep searching outward */
    }
    return false;
}

void env_define(Env *e, Str *name, Value v) {
    Value *s = find_slot(e, name);
    if (s) { *s = v; return; }
    if (e->n == e->cap) {
        gc_grow((size_t)e->cap / 16 + 1);
        e->cap = e->cap ? e->cap * 2 : 4;
        e->names = xrealloc(e->names, sizeof(Str *) * e->cap);
        e->vals = xrealloc(e->vals, sizeof(Value) * e->cap);
    }
    e->names[e->n] = name; e->vals[e->n] = v; e->n++;
}

/* Assignment: a plain name is local to the current scope unless it was
 * declared 'global' or 'nonlocal' there. */
void env_set(Env *e, Str *name, Value v) {
    Value *s = find_slot(e, name);
    if (!s) { env_define(e, name, v); return; }
    if (s->t != T_ALIAS) { *s = v; return; }
    if (s->u.b) {
        Env *root = module_root(e);
        Value *g = find_slot(root, name);
        if (g && g->t != T_ALIAS) *g = v; else env_define(root, name, v);
        return;
    }
    for (Env *p = e->parent; p; p = p->parent) {
        Value *q = find_slot(p, name);
        if (!q) continue;
        if (q->t != T_ALIAS) { *q = v; return; }
        if (q->u.b) { Env *root = module_root(e); Value *g = find_slot(root, name); if (g) *g = v; else env_define(root, name, v); return; }
    }
    sage_error("no variable '%s' in an enclosing function to share", name->s);
}
