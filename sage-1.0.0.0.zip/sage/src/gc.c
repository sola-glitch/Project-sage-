/* Garbage collector: mark and sweep.
 *
 * Every runtime object (text, list, dict, function, class, instance, bound
 * method, scope) is allocated here behind a small header and linked in one list.
 * Roots are the global scope, a few interpreter variables, and the C stack,
 * which is scanned conservatively (any word that equals the address of a live
 * object keeps it alive). Collection only happens at safe points: the start of
 * a statement and the start of a function call.
 *
 * Objects created while the parser runs (names, string constants in the AST)
 * are "permanent": never collected.
 */
#include "sage.h"
#include <stdint.h>

typedef struct GCHdr { struct GCHdr *next; unsigned char kind, marked, perm; } GCHdr;
#define HDR(p) (((GCHdr *)(p)) - 1)

int gc_perm = 0;
size_t gc_units = 0, gc_threshold = 200000;
static const size_t GC_MIN_THRESHOLD = 200000;
static GCHdr *all_objs;
static void *stack_base;
static bool gc_stress, gc_log;
static size_t gc_runs;

/* ---- set of live object addresses (for the conservative stack scan) ---- */
static void **pset;
static size_t pcap, pcount;
static size_t ph(void *p) {
    uint64_t x = (uint64_t)(uintptr_t)p >> 4;
    x *= 0x9E3779B97F4A7C15ULL;
    return (size_t)(x >> 24);
}
static void pset_put(void **tab, size_t cap, void *p) {
    size_t i = ph(p) & (cap - 1);
    while (tab[i]) i = (i + 1) & (cap - 1);
    tab[i] = p;
}
static void pset_grow(void) {
    size_t nc = pcap ? pcap * 2 : 4096;
    void **nt = calloc(nc, sizeof(void *));
    if (!nt) { fprintf(stderr, "sage: out of memory\n"); exit(1); }
    for (size_t i = 0; i < pcap; i++) if (pset[i]) pset_put(nt, nc, pset[i]);
    free(pset);
    pset = nt; pcap = nc;
}
static bool pset_has(void *p) {
    if (!pcap) return false;
    size_t i = ph(p) & (pcap - 1);
    while (pset[i]) {
        if (pset[i] == p) return true;
        i = (i + 1) & (pcap - 1);
    }
    return false;
}

/* ---- allocation ---- */
void *gc_alloc(size_t size, int kind) {
    GCHdr *h = xmalloc(sizeof(GCHdr) + size);
    memset(h + 1, 0, size);
    h->kind = (unsigned char)kind;
    h->marked = 0;
    h->perm = gc_perm > 0;
    h->next = NULL;
    void *p = h + 1;
    if (!h->perm) {
        h->next = all_objs;
        all_objs = h;
        if ((pcount + 1) * 2 > pcap) pset_grow();
        pset_put(pset, pcap, p);
        pcount++;
        gc_units++;
    }
    return p;
}
void gc_grow(size_t units) { gc_units += units; }

/* ---- roots ---- */
static Value *root_vals[8];
static void **root_ptrs[8];
static int n_root_vals, n_root_ptrs;
void gc_root_value(Value *v) { root_vals[n_root_vals++] = v; }
void gc_root_ptr(void **p) { root_ptrs[n_root_ptrs++] = p; }

/* ---- marking ---- */
static void **work;
static size_t wn, wcap;
static void wpush(void *p) {
    if (wn == wcap) { wcap = wcap ? wcap * 2 : 4096; work = xrealloc(work, wcap * sizeof(void *)); }
    work[wn++] = p;
}
static void mark_ptr(void *p) {
    if (!p) return;
    GCHdr *h = HDR(p);
    if (h->perm || h->marked) return;
    h->marked = 1;
    wpush(p);
}
static void mark_value(Value v) {
    switch (v.t) {
    case T_STR: case T_LIST: case T_TUPLE: case T_SET: case T_DICT: case T_FUNC: case T_CLASS: case T_INST: case T_BOUND:
        mark_ptr(v.u.p);
        break;
    default: break;
    }
}
static void drain(void) {
    while (wn) {
        void *p = work[--wn];
        switch (HDR(p)->kind) {
        case GC_LIST: { List *l = p; for (int i = 0; i < l->len; i++) mark_value(l->items[i]); break; }
        case GC_DICT: {
            Dict *d = p;
            for (int i = 0; i < d->used; i++)
                if (d->e[i].live) { mark_value(d->e[i].k); mark_value(d->e[i].v); }
            break;
        }
        case GC_FUNC: { Func *f = p; mark_ptr(f->closure); mark_ptr(f->home); break; }
        case GC_CLASS: { Class *c = p; mark_ptr(c->parent); mark_ptr(c->methods); break; }
        case GC_INST: { Inst *in = p; mark_ptr(in->cls); mark_ptr(in->fields); mark_ptr(in->extra); break; }
        case GC_BOUND: { Bound *b = p; mark_value(b->self); mark_value(b->fn); break; }
        case GC_ENV: { Env *e = p; mark_ptr(e->parent); for (int i = 0; i < e->n; i++) mark_value(e->vals[i]); break; }
        default: break;
        }
    }
}

/* Scan the C stack from here up to the base recorded by gc_init. */
static void __attribute__((noinline)) scan_stack(void) {
    __builtin_unwind_init();                 /* spill callee-saved registers into this frame */
    volatile uintptr_t anchor = 0;
    uintptr_t lo = ((uintptr_t)&anchor - 64) & ~(uintptr_t)7;
    uintptr_t hi = (uintptr_t)stack_base;
    for (uintptr_t a = lo; a < hi; a += sizeof(void *)) {
        void *w = *(void **)a;
        if (pset_has(w)) mark_ptr(w);
    }
}

/* ---- sweeping ---- */
static size_t obj_units(void *p, int kind) {
    switch (kind) {
    case GC_STR: return 1 + (size_t)((Str *)p)->len / 256;
    case GC_LIST: return 1 + (size_t)((List *)p)->cap / 32;
    case GC_DICT: return 1 + (size_t)((Dict *)p)->cap / 16;
    case GC_ENV: return 1 + (size_t)((Env *)p)->cap / 16;
    default: return 1;
    }
}
static void free_obj(GCHdr *h) {
    void *p = h + 1;
    switch (h->kind) {
    case GC_STR: free(((Str *)p)->s); break;
    case GC_LIST: free(((List *)p)->items); break;
    case GC_DICT: free(((Dict *)p)->e); free(((Dict *)p)->idx); break;
    case GC_ENV: free(((Env *)p)->names); free(((Env *)p)->vals); break;
    default: break;
    }
    free(h);
}

size_t gc_collect(void) {
    if (gc_perm > 0) return 0;
    for (int i = 0; i < n_root_vals; i++) mark_value(*root_vals[i]);
    for (int i = 0; i < n_root_ptrs; i++) mark_ptr(*root_ptrs[i]);
    scan_stack();
    drain();

    size_t live = 0, units = 0, freed = 0;
    GCHdr **pp = &all_objs;
    while (*pp) {
        GCHdr *h = *pp;
        if (h->marked) {
            h->marked = 0;
            live++;
            units += obj_units(h + 1, h->kind);
            pp = &h->next;
        } else {
            *pp = h->next;
            free_obj(h);
            freed++;
        }
    }
    /* rebuild the address set from the survivors */
    free(pset); pset = NULL; pcap = 0; pcount = 0;
    for (GCHdr *h = all_objs; h; h = h->next) {
        if ((pcount + 1) * 2 > pcap) pset_grow();
        pset_put(pset, pcap, h + 1);
        pcount++;
    }
    gc_units = units;
    gc_threshold = gc_stress ? 0 : (units * 2 > GC_MIN_THRESHOLD ? units * 2 : GC_MIN_THRESHOLD);
    gc_runs++;
    if (gc_log) fprintf(stderr, "[gc %zu: %zu live, %zu freed]\n", gc_runs, live, freed);
    return live;
}

void gc_init(void *base) {
    stack_base = base;
    gc_stress = getenv("SAGE_GC_STRESS") != NULL;
    gc_log = getenv("SAGE_GC_LOG") != NULL;
    if (gc_stress) gc_threshold = 0;
}
