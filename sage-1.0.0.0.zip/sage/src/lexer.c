/* Lexer: source text -> tokens, with Python-style INDENT / DEDENT. */
#include "sage.h"
#include <ctype.h>

static const char *KEYWORDS[] = {
    "let", "say", "if", "else", "elif", "while", "for", "in", "repeat", "define",
    "return", "break", "continue", "pass", "class", "try", "catch", "raise",
    "lambda", "and", "or", "not", "is", "true", "false", "nothing", "use",
    "assert", "super", "import", "with", "finally", NULL
};

typedef struct { Token *t; int n, cap; } TL;

static Token *tpush(TL *l, TokType t, int line) {
    if (l->n == l->cap) { l->cap *= 2; l->t = xrealloc(l->t, sizeof(Token) * l->cap); }
    Token *k = &l->t[l->n++];
    memset(k, 0, sizeof *k);
    k->t = t; k->line = line;
    return k;
}

static void lex_error(int line, const char *msg, int c) {
    cur_line = line;
    if (c) sage_error("syntax error: %s '%c'", msg, c);
    sage_error("syntax error: %s", msg);
}

/* Decode backslash escapes in s[0..n). */
static Str *unescape(const char *s, int n) {
    SB b; sb_init(&b);
    for (int i = 0; i < n; i++) {
        if (s[i] == '\\' && i + 1 < n) {
            char c = s[++i];
            switch (c) {
            case 'n': sb_addc(&b, '\n'); break;
            case 't': sb_addc(&b, '\t'); break;
            case 'r': sb_addc(&b, '\r'); break;
            case '0': sb_addc(&b, '\0'); break;
            default: sb_addc(&b, c); break;
            }
        } else sb_addc(&b, s[i]);
    }
    return sb_finish(&b);
}
Str *lex_unescape(const char *s, int n) { return unescape(s, n); }

static bool is_keyword(const char *s, int len) {
    for (int i = 0; KEYWORDS[i]; i++)
        if ((int)strlen(KEYWORDS[i]) == len && memcmp(KEYWORDS[i], s, len) == 0) return true;
    return false;
}

static const char *OPS2[] = { "**", "//", "==", "!=", "<=", ">=", "|>", "+=", "-=", "*=", "/=", "%=", NULL };

Token *lex(const char *src, int *outn) {
    TL l = { xmalloc(sizeof(Token) * 256), 0, 256 };
    int indents[256], ni = 0, line = 1, depth = 0;
    indents[0] = 0;
    const char *p = src;
    bool at_start = true;

    while (*p) {
        if (at_start && depth == 0) {
            int col = 0;
            const char *q = p;
            while (*q == ' ' || *q == '\t') { col += (*q == '\t') ? 4 : 1; q++; }
            if (*q == '\n' || *q == '\r' || *q == '#' || *q == 0) {   /* blank / comment line */
                while (*q && *q != '\n') q++;
                if (*q == '\n') { q++; line++; }
                p = q;
                continue;
            }
            p = q;
            at_start = false;
            if (col > indents[ni]) {
                if (ni >= 255) lex_error(line, "too many nested blocks", 0);
                indents[++ni] = col;
                tpush(&l, TK_INDENT, line);
            } else {
                while (col < indents[ni]) { ni--; tpush(&l, TK_DEDENT, line); }
                if (col != indents[ni]) lex_error(line, "inconsistent indentation", 0);
            }
        }
        char c = *p;
        if (c == ' ' || c == '\t' || c == '\r') { p++; continue; }
        if (c == '#') { while (*p && *p != '\n') p++; continue; }
        if (c == '\\' && (p[1] == '\n' || (p[1] == '\r' && p[2] == '\n'))) {
            p += (p[1] == '\n') ? 2 : 3; line++; continue;
        }
        if (c == '\n') {
            if (depth == 0) {
                /* a following line that starts with |> continues this statement */
                const char *q = p + 1;
                while (*q == ' ' || *q == '\t' || *q == '\r' || *q == '\n') q++;
                if (q[0] == '|' && q[1] == '>') { p++; line++; continue; }
                if (l.n > 0 && l.t[l.n - 1].t != TK_NEWLINE) tpush(&l, TK_NEWLINE, line);
                at_start = true;
            }
            p++; line++;
            continue;
        }

        /* numbers */
        if (isdigit((unsigned char)c)) {
            char *end;
            double d = strtod(p, &end);
            Token *k = tpush(&l, TK_NUM, line);
            k->num = d;
            p = end;
            continue;
        }

        /* identifiers, keywords, f-strings */
        if (isalpha((unsigned char)c) || c == '_') {
            const char *s = p;
            while (isalnum((unsigned char)*p) || *p == '_') p++;
            int len = (int)(p - s);
            if (len == 1 && *s == 'f' && (*p == '"' || *p == '\'')) {
                char q = *p++;
                const char *st = p;
                while (*p && *p != q) {
                    if (*p == '\\' && p[1]) p++;
                    if (*p == '\n') lex_error(line, "unterminated string", 0);
                    p++;
                }
                if (!*p) lex_error(line, "unterminated string", 0);
                Token *k = tpush(&l, TK_FSTR, line);
                k->str = str_new(st, (int)(p - st));
                p++;
                continue;
            }
            Token *k = tpush(&l, is_keyword(s, len) ? TK_KW : TK_IDENT, line);
            k->str = intern(s, len);
            continue;
        }

        /* strings */
        if (c == '"' || c == '\'') {
            char q = c;
            if (p[1] == q && p[2] == q) {                       /* triple quoted */
                p += 3;
                const char *st = p;
                int startline = line;
                while (*p && !(p[0] == q && p[1] == q && p[2] == q)) {
                    if (*p == '\n') line++;
                    if (*p == '\\' && p[1]) p++;
                    p++;
                }
                if (!*p) lex_error(startline, "unterminated triple-quoted string", 0);
                Token *k = tpush(&l, TK_STR, startline);
                k->str = unescape(st, (int)(p - st));
                p += 3;
                continue;
            }
            p++;
            const char *st = p;
            while (*p && *p != q) {
                if (*p == '\\' && p[1]) p++;
                if (*p == '\n') lex_error(line, "unterminated string", 0);
                p++;
            }
            if (!*p) lex_error(line, "unterminated string", 0);
            Token *k = tpush(&l, TK_STR, line);
            k->str = unescape(st, (int)(p - st));
            p++;
            continue;
        }

        /* operators */
        bool matched = false;
        for (int i = 0; OPS2[i]; i++)
            if (p[0] == OPS2[i][0] && p[1] == OPS2[i][1]) {
                Token *k = tpush(&l, TK_OP, line);
                k->str = intern(OPS2[i], 2);
                p += 2; matched = true; break;
            }
        if (matched) continue;
        if (strchr("+-*/%<>=()[]{},:.@|&", c)) {
            if (c == '(' || c == '[' || c == '{') depth++;
            if (c == ')' || c == ']' || c == '}') { if (depth > 0) depth--; }
            Token *k = tpush(&l, TK_OP, line);
            k->str = intern(p, 1);
            p++;
            continue;
        }
        lex_error(line, "unexpected character", (unsigned char)c);
    }

    if (depth > 0) lex_error(line, "unclosed bracket", 0);
    if (l.n > 0 && l.t[l.n - 1].t != TK_NEWLINE) tpush(&l, TK_NEWLINE, line);
    while (ni > 0) { ni--; tpush(&l, TK_DEDENT, line); }
    tpush(&l, TK_EOF, line);
    *outn = l.n;
    return l.t;
}
