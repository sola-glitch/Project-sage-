/* Case mapping for the scripts most people write in: Latin (incl. accents and
   Latin Extended-A), Greek and Cyrillic. Other characters pass through unchanged. */
#include "sage.h"

static bool pair_upper_even(unsigned c) {      /* ranges where even = upper, odd = lower */
    return (c >= 0x100 && c <= 0x137) || (c >= 0x14A && c <= 0x177) ||
           (c >= 0x460 && c <= 0x481) || (c >= 0x48A && c <= 0x4BF) || (c >= 0x4D0 && c <= 0x52F);
}
static bool pair_upper_odd(unsigned c) {       /* ranges where odd = upper, even = lower */
    return (c >= 0x139 && c <= 0x148) || (c >= 0x179 && c <= 0x17E) || (c >= 0x4C1 && c <= 0x4CE);
}

unsigned uc_upper(unsigned c) {
    if (c < 0x80) return (c >= 'a' && c <= 'z') ? c - 32 : c;
    if (c == 0xFF) return 0x178;
    if (c == 0xB5) return 0x39C;
    if (c >= 0xE0 && c <= 0xFE && c != 0xF7) return c - 32;
    if (pair_upper_even(c)) return (c & 1) ? c - 1 : c;
    if (pair_upper_odd(c)) return (c & 1) ? c : c - 1;
    if (c == 0x3C2) return 0x3A3;
    if (c >= 0x3B1 && c <= 0x3CB) return c - 32;
    if (c == 0x3AC) return 0x386;
    if (c >= 0x3AD && c <= 0x3AF) return c - 37;
    if (c == 0x3CC) return 0x38C;
    if (c == 0x3CD || c == 0x3CE) return c - 63;
    if (c >= 0x430 && c <= 0x44F) return c - 32;
    if (c >= 0x450 && c <= 0x45F) return c - 80;
    return c;
}
unsigned uc_lower(unsigned c) {
    if (c < 0x80) return (c >= 'A' && c <= 'Z') ? c + 32 : c;
    if (c == 0x178) return 0xFF;
    if (c >= 0xC0 && c <= 0xDE && c != 0xD7) return c + 32;
    if (pair_upper_even(c)) return (c & 1) ? c : c + 1;
    if (pair_upper_odd(c)) return (c & 1) ? c + 1 : c;
    if (c >= 0x391 && c <= 0x3AB && c != 0x3A2) return c + 32;
    if (c == 0x386) return 0x3AC;
    if (c >= 0x388 && c <= 0x38A) return c + 37;
    if (c == 0x38C) return 0x3CC;
    if (c == 0x38E || c == 0x38F) return c + 63;
    if (c >= 0x410 && c <= 0x42F) return c + 32;
    if (c >= 0x400 && c <= 0x40F) return c + 80;
    return c;
}
bool uc_is_space(unsigned c) { return c == ' ' || (c >= 9 && c <= 13) || c == 0xA0; }

/* Decode one UTF-8 character at s (n bytes left); returns its length. */
static int decode(const char *s, int n, unsigned *out) {
    unsigned char c = (unsigned char)s[0];
    int len = u8len(c);
    if (len > n) len = 1;
    if (len == 1) { *out = c; return 1; }
    unsigned cp = c & (0xFF >> (len + 1));
    for (int i = 1; i < len; i++) {
        if (((unsigned char)s[i] & 0xC0) != 0x80) { *out = c; return 1; }
        cp = (cp << 6) | ((unsigned char)s[i] & 0x3F);
    }
    *out = cp;
    return len;
}
static void encode(SB *b, unsigned c) {
    if (c < 0x80) sb_addc(b, (char)c);
    else if (c < 0x800) { sb_addc(b, (char)(0xC0 | (c >> 6))); sb_addc(b, (char)(0x80 | (c & 0x3F))); }
    else if (c < 0x10000) { sb_addc(b, (char)(0xE0 | (c >> 12))); sb_addc(b, (char)(0x80 | ((c >> 6) & 0x3F))); sb_addc(b, (char)(0x80 | (c & 0x3F))); }
    else { sb_addc(b, (char)(0xF0 | (c >> 18))); sb_addc(b, (char)(0x80 | ((c >> 12) & 0x3F))); sb_addc(b, (char)(0x80 | ((c >> 6) & 0x3F))); sb_addc(b, (char)(0x80 | (c & 0x3F))); }
}

/* mode: 0 = upper, 1 = lower, 2 = title (first letter of each word upper, rest lower) */
Str *uc_convert(Str *s, int mode) {
    SB b; sb_init(&b);
    bool start = true;
    for (int i = 0; i < s->len;) {
        unsigned c;
        int n = decode(s->s + i, s->len - i, &c);
        if (n == 1 && c >= 0x80) { sb_addc(&b, s->s[i]); i++; continue; }   /* invalid byte: keep */
        unsigned r = mode == 0 ? uc_upper(c) : mode == 1 ? uc_lower(c) : (start ? uc_upper(c) : uc_lower(c));
        start = uc_is_space(c);
        encode(&b, r);
        i += n;
    }
    return sb_finish(&b);
}
