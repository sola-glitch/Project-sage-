/* re module: regular expressions on top of POSIX extended regex. */
#include "sage.h"
#include <regex.h>
#include <ctype.h>

#define NATIVE(name) static Value name(__attribute__((unused)) int argc, __attribute__((unused)) Value *argv)

/* Translate the common shorthand (\d \w \s \D \W \S \b) into POSIX classes. */
static char *translate(const char *p, int n) {
    SB b; sb_init(&b);
    for (int i = 0; i < n; i++) {
        if (p[i] == '\\' && i + 1 < n) {
            char c = p[++i];
            switch (c) {
            case 'd': sb_adds(&b, "[[:digit:]]"); break;
            case 'D': sb_adds(&b, "[^[:digit:]]"); break;
            case 'w': sb_adds(&b, "[[:alnum:]_]"); break;
            case 'W': sb_adds(&b, "[^[:alnum:]_]"); break;
            case 's': sb_adds(&b, "[[:space:]]"); break;
            case 'S': sb_adds(&b, "[^[:space:]]"); break;
            case 'n': sb_addc(&b, '\n'); break;
            case 't': sb_addc(&b, '\t'); break;
            default: sb_addc(&b, '\\'); sb_addc(&b, c);
            }
        } else sb_addc(&b, p[i]);
    }
    char *r = b.s;
    return r;
}
static void compile(regex_t *re, Value pat) {
    if (pat.t != T_STR) sage_error("re needs a text pattern, not a %s", type_name(pat));
    char *t = translate(AS_STR(pat)->s, AS_STR(pat)->len);
    int rc = regcomp(re, t, REG_EXTENDED);
    free(t);
    if (rc) {
        char msg[200];
        regerror(rc, re, msg, sizeof msg);
        sage_error("bad pattern '%s': %s", AS_STR(pat)->s, msg);
    }
}
static void need_text(Value v, const char *fn) {
    if (v.t != T_STR) sage_error("re.%s() needs text to search, not a %s", fn, type_name(v));
}

/* Match info as a dict: text, start, end (byte offsets), groups. */
static Value match_dict(const char *base, regmatch_t *m, int ng) {
    Dict *d = dict_new();
    Value dv = v_obj(T_DICT, d);
    dict_set(d, v_str(str_cstr("text")), v_str(str_new(base + m[0].rm_so, (int)(m[0].rm_eo - m[0].rm_so))));
    dict_set(d, v_str(str_cstr("start")), v_num(m[0].rm_so));
    dict_set(d, v_str(str_cstr("end")), v_num(m[0].rm_eo));
    List *g = list_new(ng);
    for (int i = 1; i <= ng; i++)
        list_push(g, m[i].rm_so < 0 ? v_nothing() : v_str(str_new(base + m[i].rm_so, (int)(m[i].rm_eo - m[i].rm_so))));
    dict_set(d, v_str(str_cstr("groups")), v_obj(T_LIST, g));
    return dv;
}

NATIVE(re_test) {
    need_text(argv[1], "test");
    regex_t re; compile(&re, argv[0]);
    int rc = regexec(&re, AS_STR(argv[1])->s, 0, NULL, 0);
    regfree(&re);
    return v_bool(rc == 0);
}
NATIVE(re_search) {
    need_text(argv[1], "search");
    regex_t re; compile(&re, argv[0]);
    regmatch_t m[10];
    int rc = regexec(&re, AS_STR(argv[1])->s, 10, m, 0);
    Value r = rc == 0 ? match_dict(AS_STR(argv[1])->s, m, (int)re.re_nsub > 9 ? 9 : (int)re.re_nsub) : v_nothing();
    regfree(&re);
    return r;
}
/* Walk all non-overlapping matches. */
typedef void (*Each)(void *ctx, const char *base, regmatch_t *m, int ng);
static void each_match(regex_t *re, const char *s, Each f, void *ctx) {
    int ng = (int)re->re_nsub > 9 ? 9 : (int)re->re_nsub;
    regmatch_t m[10];
    int pos = 0, len = (int)strlen(s);
    while (pos <= len) {
        if (regexec(re, s + pos, 10, m, pos > 0 ? REG_NOTBOL : 0) != 0) break;
        for (int i = 0; i <= 9; i++) if (m[i].rm_so >= 0) { m[i].rm_so += pos; m[i].rm_eo += pos; }
        f(ctx, s, m, ng);
        pos = m[0].rm_eo > m[0].rm_so ? (int)m[0].rm_eo : (int)m[0].rm_eo + 1;
    }
}
static void collect(void *ctx, const char *base, regmatch_t *m, int ng) {
    List *l = ctx;
    if (ng == 0) list_push(l, v_str(str_new(base + m[0].rm_so, (int)(m[0].rm_eo - m[0].rm_so))));
    else if (ng == 1) list_push(l, m[1].rm_so < 0 ? v_str(str_cstr("")) : v_str(str_new(base + m[1].rm_so, (int)(m[1].rm_eo - m[1].rm_so))));
    else {
        List *g = list_new(ng);
        for (int i = 1; i <= ng; i++)
            list_push(g, v_str(m[i].rm_so < 0 ? str_cstr("") : str_new(base + m[i].rm_so, (int)(m[i].rm_eo - m[i].rm_so))));
        list_push(l, v_obj(T_LIST, g));
    }
}
NATIVE(re_find_all) {
    need_text(argv[1], "find_all");
    regex_t re; compile(&re, argv[0]);
    List *l = list_new(0);
    Value lv = v_obj(T_LIST, l);
    each_match(&re, AS_STR(argv[1])->s, collect, l);
    regfree(&re);
    return lv;
}
typedef struct { SB b; const char *repl; int rlen; int last; } Sub;
static void substitute(void *ctx, const char *base, regmatch_t *m, int ng) {
    Sub *s = ctx;
    (void)ng;
    sb_add(&s->b, base + s->last, (int)(m[0].rm_so - s->last));
    for (int i = 0; i < s->rlen; i++) {
        if (s->repl[i] == '\\' && i + 1 < s->rlen && isdigit((unsigned char)s->repl[i + 1])) {
            int g = s->repl[++i] - '0';
            if (m[g].rm_so >= 0) sb_add(&s->b, base + m[g].rm_so, (int)(m[g].rm_eo - m[g].rm_so));
        } else sb_addc(&s->b, s->repl[i]);
    }
    s->last = (int)m[0].rm_eo;
}
NATIVE(re_replace) {
    need_text(argv[1], "replace");
    if (argv[2].t != T_STR) sage_error("re.replace() needs text to put in, not a %s", type_name(argv[2]));
    regex_t re; compile(&re, argv[0]);
    Sub s; sb_init(&s.b);
    s.repl = AS_STR(argv[2])->s; s.rlen = AS_STR(argv[2])->len; s.last = 0;
    const char *text = AS_STR(argv[1])->s;
    each_match(&re, text, substitute, &s);
    sb_add(&s.b, text + s.last, (int)strlen(text) - s.last);
    regfree(&re);
    return v_str(sb_finish(&s.b));
}
typedef struct { List *out; const char *text; int last; } Spl;
static void splitter(void *ctx, const char *base, regmatch_t *m, int ng) {
    Spl *s = ctx; (void)ng;
    if (m[0].rm_eo == m[0].rm_so) return;      /* ignore empty matches */
    list_push(s->out, v_str(str_new(base + s->last, (int)(m[0].rm_so - s->last))));
    s->last = (int)m[0].rm_eo;
}
NATIVE(re_split) {
    need_text(argv[1], "split");
    regex_t re; compile(&re, argv[0]);
    List *l = list_new(0);
    Value lv = v_obj(T_LIST, l);
    Spl s = { l, AS_STR(argv[1])->s, 0 };
    each_match(&re, s.text, splitter, &s);
    list_push(l, v_str(str_new(s.text + s.last, (int)strlen(s.text) - s.last)));
    regfree(&re);
    return lv;
}
Native re_natives[] = {
    {"test", re_test, 2, 2}, {"search", re_search, 2, 2}, {"find_all", re_find_all, 2, 2},
    {"replace", re_replace, 3, 3}, {"split", re_split, 2, 2}, {NULL, NULL, 0, 0}
};
