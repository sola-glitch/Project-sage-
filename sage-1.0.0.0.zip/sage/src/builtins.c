/* Built-in functions and methods of text, lists and dictionaries. */
#include "sage.h"
#include <ctype.h>
#include <time.h>

#define NATIVE(name) static Value name(__attribute__((unused)) int argc, __attribute__((unused)) Value *argv)

static double need_num(Value v, const char *fn) {
    if (v.t != T_NUM) sage_error("%s() needs a number, not a %s", fn, type_name(v));
    return v.u.n;
}
static Str *need_str(Value v, const char *fn) {
    if (v.t != T_STR) sage_error("%s() needs text, not a %s", fn, type_name(v));
    return AS_STR(v);
}
static Dict *need_dict(Value v, const char *fn) {
    if (v.t != T_DICT) sage_error("%s() needs a dict, not a %s", fn, type_name(v));
    return AS_DICT(v);
}
static Value mkstr(const char *s, int len) { return v_str(str_new(s, len)); }
static Value mklist(List *l) { return v_obj(T_LIST, l); }

/* ---------- sorting (stable merge sort, works with user key functions) ---------- */
static void msort(Value *it, Value *ky, Value *ti, Value *tk, int n) {
    if (n < 2) return;
    int m = n / 2, i = 0, j = m, k = 0;
    msort(it, ky, ti, tk, m);
    msort(it + m, ky + m, ti, tk, n - m);
    while (i < m && j < n) {
        if (compare_values(ky[j], ky[i]) < 0) { ti[k] = it[j]; tk[k++] = ky[j++]; }
        else { ti[k] = it[i]; tk[k++] = ky[i++]; }
    }
    while (i < m) { ti[k] = it[i]; tk[k++] = ky[i++]; }
    while (j < n) { ti[k] = it[j]; tk[k++] = ky[j++]; }
    memcpy(it, ti, sizeof(Value) * k);
    memcpy(ky, tk, sizeof(Value) * k);
}
static void sort_list(List *l, Value keyfn) {
    int n = l->len;
    if (n < 2) return;
    /* the keys live in a collector-visible list so a key function cannot lose them */
    List *volatile keylist = list_new(n);
    for (int i = 0; i < n; i++)
        list_push(keylist, keyfn.t == T_NOTHING ? l->items[i] : call_value(keyfn, 1, &l->items[i]));
    Value *ti = xmalloc(sizeof(Value) * n), *tk = xmalloc(sizeof(Value) * n);
    msort(l->items, keylist->items, ti, tk, n);
    free(ti); free(tk);
}
static List *copy_list(List *src) {
    List *r = list_new(src->len);
    for (int i = 0; i < src->len; i++) list_push(r, src->items[i]);
    return r;
}

/* ---------- global functions ---------- */
NATIVE(n_len) {
    Value v = argv[0];
    if (v.t == T_STR) return v_num(AS_STR(v)->ulen);
    if (v.t == T_LIST) return v_num(AS_LIST(v)->len);
    if (v.t == T_DICT || v.t == T_SET) return v_num(AS_DICT(v)->len);
    if (v.t == T_TUPLE) return v_num(AS_LIST(v)->len);
    if (v.t == T_INST) { Value r; if (inst_dunder(v, "__len__", 0, NULL, &r)) return r; }
    sage_error("len() does not work on a %s", type_name(v));
}
NATIVE(n_priv_read) {
    if (argv[0].t != T_STR) sage_error("open() needs a file name in quotes, not a %s", type_name(argv[0]));
    char *src = read_file(AS_STR(argv[0])->s);
    if (!src) sage_error("cannot open file '%s'", AS_STR(argv[0])->s);
    Str *r = str_new(src, (int)strlen(src));
    free(src);
    return v_str(r);
}
NATIVE(n_priv_write) {
    if (argv[0].t != T_STR || argv[1].t != T_STR) sage_error("cannot write: a file name and text are needed");
    FILE *f = fopen(AS_STR(argv[0])->s, truthy(argv[2]) ? "ab" : "wb");
    if (!f) sage_error("cannot write to file '%s'", AS_STR(argv[0])->s);
    fwrite(AS_STR(argv[1])->s, 1, (size_t)AS_STR(argv[1])->len, f);
    fclose(f);
    return v_nothing();
}
NATIVE(n_str) { return v_str(to_str(argv[0])); }
NATIVE(n_num) {
    Value v = argv[0];
    if (v.t == T_NUM) return v;
    if (v.t == T_BOOL) return v_num(v.u.b ? 1 : 0);
    if (v.t == T_STR) {
        const char *s = AS_STR(v)->s;
        char *end;
        while (isspace((unsigned char)*s)) s++;
        double d = strtod(s, &end);
        while (isspace((unsigned char)*end)) end++;
        if (end == s || *end) sage_error("cannot turn %s into a number", repr_str(v)->s);
        return v_num(d);
    }
    sage_error("cannot turn a %s into a number", type_name(v));
}
NATIVE(n_int) { return v_num(trunc(n_num(1, argv).u.n)); }
NATIVE(n_bool) { return v_bool(truthy(argv[0])); }
NATIVE(n_list) { return mklist(copy_list(AS_LIST(iter_items(argv[0])))); }
NATIVE(n_tuple) {
    if (argc == 0) return v_obj(T_TUPLE, list_new(0));
    return v_obj(T_TUPLE, copy_list(AS_LIST(iter_items(argv[0]))));
}
NATIVE(n_set) {
    Dict *d = dict_new();
    if (argc) { List *l = AS_LIST(iter_items(argv[0])); for (int i = 0; i < l->len; i++) dict_set(d, l->items[i], v_bool(true)); }
    return v_obj(T_SET, d);
}
static Dict *self_set(Value v) { return AS_DICT(v); }
static Dict *other_set(Value v) {
    if (v.t == T_SET) return AS_DICT(v);
    Dict *d = dict_new();
    List *l = AS_LIST(iter_items(v));
    for (int i = 0; i < l->len; i++) dict_set(d, l->items[i], v_bool(true));
    return d;
}
NATIVE(s_add) { dict_set(self_set(argv[0]), argv[1], v_bool(true)); return v_nothing(); }
NATIVE(s_remove) {
    if (!dict_del(self_set(argv[0]), argv[1])) sage_error("key %s not found", repr_str(argv[1])->s);
    return v_nothing();
}
NATIVE(s_discard) { dict_del(self_set(argv[0]), argv[1]); return v_nothing(); }
NATIVE(s_has) { return v_bool(dict_get(self_set(argv[0]), argv[1], NULL)); }
NATIVE(s_copy) { Dict *d = dict_new(), *s = self_set(argv[0]); DICT_EACH(s, i) dict_set(d, s->e[i].k, v_bool(true)); return v_obj(T_SET, d); }
NATIVE(s_clear) {
    Dict *s = self_set(argv[0]);
    List *keys = AS_LIST(iter_items(argv[0]));
    for (int i = 0; i < keys->len; i++) dict_del(s, keys->items[i]);
    return v_nothing();
}
NATIVE(s_union) { Dict *r = dict_new(), *a = self_set(argv[0]), *b = other_set(argv[1]); DICT_EACH(a, i) dict_set(r, a->e[i].k, v_bool(true)); DICT_EACH(b, i) dict_set(r, b->e[i].k, v_bool(true)); return v_obj(T_SET, r); }
NATIVE(s_inter) { Dict *r = dict_new(), *a = self_set(argv[0]), *b = other_set(argv[1]); DICT_EACH(a, i) if (dict_get(b, a->e[i].k, NULL)) dict_set(r, a->e[i].k, v_bool(true)); return v_obj(T_SET, r); }
NATIVE(s_diff) { Dict *r = dict_new(), *a = self_set(argv[0]), *b = other_set(argv[1]); DICT_EACH(a, i) if (!dict_get(b, a->e[i].k, NULL)) dict_set(r, a->e[i].k, v_bool(true)); return v_obj(T_SET, r); }
NATIVE(s_subset) { Dict *a = self_set(argv[0]), *b = other_set(argv[1]); DICT_EACH(a, i) if (!dict_get(b, a->e[i].k, NULL)) return v_bool(false); return v_bool(true); }
NATIVE(s_superset) { Dict *a = self_set(argv[0]), *b = other_set(argv[1]); DICT_EACH(b, i) if (!dict_get(a, b->e[i].k, NULL)) return v_bool(false); return v_bool(true); }
NATIVE(s_list) { return mklist(copy_list(AS_LIST(iter_items(argv[0])))); }
NATIVE(t_count) { int c = 0; List *l = AS_LIST(argv[0]); for (int i = 0; i < l->len; i++) if (values_equal(l->items[i], argv[1])) c++; return v_num(c); }
NATIVE(t_index) { List *l = AS_LIST(argv[0]); for (int i = 0; i < l->len; i++) if (values_equal(l->items[i], argv[1])) return v_num(i); sage_error("%s is not in the tuple", repr_str(argv[1])->s); }
NATIVE(n_getattr) {
    if (argv[1].t != T_STR) sage_error("getattr() needs a name in quotes");
    if (argc == 3) {
        if (argv[0].t != T_INST && argv[0].t != T_CLASS) return argv[2];
        if (argv[0].t == T_INST && !AS_INST(argv[0])->extra) {
            Value t;
            if (!dict_get(AS_INST(argv[0])->fields, argv[1], &t) && !class_find(AS_INST(argv[0])->cls, AS_STR(argv[1]), &t)) return argv[2];
        }
    }
    return sage_getattr(argv[0], AS_STR(argv[1]));
}
NATIVE(n_import_module) {
    if (argv[0].t != T_STR) sage_error("import_module() needs a module name in quotes");
    return sage_import(AS_STR(argv[0]));
}
NATIVE(n_dir) {
    List *r = list_new(0);
    Value v = argv[0];
    if (v.t == T_INST && AS_INST(v)->extra) {
        Env *e = AS_INST(v)->extra;
        for (int i = 0; i < e->n; i++) if (e->vals[i].t != T_ALIAS && e->names[i]->s[0] != '_') list_push(r, v_str(e->names[i]));
    } else if (v.t == T_INST) {
        Dict *f = AS_INST(v)->fields;
        DICT_EACH(f, i) list_push(r, f->e[i].k);
        for (Class *c = AS_INST(v)->cls; c; c = c->parent) {
            Dict *m = c->methods;
            DICT_EACH(m, i) list_push(r, m->e[i].k);
        }
    }
    return mklist(r);
}
NATIVE(n_add_path) {
    if (argv[0].t != T_STR) sage_error("_add_path() needs a folder name in quotes");
    add_search_dir(AS_STR(argv[0])->len ? AS_STR(argv[0])->s : ".");
    return v_nothing();
}
NATIVE(n_type) { return v_str(str_cstr(type_name(argv[0]))); }
NATIVE(n_isinstance) {
    if (argv[1].t != T_CLASS) sage_error("isinstance() needs a class as its second argument");
    return v_bool(argv[0].t == T_INST && class_is(AS_INST(argv[0])->cls, AS_CLASS(argv[1])));
}
NATIVE(n_hasattr) {
    Str *name = need_str(argv[1], "hasattr");
    if (argv[0].t != T_INST) return v_bool(false);
    Value tmp;
    return v_bool(dict_get(AS_INST(argv[0])->fields, v_str(name), &tmp) || class_find(AS_INST(argv[0])->cls, name, &tmp));
}
Value native_range(int argc, Value *argv) {
    double a[3] = {0, 0, 0};
    for (int i = 0; i < argc; i++) a[i] = need_num(argv[i], "range");
    double start = 0, stop, step = 1;
    if (argc == 1) stop = a[0]; else { start = a[0]; stop = a[1]; if (argc == 3) step = a[2]; }
    if (step == 0) sage_error("range() step cannot be zero");
    double count = ceil((stop - start) / step);
    if (count < 0) count = 0;
    if (count > 50000000) sage_error("range() is too large to build as a list; use it directly in a 'for' loop");
    List *l = list_new((int)count);
    for (int i = 0; i < (int)count; i++) list_push(l, v_num(start + i * step));
    return mklist(l);
}
NATIVE(n_print) {
    for (int i = 0; i < argc; i++) {
        Str *s = to_str(argv[i]);
        if (i) fputc(' ', stdout);
        fwrite(s->s, 1, s->len, stdout);
    }
    fputc('\n', stdout);
    return v_nothing();
}
NATIVE(n_ask) {
    if (argc > 0) { Str *p = to_str(argv[0]); fwrite(p->s, 1, p->len, stdout); }
    fflush(stdout);
    char buf[4096];
    if (!fgets(buf, sizeof buf, stdin)) return v_nothing();
    size_t n = strlen(buf);
    while (n && (buf[n - 1] == '\n' || buf[n - 1] == '\r')) n--;
    return mkstr(buf, (int)n);
}
NATIVE(n_gc) { return v_num((double)gc_collect()); }
NATIVE(n_abs) { return v_num(fabs(need_num(argv[0], "abs"))); }

static Value extreme(int argc, Value *argv, int sign, const char *fn) {
    List *src = NULL;
    Value tmp;
    if (argc == 1) { tmp = iter_items(argv[0]); src = AS_LIST(tmp); }
    int n = src ? src->len : argc;
    if (n == 0) sage_error("%s() needs at least one value", fn);
    Value best = src ? src->items[0] : argv[0];
    for (int i = 1; i < n; i++) {
        Value v = src ? src->items[i] : argv[i];
        if (compare_values(v, best) * sign > 0) best = v;
    }
    return best;
}
NATIVE(n_min) { return extreme(argc, argv, -1, "min"); }
NATIVE(n_max) { return extreme(argc, argv, 1, "max"); }
NATIVE(n_sum) {
    List *l = AS_LIST(iter_items(argv[0]));
    double t = argc > 1 ? need_num(argv[1], "sum") : 0;
    for (int i = 0; i < l->len; i++) t += need_num(l->items[i], "sum");
    return v_num(t);
}
NATIVE(n_round) {
    double x = need_num(argv[0], "round");
    if (argc < 2) return v_num(round(x));
    double p = pow(10, need_num(argv[1], "round"));
    return v_num(round(x * p) / p);
}
#define MATH1(fname, cfn) NATIVE(fname) { return v_num(cfn(need_num(argv[0], #cfn))); }
MATH1(n_floor, floor) MATH1(n_ceil, ceil) MATH1(n_sqrt, sqrt) MATH1(n_sin, sin)
MATH1(n_cos, cos) MATH1(n_tan, tan) MATH1(n_log, log) MATH1(n_exp, exp)
NATIVE(n_pow) { return v_num(pow(need_num(argv[0], "pow"), need_num(argv[1], "pow"))); }

static unsigned long long rng = 88172645463325252ULL;
static double rnd01(void) {
    rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17;
    return (double)(rng >> 11) * (1.0 / 9007199254740992.0);
}
double sage_random(void) { return rnd01(); }
void sage_seed(double n) { rng = ((unsigned long long)n * 2654435761ULL) | 1ULL; }
NATIVE(n_random) { return v_num(rnd01()); }
NATIVE(n_randint) {
    double a = need_num(argv[0], "randint"), b = need_num(argv[1], "randint");
    if (b < a) sage_error("randint() needs the first number to be the smaller one");
    return v_num(a + floor(rnd01() * (b - a + 1)));
}
NATIVE(n_seed) { rng = ((unsigned long long)need_num(argv[0], "seed") * 2654435761ULL) | 1ULL; return v_nothing(); }
NATIVE(n_time) {
    struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts);
    return v_num((double)ts.tv_sec + ts.tv_nsec * 1e-9);
}
NATIVE(n_clock) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return v_num((double)ts.tv_sec + ts.tv_nsec * 1e-9);
}
NATIVE(n_exit) { fflush(stdout); exit(argc ? (int)need_num(argv[0], "exit") : 0); }

NATIVE(n_sorted) {
    List *r = copy_list(AS_LIST(iter_items(argv[0])));
    sort_list(r, argc > 1 ? argv[1] : v_nothing());
    return mklist(r);
}
NATIVE(n_reversed) {
    List *src = AS_LIST(iter_items(argv[0])), *r = list_new(src->len);
    for (int i = src->len - 1; i >= 0; i--) list_push(r, src->items[i]);
    return mklist(r);
}
NATIVE(n_map) {
    List *src = AS_LIST(iter_items(argv[0])), *r = list_new(src->len);
    for (int i = 0; i < src->len; i++) list_push(r, call_value(argv[1], 1, &src->items[i]));
    return mklist(r);
}
NATIVE(n_filter) {
    List *src = AS_LIST(iter_items(argv[0])), *r = list_new(0);
    for (int i = 0; i < src->len; i++)
        if (truthy(call_value(argv[1], 1, &src->items[i]))) list_push(r, src->items[i]);
    return mklist(r);
}
NATIVE(n_reduce) {
    List *src = AS_LIST(iter_items(argv[0]));
    int i = 0;
    Value acc;
    if (argc > 2) acc = argv[2];
    else {
        if (src->len == 0) sage_error("reduce() of an empty list needs a starting value");
        acc = src->items[i++];
    }
    for (; i < src->len; i++) {
        Value args[2] = { acc, src->items[i] };
        acc = call_value(argv[1], 2, args);
    }
    return acc;
}
NATIVE(n_each) {
    List *src = AS_LIST(iter_items(argv[0]));
    for (int i = 0; i < src->len; i++) call_value(argv[1], 1, &src->items[i]);
    return v_nothing();
}
NATIVE(n_any) {
    List *l = AS_LIST(iter_items(argv[0]));
    for (int i = 0; i < l->len; i++) if (truthy(l->items[i])) return v_bool(true);
    return v_bool(false);
}
NATIVE(n_all) {
    List *l = AS_LIST(iter_items(argv[0]));
    for (int i = 0; i < l->len; i++) if (!truthy(l->items[i])) return v_bool(false);
    return v_bool(true);
}
NATIVE(n_zip) {
    List *src[16];
    int n = argc > 16 ? 16 : argc, len = -1;
    for (int i = 0; i < n; i++) {
        src[i] = AS_LIST(iter_items(argv[i]));
        if (len < 0 || src[i]->len < len) len = src[i]->len;
    }
    List *r = list_new(len);
    for (int j = 0; j < len; j++) {
        List *row = list_new(n);
        for (int i = 0; i < n; i++) list_push(row, src[i]->items[j]);
        list_push(r, v_obj(T_TUPLE, row));
    }
    return mklist(r);
}
NATIVE(n_enumerate) {
    List *src = AS_LIST(iter_items(argv[0])), *r = list_new(src->len);
    for (int i = 0; i < src->len; i++) {
        List *pair = list_new(2);
        list_push(pair, v_num(i)); list_push(pair, src->items[i]);
        list_push(r, v_obj(T_TUPLE, pair));
    }
    return mklist(r);
}
NATIVE(n_keys) {
    Dict *d = need_dict(argv[0], "keys");
    List *r = list_new(d->len);
    DICT_EACH(d, i) list_push(r, d->e[i].k);
    return mklist(r);
}
NATIVE(n_values) {
    Dict *d = need_dict(argv[0], "values");
    List *r = list_new(d->len);
    DICT_EACH(d, i) list_push(r, d->e[i].v);
    return mklist(r);
}
NATIVE(n_items) {
    Dict *d = need_dict(argv[0], "items");
    List *r = list_new(d->len);
    DICT_EACH(d, i) {
        List *pair = list_new(2);
        list_push(pair, d->e[i].k); list_push(pair, d->e[i].v);
        list_push(r, v_obj(T_TUPLE, pair));
    }
    return mklist(r);
}
NATIVE(n_fixed) {
    char buf[512];
    int digits = (int)need_num(argv[1], "fixed");
    if (digits < 0) digits = 0;
    if (digits > 30) digits = 30;
    snprintf(buf, sizeof buf, "%.*f", digits, need_num(argv[0], "fixed"));
    return mkstr(buf, (int)strlen(buf));
}
NATIVE(n_chr) {
    unsigned c = (unsigned)need_num(argv[0], "chr");
    char b[5]; int n = 0;
    if (c < 0x80) b[n++] = (char)c;
    else if (c < 0x800) { b[n++] = (char)(0xC0 | (c >> 6)); b[n++] = (char)(0x80 | (c & 0x3F)); }
    else if (c < 0x10000) { b[n++] = (char)(0xE0 | (c >> 12)); b[n++] = (char)(0x80 | ((c >> 6) & 0x3F)); b[n++] = (char)(0x80 | (c & 0x3F)); }
    else { b[n++] = (char)(0xF0 | (c >> 18)); b[n++] = (char)(0x80 | ((c >> 12) & 0x3F)); b[n++] = (char)(0x80 | ((c >> 6) & 0x3F)); b[n++] = (char)(0x80 | (c & 0x3F)); }
    return mkstr(b, n);
}
NATIVE(n_ord) {
    Str *s = need_str(argv[0], "ord");
    if (s->len == 0) sage_error("ord() needs a non-empty text");
    unsigned char c = (unsigned char)s->s[0];
    if (c < 0x80 || s->len < 2) return v_num(c);
    int n = (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : 4;
    unsigned cp = c & (0xFF >> (n + 1));
    for (int i = 1; i < n && i < s->len; i++) cp = (cp << 6) | ((unsigned char)s->s[i] & 0x3F);
    return v_num(cp);
}
NATIVE(n_read_file) {
    Str *p = need_str(argv[0], "read_file");
    char *src = read_file(p->s);
    if (!src) sage_error("cannot open file '%s'", p->s);
    Str *r = str_cstr(src);
    free(src);
    return v_str(r);
}
static Value write_to(Value *argv, const char *mode, const char *fn) {
    Str *p = need_str(argv[0], fn), *t = to_str(argv[1]);
    FILE *f = fopen(p->s, mode);
    if (!f) sage_error("cannot write to file '%s'", p->s);
    fwrite(t->s, 1, t->len, f);
    fclose(f);
    return v_nothing();
}
NATIVE(n_write_file) { return write_to(argv, "wb", "write_file"); }
NATIVE(n_append_file) { return write_to(argv, "ab", "append_file"); }
NATIVE(n_file_exists) {
    FILE *f = fopen(need_str(argv[0], "file_exists")->s, "rb");
    if (f) fclose(f);
    return v_bool(f != NULL);
}

/* ---------- text methods (argv[0] is the text) ---------- */
NATIVE(s_upper) { return v_str(uc_convert(AS_STR(argv[0]), 0)); }
NATIVE(s_lower) { return v_str(uc_convert(AS_STR(argv[0]), 1)); }
NATIVE(s_strip) {
    Str *s = AS_STR(argv[0]);
    int a = 0, b = s->len;
    while (a < b && isspace((unsigned char)s->s[a])) a++;
    while (b > a && isspace((unsigned char)s->s[b - 1])) b--;
    return mkstr(s->s + a, b - a);
}
NATIVE(s_split) {
    Str *s = AS_STR(argv[0]);
    List *r = list_new(0);
    const char *p = s->s;
    if (argc < 2) {
        while (*p) {
            while (isspace((unsigned char)*p)) p++;
            if (!*p) break;
            const char *st = p;
            while (*p && !isspace((unsigned char)*p)) p++;
            list_push(r, mkstr(st, (int)(p - st)));
        }
    } else {
        Str *sep = need_str(argv[1], "split");
        if (sep->len == 0) sage_error("split() needs a separator that is not empty");
        for (;;) {
            const char *q = strstr(p, sep->s);
            if (!q) { list_push(r, mkstr(p, (int)strlen(p))); break; }
            list_push(r, mkstr(p, (int)(q - p)));
            p = q + sep->len;
        }
    }
    return mklist(r);
}
NATIVE(s_replace) {
    Str *s = AS_STR(argv[0]), *from = need_str(argv[1], "replace"), *to = need_str(argv[2], "replace");
    if (from->len == 0) sage_error("replace() needs text to look for");
    SB sb; sb_init(&sb);
    const char *p = s->s;
    for (;;) {
        const char *q = strstr(p, from->s);
        if (!q) { sb_adds(&sb, p); break; }
        sb_add(&sb, p, (int)(q - p));
        sb_add(&sb, to->s, to->len);
        p = q + from->len;
    }
    return v_str(sb_finish(&sb));
}
NATIVE(s_starts_with) {
    Str *s = AS_STR(argv[0]), *x = need_str(argv[1], "starts_with");
    return v_bool(x->len <= s->len && memcmp(s->s, x->s, x->len) == 0);
}
NATIVE(s_ends_with) {
    Str *s = AS_STR(argv[0]), *x = need_str(argv[1], "ends_with");
    return v_bool(x->len <= s->len && memcmp(s->s + s->len - x->len, x->s, x->len) == 0);
}
NATIVE(s_find) {
    Str *s = AS_STR(argv[0]), *x = need_str(argv[1], "find");
    const char *q = strstr(s->s, x->s);
    if (!q) return v_num(-1);
    int chars = 0;                               /* report a character index, not a byte offset */
    for (const char *p = s->s; p < q; p += u8len((unsigned char)*p)) chars++;
    return v_num(chars);
}
NATIVE(s_contains) { return v_bool(strstr(AS_STR(argv[0])->s, need_str(argv[1], "contains")->s) != NULL); }
NATIVE(s_count) {
    Str *s = AS_STR(argv[0]), *x = need_str(argv[1], "count");
    if (x->len == 0) sage_error("count() needs text to look for");
    int c = 0;
    for (const char *p = s->s; (p = strstr(p, x->s)); p += x->len) c++;
    return v_num(c);
}
NATIVE(s_join) {
    Str *sep = AS_STR(argv[0]);
    List *l = AS_LIST(iter_items(argv[1]));
    SB sb; sb_init(&sb);
    for (int i = 0; i < l->len; i++) {
        if (i) sb_add(&sb, sep->s, sep->len);
        Str *x = to_str(l->items[i]);
        sb_add(&sb, x->s, x->len);
    }
    return v_str(sb_finish(&sb));
}
NATIVE(s_title) { return v_str(uc_convert(AS_STR(argv[0]), 2)); }

/* ---------- list methods (argv[0] is the list) ---------- */
NATIVE(l_add) { list_push(AS_LIST(argv[0]), argv[1]); return v_nothing(); }
NATIVE(l_pop) {
    List *l = AS_LIST(argv[0]);
    if (l->len == 0) sage_error("cannot pop from an empty list");
    int i = l->len - 1;
    if (argc > 1) {
        double d = need_num(argv[1], "pop");
        long k = (long)d;
        if (k < 0) k += l->len;
        if (k < 0 || k >= l->len) sage_error("pop index out of range");
        i = (int)k;
    }
    Value v = l->items[i];
    memmove(l->items + i, l->items + i + 1, sizeof(Value) * (l->len - i - 1));
    l->len--;
    return v;
}
NATIVE(l_insert) {
    List *l = AS_LIST(argv[0]);
    long i = (long)need_num(argv[1], "insert");
    if (i < 0) i += l->len;
    if (i < 0) i = 0;
    if (i > l->len) i = l->len;
    list_push(l, v_nothing());
    memmove(l->items + i + 1, l->items + i, sizeof(Value) * (l->len - 1 - i));
    l->items[i] = argv[2];
    return v_nothing();
}
static int list_index_of(List *l, Value v) {
    for (int i = 0; i < l->len; i++) if (values_equal(l->items[i], v)) return i;
    return -1;
}
NATIVE(l_remove) {
    List *l = AS_LIST(argv[0]);
    int i = list_index_of(l, argv[1]);
    if (i < 0) sage_error("remove(): %s is not in the list", repr_str(argv[1])->s);
    memmove(l->items + i, l->items + i + 1, sizeof(Value) * (l->len - i - 1));
    l->len--;
    return v_nothing();
}
NATIVE(l_index) { return v_num(list_index_of(AS_LIST(argv[0]), argv[1])); }
NATIVE(l_contains) { return v_bool(list_index_of(AS_LIST(argv[0]), argv[1]) >= 0); }
NATIVE(l_count) {
    List *l = AS_LIST(argv[0]); int c = 0;
    for (int i = 0; i < l->len; i++) if (values_equal(l->items[i], argv[1])) c++;
    return v_num(c);
}
NATIVE(l_sort) { sort_list(AS_LIST(argv[0]), argc > 1 ? argv[1] : v_nothing()); return v_nothing(); }
NATIVE(l_reverse) {
    List *l = AS_LIST(argv[0]);
    for (int i = 0, j = l->len - 1; i < j; i++, j--) { Value t = l->items[i]; l->items[i] = l->items[j]; l->items[j] = t; }
    return v_nothing();
}
NATIVE(l_join) { Value a[2] = { argc > 1 ? argv[1] : mkstr("", 0), argv[0] }; return s_join(2, a); }
NATIVE(l_copy) { return mklist(copy_list(AS_LIST(argv[0]))); }
NATIVE(l_clear) { AS_LIST(argv[0])->len = 0; return v_nothing(); }
NATIVE(l_first) { List *l = AS_LIST(argv[0]); return l->len ? l->items[0] : v_nothing(); }
NATIVE(l_last) { List *l = AS_LIST(argv[0]); return l->len ? l->items[l->len - 1] : v_nothing(); }
NATIVE(l_extend) {
    List *l = AS_LIST(argv[0]), *o = AS_LIST(iter_items(argv[1]));
    int n = o->len;
    for (int i = 0; i < n; i++) list_push(l, o->items[i]);
    return v_nothing();
}

/* ---------- dict methods (argv[0] is the dict) ---------- */
NATIVE(d_get) {
    Value v;
    if (dict_get(AS_DICT(argv[0]), argv[1], &v)) return v;
    return argc > 2 ? argv[2] : v_nothing();
}
NATIVE(d_has) { return v_bool(dict_get(AS_DICT(argv[0]), argv[1], NULL)); }
NATIVE(d_remove) { return v_bool(dict_del(AS_DICT(argv[0]), argv[1])); }
NATIVE(d_update) {
    Dict *d = AS_DICT(argv[0]), *o = need_dict(argv[1], "update");
    DICT_EACH(o, i) dict_set(d, o->e[i].k, o->e[i].v);
    return v_nothing();
}
NATIVE(d_copy) {
    Dict *o = AS_DICT(argv[0]), *d = dict_new();
    DICT_EACH(o, i) dict_set(d, o->e[i].k, o->e[i].v);
    return v_obj(T_DICT, d);
}
NATIVE(d_clear) {
    Dict *d = AS_DICT(argv[0]);
    d->len = d->used = 0;
    for (int i = 0; i < d->icap; i++) d->idx[i] = -1;
    return v_nothing();
}

/* ---------- tables ---------- */
static Native global_table[] = {
    {"_read_file", n_priv_read, 1, 1}, {"_write_file", n_priv_write, 3, 3}, {"_add_path", n_add_path, 1, 1}, {"getattr", n_getattr, 2, 3}, {"import_module", n_import_module, 1, 1}, {"dir", n_dir, 1, 1}, {"tuple", n_tuple, 0, 1}, {"set", n_set, 0, 1}, {"len", n_len, 1, 1}, {"str", n_str, 1, 1}, {"num", n_num, 1, 1}, {"int", n_int, 1, 1},
    {"bool", n_bool, 1, 1}, {"list", n_list, 1, 1}, {"type", n_type, 1, 1},
    {"isinstance", n_isinstance, 2, 2}, {"hasattr", n_hasattr, 2, 2}, {"range", native_range, 1, 3},
    {"print", n_print, 0, -1}, {"gc", n_gc, 0, 0}, {"ask", n_ask, 0, 1}, {"abs", n_abs, 1, 1}, {"min", n_min, 1, -1},
    {"max", n_max, 1, -1}, {"sum", n_sum, 1, 2}, {"round", n_round, 1, 2}, {"floor", n_floor, 1, 1},
    {"ceil", n_ceil, 1, 1}, {"sqrt", n_sqrt, 1, 1}, {"sin", n_sin, 1, 1}, {"cos", n_cos, 1, 1},
    {"tan", n_tan, 1, 1}, {"log", n_log, 1, 1}, {"exp", n_exp, 1, 1}, {"pow", n_pow, 2, 2},
    {"random", n_random, 0, 0}, {"randint", n_randint, 2, 2}, {"seed", n_seed, 1, 1},
    {"time", n_time, 0, 0}, {"clock", n_clock, 0, 0}, {"exit", n_exit, 0, 1},
    {"sorted", n_sorted, 1, 2}, {"reversed", n_reversed, 1, 1}, {"map", n_map, 2, 2},
    {"filter", n_filter, 2, 2}, {"reduce", n_reduce, 2, 3}, {"each", n_each, 2, 2},
    {"any", n_any, 1, 1}, {"all", n_all, 1, 1}, {"zip", n_zip, 1, 16}, {"enumerate", n_enumerate, 1, 1},
    {"keys", n_keys, 1, 1}, {"values", n_values, 1, 1}, {"items", n_items, 1, 1},
    {"fixed", n_fixed, 2, 2}, {"chr", n_chr, 1, 1}, {"ord", n_ord, 1, 1},
    {"read_file", n_read_file, 1, 1}, {"write_file", n_write_file, 2, 2},
    {"append_file", n_append_file, 2, 2}, {"file_exists", n_file_exists, 1, 1},
    {NULL, NULL, 0, 0}
};

/* min/max here exclude the receiver */
static Native str_methods[] = {
    {"upper", s_upper, 0, 0}, {"lower", s_lower, 0, 0}, {"strip", s_strip, 0, 0},
    {"split", s_split, 0, 1}, {"replace", s_replace, 2, 2}, {"starts_with", s_starts_with, 1, 1},
    {"ends_with", s_ends_with, 1, 1}, {"find", s_find, 1, 1}, {"contains", s_contains, 1, 1},
    {"count", s_count, 1, 1}, {"join", s_join, 1, 1}, {"title", s_title, 0, 0},
    {NULL, NULL, 0, 0}
};
static Native list_methods[] = {
    {"add", l_add, 1, 1}, {"push", l_add, 1, 1}, {"pop", l_pop, 0, 1}, {"insert", l_insert, 2, 2},
    {"remove", l_remove, 1, 1}, {"index", l_index, 1, 1}, {"contains", l_contains, 1, 1},
    {"count", l_count, 1, 1}, {"sort", l_sort, 0, 1}, {"reverse", l_reverse, 0, 0},
    {"map", n_map, 1, 1}, {"filter", n_filter, 1, 1}, {"reduce", n_reduce, 1, 2}, {"each", n_each, 1, 1},
    {"join", l_join, 0, 1}, {"copy", l_copy, 0, 0}, {"clear", l_clear, 0, 0},
    {"first", l_first, 0, 0}, {"last", l_last, 0, 0}, {"extend", l_extend, 1, 1},
    {NULL, NULL, 0, 0}
};
static Native tuple_methods[] = {
    {"count", t_count, 1, 1}, {"index", t_index, 1, 1}, {"contains", t_count, 1, 1}, {NULL, NULL, 0, 0}
};
static Native set_methods[] = {
    {"add", s_add, 1, 1}, {"remove", s_remove, 1, 1}, {"discard", s_discard, 1, 1}, {"has", s_has, 1, 1},
    {"contains", s_has, 1, 1}, {"copy", s_copy, 0, 0}, {"clear", s_clear, 0, 0}, {"union", s_union, 1, 1},
    {"intersection", s_inter, 1, 1}, {"difference", s_diff, 1, 1}, {"is_subset", s_subset, 1, 1},
    {"is_superset", s_superset, 1, 1}, {"to_list", s_list, 0, 0}, {NULL, NULL, 0, 0}
};
static Native dict_methods[] = {
    {"get", d_get, 1, 2}, {"has", d_has, 1, 1}, {"remove", d_remove, 1, 1}, {"keys", n_keys, 0, 0},
    {"values", n_values, 0, 0}, {"items", n_items, 0, 0}, {"update", d_update, 1, 1},
    {"copy", d_copy, 0, 0}, {"clear", d_clear, 0, 0},
    {NULL, NULL, 0, 0}
};

Native *find_method(Type t, Str *name) {
    Native *tab = t == T_STR ? str_methods : t == T_LIST ? list_methods : t == T_TUPLE ? tuple_methods : t == T_SET ? set_methods : dict_methods;
    for (; tab->name; tab++)
        if (strcmp(tab->name, name->s) == 0) return tab;
    return NULL;
}

void register_builtins(void) {
    rng ^= (unsigned long long)time(NULL) * 0x9E3779B97F4A7C15ULL;
    if (!rng) rng = 1;
    for (Native *n = global_table; n->name; n++)
        env_define(builtins, intern(n->name, (int)strlen(n->name)), v_obj(T_NATIVE, n));
}
