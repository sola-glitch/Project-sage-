/* Sage - a multi-paradigm, plain-English programming language.
 * Shared declarations for the interpreter. */
#ifndef SAGE_H
#define SAGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stdbool.h>
#include <setjmp.h>
#include <math.h>

#define SAGE_VERSION "1.0.0.0"
#define MAX_CALL_DEPTH 2500

/* ---------- values ---------- */
typedef enum {
    T_NOTHING, T_BOOL, T_NUM, T_STR, T_LIST, T_DICT,
    T_FUNC, T_NATIVE, T_CLASS, T_INST, T_BOUND,
    T_TUPLE, T_SET,    /* tuple: a fixed list; set: dict keys only */
    T_ALIAS            /* internal: marks a 'global' / 'nonlocal' name inside a scope */
} Type;

typedef struct Value {
    Type t;
    union { bool b; double n; void *p; } u;
} Value;

typedef struct Str  { int len, ulen; unsigned hash; char *s; } Str;   /* len = bytes, ulen = characters */
typedef struct List { int len, cap; Value *items; } List;
typedef struct Entry { Value k, v; bool live; } Entry;
typedef struct Dict { int len, used, cap; Entry *e; int *idx; int icap; } Dict;

typedef struct Node Node;
typedef struct Env Env;
typedef struct Class Class;

struct Env { Env *parent; int n, cap; Str **names; Value *vals; };
typedef struct Func { Node *def; Env *closure; Class *home; } Func;
typedef Value (*NativeFn)(int argc, Value *argv);
typedef struct Native { const char *name; NativeFn fn; int min, max; } Native;
struct Class { Str *name; Class *parent; Dict *methods; };
typedef struct Inst { Class *cls; Dict *fields; Env *extra; } Inst;   /* extra: scope of a module */
typedef struct Bound { Value self; Value fn; } Bound;

static inline Value v_nothing(void) { Value v; v.t = T_NOTHING; v.u.n = 0; return v; }
static inline Value v_bool(bool b)  { Value v; v.t = T_BOOL; v.u.n = 0; v.u.b = b; return v; }
static inline Value v_num(double n) { Value v; v.t = T_NUM; v.u.n = n; return v; }
static inline Value v_obj(Type t, void *p) { Value v; v.t = t; v.u.p = p; return v; }
#define v_str(s) v_obj(T_STR, (s))

#define AS_STR(v)    ((Str *)(v).u.p)
#define AS_LIST(v)   ((List *)(v).u.p)
#define AS_DICT(v)   ((Dict *)(v).u.p)
#define AS_FUNC(v)   ((Func *)(v).u.p)
#define AS_NATIVE(v) ((Native *)(v).u.p)
#define AS_CLASS(v)  ((Class *)(v).u.p)
#define AS_INST(v)   ((Inst *)(v).u.p)
#define AS_BOUND(v)  ((Bound *)(v).u.p)

/* ---------- AST ---------- */
typedef enum {
    OP_NONE = 0, OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_IDIV, OP_MOD, OP_POW,
    OP_EQ, OP_NE, OP_LT, OP_GT, OP_LE, OP_GE, OP_IN, OP_NOTIN, OP_UNION, OP_INTER
} BinOp;

typedef enum {
    N_LIT, N_VAR, N_LIST, N_DICT, N_BIN, N_AND, N_OR, N_NOT, N_NEG, N_CALL,
    N_INDEX, N_SLICE, N_ATTR, N_LAMBDA, N_TERN, N_COMP, N_FSTR, N_SUPER,
    N_BLOCK, N_SAY, N_LET, N_ASSIGN, N_IF, N_WHILE, N_FOR, N_REPEAT, N_DEF,
    N_CLASS, N_RETURN, N_BREAK, N_CONTINUE, N_PASS, N_TRY, N_RAISE, N_USE,
    N_ASSERT, N_EXPR, N_SPREAD, N_KWARG, N_KWSPREAD, N_UNPACK, N_GLOBAL, N_IMPORT, N_WITH, N_TUPLE, N_SETLIT
} NodeKind;

struct Node {
    NodeKind kind;
    int line;
    int op;                    /* BinOp, or required-param count for defs */
    Node *a, *b, *c;
    Node **kids;  int nkids;
    Node **kids2; int nkids2;  /* dict values / if-blocks / param defaults */
    Str *name;
    int file;                  /* index into file_names (0 = main script) */
    Value val;
    Str **params; int nparams;
    Str *rest, *kwrest;        /* *args and **kwargs parameter names */
    int npos;                  /* parameters that can be given positionally */
};

/* ---------- errors ---------- */
typedef struct Handler { jmp_buf jb; struct Handler *prev; int depth; } Handler;
extern Handler *handlers;
extern Value exc_value;
extern int cur_line, exc_line, call_depth;
extern int cur_file, exc_file, parse_file;
extern char *file_names[];
int register_file(const char *path);
void sage_throw(Value v) __attribute__((noreturn));
void sage_error(const char *fmt, ...) __attribute__((noreturn, format(printf, 1, 2)));

/* ---------- value.c ---------- */
typedef struct SB { char *s; int len, cap; } SB;
void sb_init(SB *b);
void sb_add(SB *b, const char *s, int n);
void sb_addc(SB *b, char c);
void sb_adds(SB *b, const char *s);
Str *sb_finish(SB *b);

void *xmalloc(size_t n);
void *xrealloc(void *p, size_t n);
Str *str_new(const char *s, int len);
Str *str_cstr(const char *s);
Str *intern(const char *s, int len);
List *list_new(int cap);
void list_push(List *l, Value v);
Dict *dict_new(void);
bool dict_get(Dict *d, Value k, Value *out);
void dict_set(Dict *d, Value k, Value v);
bool dict_del(Dict *d, Value k);
#define DICT_EACH(d, i) for (int i = 0; i < (d)->used; i++) if ((d)->e[i].live)

bool truthy(Value v);
bool values_equal(Value a, Value b);
int compare_values(Value a, Value b);
const char *type_name(Value v);
Str *to_str(Value v);
Str *repr_str(Value v);
bool class_find(Class *c, Str *name, Value *out);
bool class_is(Class *c, Class *target);
void init_names(void);
extern Str *S_self, *S_home, *S_init, *S_totext, *S_range;

/* ---------- gc.c ---------- */
enum { GC_STR, GC_LIST, GC_DICT, GC_FUNC, GC_CLASS, GC_INST, GC_BOUND, GC_ENV };
extern int gc_perm;                      /* > 0: allocations are permanent (parser) */
extern size_t gc_units, gc_threshold;
void *gc_alloc(size_t size, int kind);
void gc_grow(size_t units);
void gc_init(void *stack_base);
void gc_root_value(Value *v);
void gc_root_ptr(void **p);
size_t gc_collect(void);
static inline void gc_safepoint(void) { if (gc_units > gc_threshold) gc_collect(); }

/* keyword arguments passed to a call */
typedef struct KW { int n; Str **names; Value *vals; } KW;
int u8len(unsigned char lead);
long str_offset(Str *s, long char_index);       /* byte offset of a character index */

/* ---------- env ---------- */
Env *env_new(Env *parent);
bool env_get(Env *e, Str *name, Value *out);
void env_set(Env *e, Str *name, Value v);       /* assignment: local unless declared global/nonlocal */
bool env_has_local(Env *e, Str *name);
bool env_lookup_local(Env *e, Str *name, Value *out);   /* this scope only, ignoring markers */
extern Env *builtins;
Env *module_root(Env *e);
void env_define(Env *e, Str *name, Value v);

/* ---------- lexer / parser ---------- */
typedef enum {
    TK_EOF, TK_NEWLINE, TK_INDENT, TK_DEDENT, TK_NUM, TK_STR, TK_FSTR,
    TK_IDENT, TK_KW, TK_OP
} TokType;
typedef struct Token { TokType t; int line; double num; Str *str; } Token;
Token *lex(const char *src, int *ntok);
Node *parse_program(const char *src);

/* ---------- interpreter ---------- */
extern Env *globals;
extern Class *module_class;
void add_search_dir(const char *dir);
double sage_random(void);
void sage_seed(double n);
Value stdlib_module(const char *name);        /* stdlib.c: built-in modules, or nothing */
Value make_module_value(Dict *fields);
void interp_init(void);
int run_source(const char *src, bool repl);
Value call_value(Value f, int argc, Value *argv);
Value call_value_kw(Value f, int argc, Value *argv, KW *kw);
Value call_method(Value self, Value fn, int argc, Value *argv);
void load_prelude(void);
Value sage_getattr(Value o, Str *name);
Value sage_import(Str *name);
Str *uc_convert(Str *s, int mode);   /* 0 upper, 1 lower, 2 title */
bool inst_dunder(Value self, const char *name, int argc, Value *argv, Value *out);
Value iter_items(Value v);              /* list snapshot of an iterable */
char *read_file(const char *path);

/* ---------- helpers shared by the built-in modules (stdlib.c) ---------- */
double lib_num(Value v, const char *fn);
Str *lib_str(Value v, const char *fn);
Value lib_text(const char *s, int len);
extern Native json_natives[], csv_natives[], re_natives[];

/* ---------- builtins.c ---------- */
void register_builtins(void);
Native *find_method(Type t, Str *name);
Value native_range(int argc, Value *argv);

#endif
