/* Sage entry point: run a file, run a snippet, or start the REPL. */
#include "sage.h"
#include <ctype.h>
#include <unistd.h>
#include <sys/stat.h>
#include <limits.h>

#define AI_NOTICE "Disclaimer: Sage was designed and written with AI assistance (Claude, by Anthropic), including\n" \
                  "AI-assisted research into language design. It is a young, independent project: test it\n" \
                  "before relying on it for anything important.\n"

static void usage(void) {
    printf("Sage %s - a plain-English, multi-paradigm programming language\n\n"
           "usage:\n"
           "  sage                 start the interactive REPL\n"
           "  sage file.sage       run a program\n"
           "  sage -e \"say 1 + 2\"  run a snippet\n"
           "  sage --version       show the version\n"
           "  sage env create      make a .sage_env folder for this project's packages\n"
           "  sage pkg install X   install a package from a folder or git URL\n"
           "  sage pkg install -r requirements.txt\n"
           "  sage pkg list | remove NAME\n"
           "  sage test [paths]    run every test_* function in test_*.sage files\n"
           "  sage --about         about this project, with the AI-assistance disclaimer\n", SAGE_VERSION);
}

/* Does this line leave something open (a block colon or an open bracket)? */
static bool needs_more(const char *line) {
    int depth = 0;
    char q = 0;
    const char *last = line;
    for (const char *p = line; *p; p++) {
        if (q) { if (*p == '\\' && p[1]) p++; else if (*p == q) q = 0; continue; }
        if (*p == '"' || *p == '\'') q = *p;
        else if (*p == '#') break;
        else if (*p == '(' || *p == '[' || *p == '{') depth++;
        else if (*p == ')' || *p == ']' || *p == '}') depth--;
        if (!isspace((unsigned char)*p)) last = p;
    }
    return depth > 0 || (*line && *last == ':');
}

static void repl(void) {
    printf("Sage %s  -  type code, or press Ctrl-D to leave.  (sage --about: AI-assistance disclaimer)\n", SAGE_VERSION);
    char line[4096];
    for (;;) {
        printf("sage> ");
        fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) { printf("\n"); break; }
        SB buf; sb_init(&buf);
        sb_adds(&buf, line);
        bool block = needs_more(line);
        bool inblock = block && strchr(line, ':') != NULL && line[0] != ' ' ;
        while (block) {
            printf("...  ");
            fflush(stdout);
            if (!fgets(line, sizeof line, stdin)) break;
            bool blank = true;
            for (const char *p = line; *p; p++) if (!isspace((unsigned char)*p)) blank = false;
            if (blank && inblock) break;
            sb_adds(&buf, line);
            if (!inblock) block = needs_more(buf.s);
        }
        run_source(buf.s, true);
        fflush(stdout);
        free(buf.s);
    }
}


/* ---------- environments and packages ---------- */
static bool is_dir(const char *p) { struct stat st; return stat(p, &st) == 0 && S_ISDIR(st.st_mode); }

/* Walk up from the current folder looking for .sage_env; copies its path into out. */
static bool find_env(char *out, size_t n) {
    char cwd[PATH_MAX];
    if (!getcwd(cwd, sizeof cwd)) return false;
    for (;;) {
        snprintf(out, n, "%s/.sage_env", cwd);
        if (is_dir(out)) return true;
        char *slash = strrchr(cwd, '/');
        if (!slash || slash == cwd) {
            if (slash == cwd && cwd[1]) { cwd[1] = 0; continue; }
            return false;
        }
        *slash = 0;
    }
}
static void setup_paths(const char *script) {
    if (script) {
        char dir[PATH_MAX];
        snprintf(dir, sizeof dir, "%s", script);
        char *sl = strrchr(dir, '/');
        if (sl) { *sl = 0; add_search_dir(dir[0] ? dir : "/"); }
    }
    char env[PATH_MAX + 32];
    if (find_env(env, sizeof env)) {
        char pk[PATH_MAX + 64];
        snprintf(pk, sizeof pk, "%s/packages", env);
        add_search_dir(pk);
    }
    const char *sp = getenv("SAGE_PATH");
    if (sp) {
        char *copy = strdup(sp);
        for (char *t = strtok(copy, ":"); t; t = strtok(NULL, ":")) add_search_dir(t);
        free(copy);
    }
    char exe[PATH_MAX];
    ssize_t k = readlink("/proc/self/exe", exe, sizeof exe - 1);
    if (k > 0) {
        exe[k] = 0;
        char *sl = strrchr(exe, '/');
        if (sl) {
            *sl = 0;
            char lib[PATH_MAX + 64];
            snprintf(lib, sizeof lib, "%s/lib", exe);
            if (is_dir(lib)) add_search_dir(lib);
            snprintf(lib, sizeof lib, "%s/../share/sage/lib", exe);
            if (is_dir(lib)) add_search_dir(lib);
        }
    }
}
static int run_cmd(const char *fmt, const char *a, const char *b) {
    char cmd[PATH_MAX * 3];
    snprintf(cmd, sizeof cmd, fmt, a, b);
    return system(cmd);
}
/* Reject names that could escape the packages folder or break a shell command. */
static bool safe_name(const char *s) {
    if (!*s || s[0] == '.') return false;
    for (; *s; s++) if (!isalnum((unsigned char)*s) && *s != '_' && *s != '-') return false;
    return true;
}
static bool safe_path(const char *s) {
    for (; *s; s++) if (!isalnum((unsigned char)*s) && !strchr("/._-~:@+= ", *s)) return false;
    return true;
}
static int pkg_install_one(const char *packages, const char *src) {
    if (!safe_path(src)) { fprintf(stderr, "sage pkg: odd characters in '%s'\n", src); return 1; }
    bool git = !strncmp(src, "http://", 7) || !strncmp(src, "https://", 8) ||
               !strncmp(src, "git@", 4) || (strlen(src) > 4 && !strcmp(src + strlen(src) - 4, ".git"));
    char name[256];
    const char *base = strrchr(src, '/');
    base = base ? base + 1 : src;
    snprintf(name, sizeof name, "%s", base);
    size_t nl = strlen(name);
    if (nl > 4 && !strcmp(name + nl - 4, ".git")) name[nl - 4] = 0;
    if (!safe_name(name)) { fprintf(stderr, "sage pkg: cannot make a package name from '%s'\n", src); return 1; }
    char dest[PATH_MAX + 300];
    snprintf(dest, sizeof dest, "%s/%s", packages, name);
    if (is_dir(dest)) run_cmd("rm -rf '%s'%s", dest, "");
    int rc;
    if (git) rc = run_cmd("git clone --depth 1 -q '%s' '%s'", src, dest);
    else if (is_dir(src)) rc = run_cmd("cp -r '%s' '%s'", src, dest);
    else {                                            /* a single .sage file */
        char one[PATH_MAX];
        snprintf(one, sizeof one, "%s", src);
        if (access(one, R_OK) != 0) { fprintf(stderr, "sage pkg: '%s' is not a folder, git URL or file\n", src); return 1; }
        char file[PATH_MAX + 300];
        size_t l = strlen(name);
        if (l > 5 && !strcmp(name + l - 5, ".sage")) name[l - 5] = 0;
        snprintf(file, sizeof file, "%s/%s.sage", packages, name);
        rc = run_cmd("cp '%s' '%s'", src, file);
    }
    if (rc != 0) { fprintf(stderr, "sage pkg: could not install '%s'\n", src); return 1; }
    printf("installed %s\n", name);
    return 0;
}
static int cmd_env(int argc, char **argv) {
    if (argc >= 3 && !strcmp(argv[2], "create")) {
        if (mkdir(".sage_env", 0755) != 0 && !is_dir(".sage_env")) { perror("sage env"); return 1; }
        mkdir(".sage_env/packages", 0755);
        printf("created .sage_env in %s\nPackages you install here are used by programs run inside this folder.\n",
               getcwd(NULL, 0));
        return 0;
    }
    char env[PATH_MAX + 32];
    if (find_env(env, sizeof env)) printf("active environment: %s\n", env);
    else printf("no .sage_env found here or above. Make one with: sage env create\n");
    return 0;
}
static int cmd_pkg(int argc, char **argv) {
    char env[PATH_MAX + 32], packages[PATH_MAX + 64];
    if (argc < 3) { usage(); return 2; }
    if (!find_env(env, sizeof env)) {
        fprintf(stderr, "sage pkg: no .sage_env found. Run 'sage env create' in your project folder first.\n");
        return 1;
    }
    snprintf(packages, sizeof packages, "%s/packages", env);
    mkdir(packages, 0755);
    const char *sub = argv[2];
    if (!strcmp(sub, "list")) {
        char cmd[PATH_MAX + 80];
        snprintf(cmd, sizeof cmd, "ls -1 '%s'", packages);
        return system(cmd) == 0 ? 0 : 1;
    }
    if (!strcmp(sub, "remove") && argc >= 4) {
        if (!safe_name(argv[3])) { fprintf(stderr, "sage pkg: bad package name\n"); return 1; }
        char path[PATH_MAX + 300];
        snprintf(path, sizeof path, "%s/%s", packages, argv[3]);
        char file[PATH_MAX + 310];
        snprintf(file, sizeof file, "%s.sage", path);
        if (is_dir(path)) { run_cmd("rm -rf '%s'%s", path, ""); printf("removed %s\n", argv[3]); return 0; }
        if (access(file, F_OK) == 0) { unlink(file); printf("removed %s\n", argv[3]); return 0; }
        fprintf(stderr, "sage pkg: '%s' is not installed\n", argv[3]);
        return 1;
    }
    if (!strcmp(sub, "install") && argc >= 4) {
        int bad = 0;
        if (!strcmp(argv[3], "-r")) {
            if (argc < 5) { fprintf(stderr, "sage pkg install -r needs a file\n"); return 2; }
            FILE *f = fopen(argv[4], "r");
            if (!f) { fprintf(stderr, "sage pkg: cannot open '%s'\n", argv[4]); return 1; }
            char line[1024];
            while (fgets(line, sizeof line, f)) {
                line[strcspn(line, "\r\n")] = 0;
                char *p = line;
                while (isspace((unsigned char)*p)) p++;
                if (!*p || *p == '#') continue;
                bad += pkg_install_one(packages, p);
            }
            fclose(f);
        } else for (int i = 3; i < argc; i++) bad += pkg_install_one(packages, argv[i]);
        return bad ? 1 : 0;
    }
    usage();
    return 2;
}

int main(int argc, char **argv) {
    gc_init(__builtin_frame_address(0));
    interp_init();
    env_define(globals, intern("__name__", 8), v_str(str_cstr("__main__")));
    add_search_dir(".");
    if (argc >= 2 && (!strcmp(argv[1], "--version") || !strcmp(argv[1], "-v"))) {
        printf("Sage %s\n", SAGE_VERSION);
        return 0;
    }
    if (argc >= 2 && !strcmp(argv[1], "--about")) {
        printf("Sage %s - a plain-English, multi-paradigm programming language (interpreter written in C)\n\n%s", SAGE_VERSION, AI_NOTICE);
        return 0;
    }
    if (argc >= 2 && (!strcmp(argv[1], "--help") || !strcmp(argv[1], "-h"))) { usage(); return 0; }
    if (argc >= 2 && !strcmp(argv[1], "env")) return cmd_env(argc, argv);
    if (argc >= 2 && !strcmp(argv[1], "pkg")) return cmd_pkg(argc, argv);
    if (argc >= 2 && !strcmp(argv[1], "test")) {                 /* sage test [files or folders] */
        setup_paths(NULL);
        List *targs = list_new(argc);
        for (int i = 2; i < argc; i++) list_push(targs, v_str(str_cstr(argv[i])));
        env_define(builtins, intern("args", 4), v_obj(T_LIST, targs));
        int rc = run_source("import testing\ntesting.main()\n", false);
        fflush(stdout);
        return rc;
    }
    setup_paths(argc >= 2 && strcmp(argv[1], "-e") ? argv[1] : NULL);
    if (argc >= 3 && !strcmp(argv[1], "-e")) {
        int rc = run_source(argv[2], false);
        fflush(stdout);
        return rc;
    }
    if (argc >= 2) {
        char *src = read_file(argv[1]);
        if (!src) { fprintf(stderr, "sage: cannot open '%s'\n", argv[1]); return 2; }
        List *args = list_new(argc);
        for (int i = 2; i < argc; i++) list_push(args, v_str(str_cstr(argv[i])));
        env_define(builtins, intern("args", 4), v_obj(T_LIST, args));
        int rc = run_source(src, false);
        fflush(stdout);
        return rc;
    }
    repl();
    return 0;
}
