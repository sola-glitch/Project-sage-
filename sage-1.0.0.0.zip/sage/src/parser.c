/* Parser: tokens -> AST (recursive descent). */
#include "sage.h"

Str *lex_unescape(const char *s, int n);

typedef struct { Token *t; int pos, n; } P;

static Token *peek(P *p) { return &p->t[p->pos]; }
static Token *peek_at(P *p, int off) {
    int i = p->pos + off;
    if (i >= p->n) i = p->n - 1;
    return &p->t[i];
}
static Token *adv(P *p) {
    Token *t = &p->t[p->pos];
    if (t->t != TK_EOF) p->pos++;
    return t;
}
static bool tok_op(Token *t, const char *s) { return t->t == TK_OP && strcmp(t->str->s, s) == 0; }
static bool tok_kw(Token *t, const char *s) { return t->t == TK_KW && strcmp(t->str->s, s) == 0; }
static bool tok_id(Token *t, const char *s) { return t->t == TK_IDENT && strcmp(t->str->s, s) == 0; }
static bool is_op(P *p, const char *s) { return tok_op(peek(p), s); }
static bool is_kw(P *p, const char *s) { return tok_kw(peek(p), s); }
static bool match_op(P *p, const char *s) { if (is_op(p, s)) { adv(p); return true; } return false; }
static bool match_kw(P *p, const char *s) { if (is_kw(p, s)) { adv(p); return true; } return false; }

static const char *describe(Token *t) {
    static char buf[96];
    switch (t->t) {
    case TK_EOF: return "end of file";
    case TK_NEWLINE: return "end of line";
    case TK_INDENT: return "an unexpected indent";
    case TK_DEDENT: return "end of block";
    case TK_NUM: return "a number";
    case TK_STR: case TK_FSTR: return "a string";
    default: snprintf(buf, sizeof buf, "'%s'", t->str->s); return buf;
    }
}

static void perr(P *p, const char *fmt, ...) __attribute__((noreturn, format(printf, 2, 3)));
static void perr(P *p, const char *fmt, ...) {
    char buf[400];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    cur_line = peek(p)->line;
    sage_error("syntax error: %s", buf);
}

static void expect_op(P *p, const char *s) {
    if (!match_op(p, s)) perr(p, "expected '%s' but found %s", s, describe(peek(p)));
}
static void expect_kw(P *p, const char *s) {
    if (!match_kw(p, s)) perr(p, "expected '%s' but found %s", s, describe(peek(p)));
}
static Str *expect_ident(P *p) {
    if (peek(p)->t != TK_IDENT) perr(p, "expected a name but found %s", describe(peek(p)));
    return adv(p)->str;
}

static Node *mk(NodeKind k, int line) {
    Node *n = xmalloc(sizeof(Node));
    memset(n, 0, sizeof *n);
    n->kind = k; n->line = line; n->file = parse_file; n->val = v_nothing();
    return n;
}
static void kid(Node *n, Node *c)  { n->kids  = xrealloc(n->kids,  sizeof(Node *) * (n->nkids + 1));  n->kids[n->nkids++]   = c; }
static void kid2(Node *n, Node *c) { n->kids2 = xrealloc(n->kids2, sizeof(Node *) * (n->nkids2 + 1)); n->kids2[n->nkids2++] = c; }
static Node *lit(int line, Value v) { Node *n = mk(N_LIT, line); n->val = v; return n; }

static void add_param(P *p, Node *n, Str *name, Node *def, bool kwonly) {
    if (!kwonly) {
        if (!def && n->nparams > n->op) perr(p, "a parameter without a default cannot follow one with a default");
        if (!def) n->op++;
    }
    n->params = xrealloc(n->params, sizeof(Str *) * (n->nparams + 1));
    n->params[n->nparams++] = name;
    kid2(n, def);
}

static Node *parse_expr(P *p);
static Node *parse_or(P *p);
static Node *parse_pipe_with(P *p, bool allow_ternary);
static Node *parse_stmt(P *p);

static bool at_eol(P *p) {
    TokType t = peek(p)->t;
    return t == TK_NEWLINE || t == TK_EOF || t == TK_DEDENT;
}
static void end_stmt(P *p) {
    Token *t = peek(p);
    if (t->t == TK_NEWLINE) { adv(p); return; }
    if (t->t == TK_EOF || t->t == TK_DEDENT) return;
    perr(p, "unexpected %s", describe(t));
}

/* ---------- expressions ---------- */
static Node *sub_parse(const char *s, int len, int line) {
    char *buf = xmalloc(len + 1);
    memcpy(buf, s, len);
    buf[len] = 0;
    char *b = buf;
    while (*b == ' ' || *b == '\t') b++;
    int nt;
    Token *toks = lex(b, &nt);
    for (int i = 0; i < nt; i++) toks[i].line = line;
    P sub = { toks, 0, nt };
    if (peek(&sub)->t == TK_EOF || peek(&sub)->t == TK_NEWLINE) perr(&sub, "empty {} in f-string");
    Node *e = parse_expr(&sub);
    if (peek(&sub)->t != TK_NEWLINE && peek(&sub)->t != TK_EOF)
        perr(&sub, "unexpected %s inside f-string braces", describe(peek(&sub)));
    free(buf);
    return e;
}

static void flush_lit(Node *n, SB *b, int line) {
    if (b->len == 0) return;
    kid(n, lit(line, v_str(lex_unescape(b->s, b->len))));
    b->len = 0; b->s[0] = 0;
}

static Node *build_fstr(Token *t) {
    Node *n = mk(N_FSTR, t->line);
    const char *s = t->str->s;
    int len = t->str->len, i = 0;
    SB b; sb_init(&b);
    while (i < len) {
        char c = s[i];
        if (c == '{' && i + 1 < len && s[i + 1] == '{') { sb_addc(&b, '{'); i += 2; continue; }
        if (c == '}' && i + 1 < len && s[i + 1] == '}') { sb_addc(&b, '}'); i += 2; continue; }
        if (c == '\\' && i + 1 < len) { sb_addc(&b, c); sb_addc(&b, s[i + 1]); i += 2; continue; }
        if (c == '{') {
            flush_lit(n, &b, t->line);
            int j = i + 1, depth = 1;
            while (j < len) {
                char d = s[j];
                if (d == '"' || d == '\'') { j++; while (j < len && s[j] != d) j++; }
                else if (d == '{') depth++;
                else if (d == '}' && --depth == 0) break;
                j++;
            }
            if (j >= len) { cur_line = t->line; sage_error("syntax error: unmatched '{' in f-string"); }
            kid(n, sub_parse(s + i + 1, j - i - 1, t->line));
            i = j + 1;
            continue;
        }
        sb_addc(&b, c);
        i++;
    }
    flush_lit(n, &b, t->line);
    free(b.s);
    return n;
}

static void parse_targets(P *p, Node *n) {
    do {
        Str *name = expect_ident(p);
        n->params = xrealloc(n->params, sizeof(Str *) * (n->nparams + 1));
        n->params[n->nparams++] = name;
    } while (match_op(p, ","));
}

static void parse_params(P *p, Node *fn, const char *closer) {
    bool after_rest = false;
    fn->npos = -1;
    while (!is_op(p, closer)) {
        if (is_op(p, "**")) {
            adv(p);
            fn->kwrest = expect_ident(p);
            match_op(p, ",");
            if (!is_op(p, closer)) perr(p, "'**%s' must be the last parameter", fn->kwrest->s);
            break;
        }
        if (is_op(p, "*")) {
            if (after_rest) perr(p, "only one '*' parameter is allowed");
            adv(p);
            fn->rest = expect_ident(p);
            fn->npos = fn->nparams;
            after_rest = true;
            if (!match_op(p, ",")) break;
            continue;
        }
        Str *name = expect_ident(p);
        Node *def = NULL;
        if (match_op(p, "=")) def = parse_expr(p);
        add_param(p, fn, name, def, after_rest);
        if (!match_op(p, ",")) break;
    }
    if (fn->npos < 0) fn->npos = fn->nparams;
}

static Node *parse_list(P *p) {
    int line = adv(p)->line;
    Node *n = mk(N_LIST, line);
    if (match_op(p, "]")) return n;
    Node *first = parse_expr(p);
    if (is_kw(p, "for")) {
        adv(p);
        Node *c = mk(N_COMP, line);
        c->a = first;
        parse_targets(p, c);
        expect_kw(p, "in");
        c->b = parse_pipe_with(p, false);
        if (match_kw(p, "if")) c->c = parse_or(p);
        expect_op(p, "]");
        return c;
    }
    kid(n, first);
    while (match_op(p, ",")) {
        if (is_op(p, "]")) break;
        kid(n, parse_expr(p));
    }
    expect_op(p, "]");
    return n;
}

static Node *parse_comp_tail(P *p, Node *c) {
    parse_targets(p, c);
    expect_kw(p, "in");
    c->b = parse_pipe_with(p, false);
    if (match_kw(p, "if")) c->c = parse_or(p);
    expect_op(p, "}");
    return c;
}

/* { } is a dict ({k: v}), a set ({a, b}), or a comprehension of either. */
static Node *parse_dict(P *p) {
    int line = adv(p)->line;
    Node *n = mk(N_DICT, line);
    if (match_op(p, "}")) return n;
    Node *k = parse_expr(p);
    if (!is_op(p, ":")) {
        if (is_kw(p, "for")) {
            adv(p);
            Node *c = mk(N_COMP, line);
            c->op = 1; c->a = k;
            return parse_comp_tail(p, c);
        }
        Node *s = mk(N_SETLIT, line);
        kid(s, k);
        while (match_op(p, ",")) {
            if (is_op(p, "}")) break;
            kid(s, parse_expr(p));
        }
        expect_op(p, "}");
        return s;
    }
    adv(p);
    Node *v = parse_expr(p);
    if (is_kw(p, "for")) {
        adv(p);
        Node *c = mk(N_COMP, line);
        c->op = 2; c->a = k;
        kid(c, v);
        return parse_comp_tail(p, c);
    }
    kid(n, k); kid2(n, v);
    while (match_op(p, ",")) {
        if (is_op(p, "}")) break;
        Node *k2 = parse_expr(p);
        expect_op(p, ":");
        Node *v2 = parse_expr(p);
        kid(n, k2); kid2(n, v2);
    }
    expect_op(p, "}");
    return n;
}

static Node *parse_primary(P *p) {
    Token *t = peek(p);
    int line = t->line;
    switch (t->t) {
    case TK_NUM: adv(p); return lit(line, v_num(t->num));
    case TK_STR: adv(p); return lit(line, v_str(t->str));
    case TK_FSTR: adv(p); return build_fstr(t);
    case TK_IDENT: { adv(p); Node *n = mk(N_VAR, line); n->name = t->str; return n; }
    case TK_KW:
        if (tok_kw(t, "true"))    { adv(p); return lit(line, v_bool(true)); }
        if (tok_kw(t, "false"))   { adv(p); return lit(line, v_bool(false)); }
        if (tok_kw(t, "nothing")) { adv(p); return lit(line, v_nothing()); }
        if (tok_kw(t, "lambda")) {
            adv(p);
            Node *n = mk(N_LAMBDA, line);
            parse_params(p, n, ":");
            expect_op(p, ":");
            n->a = parse_expr(p);
            return n;
        }
        if (tok_kw(t, "super")) {
            adv(p);
            expect_op(p, ".");
            Node *n = mk(N_SUPER, line);
            n->name = expect_ident(p);
            return n;
        }
        break;
    case TK_OP:
        if (tok_op(t, "(")) {
            adv(p);
            if (match_op(p, ")")) return mk(N_TUPLE, line);
            Node *e = parse_expr(p);
            if (is_op(p, ",")) {                               /* a tuple */
                Node *tn = mk(N_TUPLE, line);
                kid(tn, e);
                while (match_op(p, ",")) {
                    if (is_op(p, ")")) break;
                    kid(tn, parse_expr(p));
                }
                expect_op(p, ")");
                return tn;
            }
            expect_op(p, ")");
            return e;
        }
        if (tok_op(t, "[")) return parse_list(p);
        if (tok_op(t, "{")) return parse_dict(p);
        break;
    default: break;
    }
    perr(p, "expected an expression but found %s", describe(t));
}

static Node *parse_postfix(P *p) {
    Node *e = parse_primary(p);
    for (;;) {
        Token *t = peek(p);
        int line = t->line;
        if (tok_op(t, "(")) {
            adv(p);
            Node *c = mk(N_CALL, line);
            c->a = e;
            if (!is_op(p, ")")) {
                bool seen_kw = false;
                for (;;) {
                    int aline = peek(p)->line;
                    if (is_op(p, "*")) {
                        adv(p);
                        Node *a = mk(N_SPREAD, aline);
                        a->a = parse_expr(p);
                        kid(c, a); c->op = 1;
                    } else if (is_op(p, "**")) {
                        adv(p);
                        Node *a = mk(N_KWSPREAD, aline);
                        a->a = parse_expr(p);
                        kid(c, a); c->op = 1; seen_kw = true;
                    } else if (peek(p)->t == TK_IDENT && tok_op(peek_at(p, 1), "=")) {
                        Node *a = mk(N_KWARG, aline);
                        a->name = adv(p)->str;
                        adv(p);
                        a->a = parse_expr(p);
                        kid(c, a); c->op = 1; seen_kw = true;
                    } else {
                        if (seen_kw) perr(p, "a positional argument cannot follow a name=value argument");
                        kid(c, parse_expr(p));
                    }
                    if (!match_op(p, ",")) break;
                    if (is_op(p, ")")) break;
                }
            }
            expect_op(p, ")");
            e = c;
        } else if (tok_op(t, "[")) {
            adv(p);
            Node *start = NULL, *end = NULL;
            bool slice = false;
            if (!is_op(p, ":")) start = parse_expr(p);
            if (match_op(p, ":")) { slice = true; if (!is_op(p, "]")) end = parse_expr(p); }
            expect_op(p, "]");
            Node *n = mk(slice ? N_SLICE : N_INDEX, line);
            n->a = e; n->b = start; n->c = end;
            e = n;
        } else if (tok_op(t, ".")) {
            adv(p);
            Node *n = mk(N_ATTR, line);
            n->a = e;
            n->name = expect_ident(p);
            e = n;
        } else break;
    }
    return e;
}

static Node *binary(NodeKind k, int op, Node *l, Node *r, int line) {
    Node *n = mk(k, line);
    n->op = op; n->a = l; n->b = r;
    return n;
}

static Node *parse_unary(P *p);
static Node *parse_pow(P *p) {
    Node *base = parse_postfix(p);
    if (is_op(p, "**")) {
        int line = adv(p)->line;
        Node *ex = parse_unary(p);
        return binary(N_BIN, OP_POW, base, ex, line);
    }
    return base;
}
static Node *parse_unary(P *p) {
    if (is_op(p, "-")) {
        int line = adv(p)->line;
        Node *n = mk(N_NEG, line);
        n->a = parse_unary(p);
        return n;
    }
    if (match_op(p, "+")) return parse_unary(p);
    return parse_pow(p);
}
static Node *parse_mul(P *p) {
    Node *l = parse_unary(p);
    for (;;) {
        int op = 0, line = peek(p)->line;
        if (is_op(p, "*")) op = OP_MUL;
        else if (is_op(p, "/")) op = OP_DIV;
        else if (is_op(p, "//")) op = OP_IDIV;
        else if (is_op(p, "%")) op = OP_MOD;
        else break;
        adv(p);
        l = binary(N_BIN, op, l, parse_unary(p), line);
    }
    return l;
}
static Node *parse_add(P *p) {
    Node *l = parse_mul(p);
    for (;;) {
        int op = 0, line = peek(p)->line;
        if (is_op(p, "+")) op = OP_ADD;
        else if (is_op(p, "-")) op = OP_SUB;
        else if (is_op(p, "|")) op = OP_UNION;
        else if (is_op(p, "&")) op = OP_INTER;
        else break;
        adv(p);
        l = binary(N_BIN, op, l, parse_mul(p), line);
    }
    return l;
}

static bool two_words(P *p, const char *a, const char *b) {
    if (tok_id(peek(p), a) && tok_id(peek_at(p, 1), b)) { adv(p); adv(p); return true; }
    return false;
}

static Node *parse_cmp(P *p) {
    Node *l = parse_add(p);
    for (;;) {
        Token *t = peek(p);
        int op = -1, line = t->line;
        if (t->t == TK_OP) {
            const char *s = t->str->s;
            if (!strcmp(s, "==")) op = OP_EQ;
            else if (!strcmp(s, "!=")) op = OP_NE;
            else if (!strcmp(s, "<")) op = OP_LT;
            else if (!strcmp(s, ">")) op = OP_GT;
            else if (!strcmp(s, "<=")) op = OP_LE;
            else if (!strcmp(s, ">=")) op = OP_GE;
            if (op >= 0) adv(p);
        } else if (tok_kw(t, "is")) {
            adv(p);
            if (match_kw(p, "not")) op = OP_NE;
            else if (two_words(p, "greater", "than")) op = OP_GT;
            else if (two_words(p, "less", "than")) op = OP_LT;
            else if (two_words(p, "at", "least")) op = OP_GE;
            else if (two_words(p, "at", "most")) op = OP_LE;
            else if (two_words(p, "equal", "to")) op = OP_EQ;
            else op = OP_EQ;
        } else if (tok_kw(t, "in")) {
            adv(p); op = OP_IN;
        } else if (tok_kw(t, "not") && tok_kw(peek_at(p, 1), "in")) {
            adv(p); adv(p); op = OP_NOTIN;
        }
        if (op < 0) break;
        l = binary(N_BIN, op, l, parse_add(p), line);
    }
    return l;
}

static Node *parse_not(P *p) {
    if (is_kw(p, "not")) {
        int line = adv(p)->line;
        Node *n = mk(N_NOT, line);
        n->a = parse_not(p);
        return n;
    }
    return parse_cmp(p);
}
static Node *parse_and(P *p) {
    Node *l = parse_not(p);
    while (is_kw(p, "and")) { int line = adv(p)->line; l = binary(N_AND, 0, l, parse_not(p), line); }
    return l;
}
static Node *parse_or(P *p) {
    Node *l = parse_and(p);
    while (is_kw(p, "or")) { int line = adv(p)->line; l = binary(N_OR, 0, l, parse_and(p), line); }
    return l;
}
static Node *parse_ternary(P *p) {
    Node *a = parse_or(p);
    if (is_kw(p, "if")) {
        int line = adv(p)->line;
        Node *cond = parse_or(p);
        expect_kw(p, "else");
        Node *other = parse_ternary(p);
        Node *n = mk(N_TERN, line);
        n->a = cond; n->b = a; n->c = other;
        return n;
    }
    return a;
}
static Node *parse_pipe_with(P *p, bool allow_ternary) {
    Node *l = allow_ternary ? parse_ternary(p) : parse_or(p);
    while (is_op(p, "|>")) {
        int line = adv(p)->line;
        Node *r = allow_ternary ? parse_ternary(p) : parse_or(p);
        if (r->kind == N_CALL) {            /* x |> f(a)  ==>  f(x, a) */
            r->kids = xrealloc(r->kids, sizeof(Node *) * (r->nkids + 1));
            memmove(r->kids + 1, r->kids, sizeof(Node *) * r->nkids);
            r->kids[0] = l;
            r->nkids++;
            l = r;
        } else {                            /* x |> f      ==>  f(x)    */
            Node *c = mk(N_CALL, line);
            c->a = r;
            kid(c, l);
            l = c;
        }
    }
    return l;
}
static Node *parse_expr(P *p) { return parse_pipe_with(p, true); }

/* ---------- statements ---------- */
static Node *parse_block(P *p) {
    Node *b = mk(N_BLOCK, peek(p)->line);
    expect_op(p, ":");
    if (peek(p)->t == TK_NEWLINE) {
        adv(p);
        if (peek(p)->t != TK_INDENT) perr(p, "expected an indented block");
        adv(p);
        while (peek(p)->t != TK_DEDENT && peek(p)->t != TK_EOF) kid(b, parse_stmt(p));
        if (peek(p)->t == TK_DEDENT) adv(p);
    } else {
        kid(b, parse_stmt(p));
    }
    return b;
}

static Node *parse_if(P *p) {
    int line = adv(p)->line;
    Node *n = mk(N_IF, line);
    kid(n, parse_expr(p));
    kid2(n, parse_block(p));
    for (;;) {
        if (is_kw(p, "elif")) { adv(p); kid(n, parse_expr(p)); kid2(n, parse_block(p)); continue; }
        if (is_kw(p, "else")) {
            adv(p);
            if (is_kw(p, "if")) { adv(p); kid(n, parse_expr(p)); kid2(n, parse_block(p)); continue; }
            n->c = parse_block(p);
        }
        break;
    }
    return n;
}

static Node *parse_define(P *p) {
    int line = adv(p)->line;
    Node *n = mk(N_DEF, line);
    n->name = expect_ident(p);
    expect_op(p, "(");
    parse_params(p, n, ")");
    expect_op(p, ")");
    n->b = parse_block(p);
    return n;
}

static Node *parse_class(P *p) {
    int line = adv(p)->line;
    Node *n = mk(N_CLASS, line);
    n->name = expect_ident(p);
    if (match_op(p, "(")) { n->a = parse_expr(p); expect_op(p, ")"); }
    else if (tok_id(peek(p), "extends")) { adv(p); n->a = parse_expr(p); }
    Node *body = parse_block(p);
    for (int i = 0; i < body->nkids; i++) {
        Node *k = body->kids[i];
        if (k->kind == N_DEF) kid(n, k);
        else if (k->kind != N_PASS) { cur_line = k->line; sage_error("syntax error: a class body may only contain 'define' statements"); }
    }
    return n;
}

static Node *parse_rhs_list(P *p, int line) {
    Node *e = parse_expr(p);
    if (!is_op(p, ",")) return e;
    Node *l = mk(N_LIST, line);
    kid(l, e);
    while (match_op(p, ",")) kid(l, parse_expr(p));
    return l;
}

static bool assignable(Node *e) { return e->kind == N_VAR || e->kind == N_INDEX || e->kind == N_ATTR; }

static Node *parse_stmt(P *p) {
    Token *t = peek(p);
    int line = t->line;
    if (tok_op(t, "@")) {                                   /* decorators */
        Node *decos = mk(N_LIST, line);
        while (is_op(p, "@")) {
            adv(p);
            kid(decos, parse_expr(p));
            if (peek(p)->t != TK_NEWLINE) perr(p, "expected the end of the line after a decorator");
            adv(p);
        }
        if (!is_kw(p, "define") && !is_kw(p, "class")) perr(p, "a decorator must be followed by 'define' or 'class'");
        Node *target = is_kw(p, "define") ? parse_define(p) : parse_class(p);
        target->c = decos;
        return target;
    }
    if (t->t == TK_INDENT) perr(p, "unexpected indentation");

    if (t->t == TK_KW) {
        const char *k = t->str->s;
        if (!strcmp(k, "if")) return parse_if(p);
        if (!strcmp(k, "while")) {
            adv(p);
            Node *n = mk(N_WHILE, line);
            n->a = parse_expr(p); n->b = parse_block(p);
            return n;
        }
        if (!strcmp(k, "for")) {
            adv(p);
            Node *n = mk(N_FOR, line);
            parse_targets(p, n);
            expect_kw(p, "in");
            n->a = parse_expr(p);
            n->b = parse_block(p);
            return n;
        }
        if (!strcmp(k, "repeat")) {
            adv(p);
            Node *n = mk(N_REPEAT, line);
            n->a = parse_expr(p);
            if (!tok_id(peek(p), "times")) perr(p, "expected 'times' but found %s", describe(peek(p)));
            adv(p);
            n->b = parse_block(p);
            return n;
        }
        if (!strcmp(k, "define")) return parse_define(p);
        if (!strcmp(k, "class")) return parse_class(p);
        if (!strcmp(k, "try")) {
            adv(p);
            Node *n = mk(N_TRY, line);
            n->a = parse_block(p);
            while (is_kw(p, "catch")) {
                adv(p);
                Node *spec = NULL;
                Str *name = NULL;
                if (is_op(p, ":")) {
                    /* catch everything, no name */
                } else if (peek(p)->t == TK_IDENT && tok_op(peek_at(p, 1), ":")) {
                    name = adv(p)->str;                      /* catch e:  (catches everything) */
                } else {
                    spec = parse_expr(p);
                    if (is_op(p, ",")) {
                        Node *l = mk(N_LIST, line);
                        kid(l, spec);
                        while (match_op(p, ",")) kid(l, parse_expr(p));
                        spec = l;
                    }
                    if (tok_id(peek(p), "as")) { adv(p); name = expect_ident(p); }
                }
                n->kids = xrealloc(n->kids, sizeof(Node *) * (n->nkids + 1));
                n->kids[n->nkids++] = spec;
                n->params = xrealloc(n->params, sizeof(Str *) * (n->nparams + 1));
                n->params[n->nparams++] = name;
                kid2(n, parse_block(p));
            }
            if (is_kw(p, "finally")) { adv(p); n->c = parse_block(p); }
            if (n->nkids == 0 && !n->c) perr(p, "expected 'catch' or 'finally' after the try block");
            for (int i = 0; i + 1 < n->nkids; i++)
                if (!n->kids[i]) perr(p, "a catch-everything clause must be the last catch");
            return n;
        }
        if (!strcmp(k, "with")) {
            adv(p);
            Node *n = mk(N_WITH, line);
            n->a = parse_expr(p);
            if (tok_id(peek(p), "as")) { adv(p); n->name = expect_ident(p); }
            n->b = parse_block(p);
            return n;
        }
        if (!strcmp(k, "return")) {
            adv(p);
            Node *n = mk(N_RETURN, line);
            if (!at_eol(p)) {
                n->a = parse_expr(p);
                if (is_op(p, ",")) {                    /* return a, b  gives a tuple */
                    Node *tn = mk(N_TUPLE, line);
                    kid(tn, n->a);
                    while (match_op(p, ",")) kid(tn, parse_expr(p));
                    n->a = tn;
                }
            }
            end_stmt(p);
            return n;
        }
        if (!strcmp(k, "break") || !strcmp(k, "continue") || !strcmp(k, "pass")) {
            adv(p);
            Node *n = mk(k[0] == 'b' ? N_BREAK : k[0] == 'c' ? N_CONTINUE : N_PASS, line);
            end_stmt(p);
            return n;
        }
        if (!strcmp(k, "raise") || !strcmp(k, "use")) {
            adv(p);
            Node *n = mk(k[0] == 'r' ? N_RAISE : N_USE, line);
            n->a = parse_expr(p);
            end_stmt(p);
            return n;
        }
        if (!strcmp(k, "say")) {
            adv(p);
            Node *n = mk(N_SAY, line);
            if (!at_eol(p)) {
                kid(n, parse_expr(p));
                while (match_op(p, ",")) kid(n, parse_expr(p));
            }
            end_stmt(p);
            return n;
        }
        if (!strcmp(k, "let")) {
            adv(p);
            Node *n = mk(N_LET, line);
            n->name = expect_ident(p);
            if (is_op(p, ",")) {                         /* let a, b = ... */
                Node *u = mk(N_UNPACK, line);
                u->op = 1;
                Node *first = mk(N_VAR, line);
                first->name = n->name;
                kid(u, first);
                while (match_op(p, ",")) {
                    Node *w = mk(N_VAR, line);
                    w->name = expect_ident(p);
                    kid(u, w);
                }
                expect_op(p, "=");
                u->a = parse_rhs_list(p, line);
                end_stmt(p);
                return u;
            }
            if (!match_op(p, "=")) {
                if (tok_id(peek(p), "be")) adv(p);
                else perr(p, "expected '=' after the name but found %s", describe(peek(p)));
            }
            n->a = parse_expr(p);
            end_stmt(p);
            return n;
        }
        if (!strcmp(k, "assert")) {
            adv(p);
            Node *n = mk(N_ASSERT, line);
            n->a = parse_expr(p);
            if (match_op(p, ",")) n->b = parse_expr(p);
            end_stmt(p);
            return n;
        }
    }
    if (tok_id(t, "give") && tok_id(peek_at(p, 1), "back")) {
        adv(p); adv(p);
        Node *n = mk(N_RETURN, line);
        if (!at_eol(p)) n->a = parse_expr(p);
        end_stmt(p);
        return n;
    }

    if (tok_kw(t, "import") || (tok_id(t, "from") && peek_at(p, 1)->t == TK_IDENT)) {
        bool from = tok_id(t, "from");
        adv(p);
        SB path; sb_init(&path);
        Str *last = expect_ident(p);
        sb_adds(&path, last->s);
        while (match_op(p, ".")) { last = expect_ident(p); sb_addc(&path, '.'); sb_adds(&path, last->s); }
        Node *n = mk(N_IMPORT, line);
        n->val = v_str(intern(path.s, path.len));
        free(path.s);
        if (from) {
            n->op = 1;
            expect_kw(p, "import");
            do {
                Str *nm = expect_ident(p), *alias = nm;
                if (tok_id(peek(p), "as")) { adv(p); alias = expect_ident(p); }
                n->params = xrealloc(n->params, sizeof(Str *) * (n->nparams + 2));
                n->params[n->nparams++] = nm;
                n->params[n->nparams++] = alias;
            } while (match_op(p, ","));
        } else {
            n->name = last;
            if (tok_id(peek(p), "as")) { adv(p); n->name = expect_ident(p); }
            else if (strchr(AS_STR(n->val)->s, '.')) {          /* import a.b.c binds the name a */
                const char *full = AS_STR(n->val)->s;
                n->rest = intern(full, (int)(strchr(full, '.') - full));
            }
        }
        end_stmt(p);
        return n;
    }
    if ((tok_id(t, "global") || tok_id(t, "nonlocal")) && peek_at(p, 1)->t == TK_IDENT) {
        adv(p);
        Node *n = mk(N_GLOBAL, line);
        n->op = tok_id(t, "nonlocal") ? 1 : 0;
        do {
            n->params = xrealloc(n->params, sizeof(Str *) * (n->nparams + 1));
            n->params[n->nparams++] = expect_ident(p);
        } while (match_op(p, ","));
        end_stmt(p);
        return n;
    }

    Node *e = parse_expr(p);
    if (is_op(p, ",") && assignable(e)) {                /* a, b = ... */
        Node *u = mk(N_UNPACK, line);
        kid(u, e);
        while (match_op(p, ",")) {
            Node *target = parse_expr(p);
            if (!assignable(target)) perr(p, "you can only assign to a variable, an index or an attribute");
            kid(u, target);
        }
        expect_op(p, "=");
        u->a = parse_rhs_list(p, line);
        end_stmt(p);
        return u;
    }
    Token *o = peek(p);
    if (o->t == TK_OP) {
        const char *s = o->str->s;
        int op = -1;
        if (!strcmp(s, "=")) op = OP_NONE;
        else if (!strcmp(s, "+=")) op = OP_ADD;
        else if (!strcmp(s, "-=")) op = OP_SUB;
        else if (!strcmp(s, "*=")) op = OP_MUL;
        else if (!strcmp(s, "/=")) op = OP_DIV;
        else if (!strcmp(s, "%=")) op = OP_MOD;
        if (op >= 0) {
            if (e->kind != N_VAR && e->kind != N_INDEX && e->kind != N_ATTR)
                perr(p, "you can only assign to a variable, an index or an attribute");
            adv(p);
            Node *n = mk(N_ASSIGN, line);
            n->a = e; n->op = op; n->b = parse_expr(p);
            end_stmt(p);
            return n;
        }
    }
    Node *n = mk(N_EXPR, line);
    n->a = e;
    end_stmt(p);
    return n;
}

Node *parse_program(const char *src) {
    gc_perm++;                         /* everything the parser makes lives forever */
    int n;
    Token *t = lex(src, &n);
    P p = { t, 0, n };
    Node *prog = mk(N_BLOCK, 1);
    while (peek(&p)->t != TK_EOF) {
        if (peek(&p)->t == TK_NEWLINE) { adv(&p); continue; }
        kid(prog, parse_stmt(&p));
    }
    gc_perm--;
    return prog;
}
