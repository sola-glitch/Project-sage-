/* Built-in modules: math, random, os, time. (json and csv: lib_json.c, re: lib_re.c) */
#include "sage.h"
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define NATIVE(name) static Value name(__attribute__((unused)) int argc, __attribute__((unused)) Value *argv)

double lib_num(Value v, const char *fn) {
    if (v.t != T_NUM) sage_error("%s() needs a number, not a %s", fn, type_name(v));
    return v.u.n;
}
Str *lib_str(Value v, const char *fn) {
    if (v.t != T_STR) sage_error("%s() needs text, not a %s", fn, type_name(v));
    return AS_STR(v);
}
Value lib_text(const char *s, int len) { return v_str(str_new(s, len)); }
static Value lib_list(List *l) { return v_obj(T_LIST, l); }

/* ---------- math ---------- */
#define M1(fname, cfn) NATIVE(fname) { return v_num(cfn(lib_num(argv[0], #cfn))); }
M1(m_sqrt, sqrt) M1(m_sin, sin) M1(m_cos, cos) M1(m_tan, tan) M1(m_asin, asin) M1(m_acos, acos)
M1(m_atan, atan) M1(m_log10, log10) M1(m_log2, log2) M1(m_exp, exp) M1(m_floor, floor)
M1(m_ceil, ceil) M1(m_trunc, trunc) M1(m_fabs, fabs)
NATIVE(m_atan2) { return v_num(atan2(lib_num(argv[0], "atan2"), lib_num(argv[1], "atan2"))); }
NATIVE(m_pow) { return v_num(pow(lib_num(argv[0], "pow"), lib_num(argv[1], "pow"))); }
NATIVE(m_hypot) { return v_num(hypot(lib_num(argv[0], "hypot"), lib_num(argv[1], "hypot"))); }
NATIVE(m_log) {
    double x = lib_num(argv[0], "log");
    return v_num(argc > 1 ? log(x) / log(lib_num(argv[1], "log")) : log(x));
}
NATIVE(m_degrees) { return v_num(lib_num(argv[0], "degrees") * 180.0 / M_PI); }
NATIVE(m_radians) { return v_num(lib_num(argv[0], "radians") * M_PI / 180.0); }
NATIVE(m_isnan) { return v_bool(isnan(lib_num(argv[0], "isnan"))); }
NATIVE(m_isinf) { return v_bool(isinf(lib_num(argv[0], "isinf"))); }
static double gcd_d(double a, double b) { a = fabs(a); b = fabs(b); while (b) { double t = fmod(a, b); a = b; b = t; } return a; }
NATIVE(m_gcd) { return v_num(gcd_d(lib_num(argv[0], "gcd"), lib_num(argv[1], "gcd"))); }
NATIVE(m_lcm) {
    double a = lib_num(argv[0], "lcm"), b = lib_num(argv[1], "lcm");
    return v_num(a == 0 || b == 0 ? 0 : fabs(a * b) / gcd_d(a, b));
}
NATIVE(m_factorial) {
    double n = lib_num(argv[0], "factorial");
    if (n < 0 || n != floor(n)) sage_error("factorial() needs a whole number that is not negative");
    double r = 1;
    for (int i = 2; i <= (int)n; i++) r *= i;
    return v_num(r);
}
NATIVE(m_sign) { double x = lib_num(argv[0], "sign"); return v_num(x > 0 ? 1 : x < 0 ? -1 : 0); }
static Native math_natives[] = {
    {"sqrt", m_sqrt, 1, 1}, {"sin", m_sin, 1, 1}, {"cos", m_cos, 1, 1}, {"tan", m_tan, 1, 1},
    {"asin", m_asin, 1, 1}, {"acos", m_acos, 1, 1}, {"atan", m_atan, 1, 1}, {"atan2", m_atan2, 2, 2},
    {"log", m_log, 1, 2}, {"log10", m_log10, 1, 1}, {"log2", m_log2, 1, 1}, {"exp", m_exp, 1, 1},
    {"pow", m_pow, 2, 2}, {"floor", m_floor, 1, 1}, {"ceil", m_ceil, 1, 1}, {"trunc", m_trunc, 1, 1},
    {"abs", m_fabs, 1, 1}, {"hypot", m_hypot, 2, 2}, {"degrees", m_degrees, 1, 1},
    {"radians", m_radians, 1, 1}, {"gcd", m_gcd, 2, 2}, {"lcm", m_lcm, 2, 2},
    {"factorial", m_factorial, 1, 1}, {"isnan", m_isnan, 1, 1}, {"isinf", m_isinf, 1, 1},
    {"sign", m_sign, 1, 1}, {NULL, NULL, 0, 0}
};

/* ---------- random ---------- */
NATIVE(r_random) { return v_num(sage_random()); }
NATIVE(r_uniform) {
    double a = lib_num(argv[0], "uniform"), b = lib_num(argv[1], "uniform");
    return v_num(a + (b - a) * sage_random());
}
NATIVE(r_randint) {
    double a = lib_num(argv[0], "randint"), b = lib_num(argv[1], "randint");
    if (b < a) sage_error("randint() needs the first number to be the smaller one");
    return v_num(a + floor(sage_random() * (b - a + 1)));
}
NATIVE(r_choice) {
    List *l = AS_LIST(iter_items(argv[0]));
    if (l->len == 0) sage_error("choice() needs a list that is not empty");
    return l->items[(int)(sage_random() * l->len)];
}
NATIVE(r_shuffle) {
    if (argv[0].t != T_LIST) sage_error("shuffle() needs a list, not a %s", type_name(argv[0]));
    List *l = AS_LIST(argv[0]);
    for (int i = l->len - 1; i > 0; i--) {
        int j = (int)(sage_random() * (i + 1));
        Value t = l->items[i]; l->items[i] = l->items[j]; l->items[j] = t;
    }
    return v_nothing();
}
NATIVE(r_seed) { sage_seed(lib_num(argv[0], "seed")); return v_nothing(); }
static Native random_natives[] = {
    {"random", r_random, 0, 0}, {"uniform", r_uniform, 2, 2}, {"randint", r_randint, 2, 2},
    {"choice", r_choice, 1, 1}, {"shuffle", r_shuffle, 1, 1}, {"seed", r_seed, 1, 1},
    {NULL, NULL, 0, 0}
};

/* ---------- os ---------- */
NATIVE(o_getcwd) { char b[4096]; return getcwd(b, sizeof b) ? lib_text(b, (int)strlen(b)) : v_nothing(); }
static int cmp_text(const void *a, const void *b) { return strcmp(*(char *const *)a, *(char *const *)b); }
NATIVE(o_listdir) {
    DIR *d = opendir(argc ? lib_str(argv[0], "listdir")->s : ".");
    if (!d) sage_error("cannot open folder '%s'", argc ? AS_STR(argv[0])->s : ".");
    char **names = NULL; int n = 0;
    struct dirent *e;
    while ((e = readdir(d))) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
        names = xrealloc(names, sizeof(char *) * (n + 1));
        names[n++] = strdup(e->d_name);
    }
    closedir(d);
    qsort(names, n, sizeof(char *), cmp_text);
    List *l = list_new(n);
    for (int i = 0; i < n; i++) { list_push(l, lib_text(names[i], (int)strlen(names[i]))); free(names[i]); }
    free(names);
    return lib_list(l);
}
NATIVE(o_exists) { return v_bool(access(lib_str(argv[0], "exists")->s, F_OK) == 0); }
NATIVE(o_is_dir) { struct stat st; return v_bool(stat(lib_str(argv[0], "is_dir")->s, &st) == 0 && S_ISDIR(st.st_mode)); }
NATIVE(o_is_file) { struct stat st; return v_bool(stat(lib_str(argv[0], "is_file")->s, &st) == 0 && S_ISREG(st.st_mode)); }
NATIVE(o_mkdir) {
    Str *p = lib_str(argv[0], "mkdir");
    if (mkdir(p->s, 0777) != 0 && access(p->s, F_OK) != 0) sage_error("cannot create folder '%s'", p->s);
    return v_nothing();
}
NATIVE(o_remove) {
    Str *p = lib_str(argv[0], "remove");
    if (remove(p->s) != 0) sage_error("cannot remove '%s'", p->s);
    return v_nothing();
}
NATIVE(o_rename) {
    Str *a = lib_str(argv[0], "rename"), *b = lib_str(argv[1], "rename");
    if (rename(a->s, b->s) != 0) sage_error("cannot rename '%s' to '%s'", a->s, b->s);
    return v_nothing();
}
NATIVE(o_getenv) {
    const char *v = getenv(lib_str(argv[0], "getenv")->s);
    if (v) return lib_text(v, (int)strlen(v));
    return argc > 1 ? argv[1] : v_nothing();
}
NATIVE(o_join) {
    SB sb; sb_init(&sb);
    for (int i = 0; i < argc; i++) {
        Str *p = lib_str(argv[i], "join");
        if (i && sb.len && sb.s[sb.len - 1] != '/' && p->s[0] != '/') sb_addc(&sb, '/');
        if (p->s[0] == '/') sb.len = 0;
        sb_add(&sb, p->s, p->len);
    }
    return v_str(sb_finish(&sb));
}
NATIVE(o_basename) {
    Str *p = lib_str(argv[0], "basename");
    const char *sl = strrchr(p->s, '/');
    return lib_text(sl ? sl + 1 : p->s, (int)strlen(sl ? sl + 1 : p->s));
}
NATIVE(o_dirname) {
    Str *p = lib_str(argv[0], "dirname");
    const char *sl = strrchr(p->s, '/');
    if (!sl) return lib_text(".", 1);
    return lib_text(p->s, sl == p->s ? 1 : (int)(sl - p->s));
}
NATIVE(o_extension) {
    Str *p = lib_str(argv[0], "extension");
    const char *sl = strrchr(p->s, '/'), *dot = strrchr(sl ? sl : p->s, '.');
    return dot ? lib_text(dot, (int)strlen(dot)) : lib_text("", 0);
}
NATIVE(o_system) { fflush(stdout); return v_num(system(lib_str(argv[0], "system")->s)); }
NATIVE(o_capture) {
    fflush(stdout);
    FILE *f = popen(lib_str(argv[0], "capture")->s, "r");
    if (!f) sage_error("cannot run that command");
    SB sb; sb_init(&sb);
    char buf[1024]; size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) sb_add(&sb, buf, (int)n);
    pclose(f);
    return v_str(sb_finish(&sb));
}
static Native os_natives[] = {
    {"getcwd", o_getcwd, 0, 0}, {"listdir", o_listdir, 0, 1}, {"exists", o_exists, 1, 1},
    {"is_dir", o_is_dir, 1, 1}, {"is_file", o_is_file, 1, 1}, {"mkdir", o_mkdir, 1, 1},
    {"remove", o_remove, 1, 1}, {"rename", o_rename, 2, 2}, {"getenv", o_getenv, 1, 2},
    {"join", o_join, 1, -1}, {"basename", o_basename, 1, 1}, {"dirname", o_dirname, 1, 1},
    {"extension", o_extension, 1, 1}, {"system", o_system, 1, 1}, {"capture", o_capture, 1, 1},
    {NULL, NULL, 0, 0}
};

/* ---------- time ---------- */
NATIVE(t_now) { struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts); return v_num((double)ts.tv_sec + ts.tv_nsec * 1e-9); }
NATIVE(t_monotonic) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return v_num((double)ts.tv_sec + ts.tv_nsec * 1e-9); }
NATIVE(t_sleep) {
    double s = lib_num(argv[0], "sleep");
    if (s < 0) s = 0;
    fflush(stdout);
    struct timespec ts = { (time_t)s, (long)((s - floor(s)) * 1e9) };
    nanosleep(&ts, NULL);
    return v_nothing();
}
static struct tm *tm_of(Value *argv, int argc, const char *fn, struct tm *out) {
    time_t t = argc > 0 ? (time_t)lib_num(argv[0], fn) : time(NULL);
    return localtime_r(&t, out);
}
NATIVE(t_format) {
    struct tm tmv, *tp = tm_of(argv, argc, "format", &tmv);
    const char *fmt = argc > 1 ? lib_str(argv[1], "format")->s : "%Y-%m-%d %H:%M:%S";
    char buf[512];
    size_t n = strftime(buf, sizeof buf, fmt, tp);
    return lib_text(buf, (int)n);
}
NATIVE(t_parts) {
    struct tm tmv, *tp = tm_of(argv, argc, "parts", &tmv);
    Dict *d = dict_new();
    const char *keys[] = { "year", "month", "day", "hour", "minute", "second", "weekday", "yearday" };
    double vals[] = { tp->tm_year + 1900, tp->tm_mon + 1, tp->tm_mday, tp->tm_hour, tp->tm_min, tp->tm_sec, tp->tm_wday, tp->tm_yday + 1 };
    for (int i = 0; i < 8; i++) dict_set(d, v_str(intern(keys[i], (int)strlen(keys[i]))), v_num(vals[i]));
    return v_obj(T_DICT, d);
}
static Native time_natives[] = {
    {"now", t_now, 0, 0}, {"monotonic", t_monotonic, 0, 0}, {"sleep", t_sleep, 1, 1},
    {"format", t_format, 0, 2}, {"parts", t_parts, 0, 1}, {NULL, NULL, 0, 0}
};

/* ---------- module table ---------- */
static void put(Dict *d, const char *name, Value v) { dict_set(d, v_str(intern(name, (int)strlen(name))), v); }

static Dict *table_dict(Native *tab) {
    Dict *d = dict_new();
    for (Native *n = tab; n->name; n++) put(d, n->name, v_obj(T_NATIVE, n));
    return d;
}

Value stdlib_module(const char *name) {
    Dict *d = NULL;
    if (!strcmp(name, "math")) {
        d = table_dict(math_natives);
        put(d, "pi", v_num(M_PI)); put(d, "e", v_num(M_E)); put(d, "tau", v_num(2 * M_PI));
        put(d, "inf", v_num(INFINITY)); put(d, "nan", v_num(NAN));
    } else if (!strcmp(name, "random")) d = table_dict(random_natives);
    else if (!strcmp(name, "os")) {
        d = table_dict(os_natives);
        put(d, "sep", lib_text("/", 1)); put(d, "name", lib_text("posix", 5));
    } else if (!strcmp(name, "time")) d = table_dict(time_natives);
    else if (!strcmp(name, "json")) d = table_dict(json_natives);
    else if (!strcmp(name, "csv")) d = table_dict(csv_natives);
    else if (!strcmp(name, "re")) d = table_dict(re_natives);
    return d ? make_module_value(d) : v_nothing();
}
