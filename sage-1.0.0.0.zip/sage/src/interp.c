/* Tree-walking evaluator: expressions, statements, functions, classes. */
#include "sage.h"
#include <alloca.h>
#include <unistd.h>

Env *globals;
static Value g_ret;
typedef enum { S_NORMAL, S_BREAK, S_CONTINUE, S_RETURN } Status;

static Value eval(Node *n, Env *env);
static Status exec(Node *n, Env *env);

/* ---------- small helpers ---------- */
char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = xmalloc(sz + 1);
    size_t got = fread(buf, 1, sz, f);
    buf[got] = 0;
    fclose(f);
    return buf;
}

static Value make_func(Node *def, Env *env, Class *home) {
    Func *f = gc_alloc(sizeof(Func), GC_FUNC);
    f->def = def; f->closure = env; f->home = home;
    return v_obj(T_FUNC, f);
}
static Value make_bound(Value self, Value fn) {
    Bound *b = gc_alloc(sizeof(Bound), GC_BOUND);
    b->self = self; b->fn = fn;
    return v_obj(T_BOUND, b);
}

static void arity_error(const char *name, int min, int max, int got) {
    const char *was = got == 1 ? "was" : "were";
    if (min == max)
        sage_error("%s() takes %d argument%s but %d %s given", name, min, min == 1 ? "" : "s", got, was);
    if (max < 0)
        sage_error("%s() takes at least %d argument%s but %d %s given", name, min, min == 1 ? "" : "s", got, was);
    sage_error("%s() takes %d to %d arguments but %d %s given", name, min, max, got, was);
}

/* ---------- calls ---------- */
static Value call_native(Native *nat, bool method, Value self, int argc, Value *argv, KW *kw) {
    Value tmp[argc + 2];
    if (kw && kw->n) {
        bool sorting = !strcmp(nat->name, "sorted") || !strcmp(nat->name, "sort");
        if (sorting && kw->n == 1 && !strcmp(kw->names[0]->s, "key")) {
            for (int i = 0; i < argc; i++) tmp[i] = argv[i];
            tmp[argc] = kw->vals[0];
            argv = tmp; argc++;
        } else sage_error("the built-in %s() does not take keyword arguments", nat->name);
    }
    if (argc < nat->min || (nat->max >= 0 && argc > nat->max)) arity_error(nat->name, nat->min, nat->max, argc);
    if (!method) return nat->fn(argc, argv);
    Value av[argc + 1];
    av[0] = self;
    for (int i = 0; i < argc; i++) av[i + 1] = argv[i];
    return nat->fn(argc + 1, av);
}

static Value call_func(Func *f, bool has_self, Value self, int argc, Value *argv, KW *kw) {
    Node *d = f->def;
    const char *fname = d->name ? d->name->s : "lambda";
    int np = d->npos, total = d->nparams;
    bool general = (kw && kw->n) || d->rest || d->kwrest || np != total;
    if (!general && (argc < d->op || argc > total)) arity_error(fname, d->op, total, argc);
    if (call_depth >= MAX_CALL_DEPTH) sage_error("maximum recursion depth exceeded");
    gc_safepoint();
    call_depth++;
    Env *env = env_new(f->closure);
    if (has_self) {
        env_define(env, S_self, self);
        env_define(env, S_home, v_obj(T_CLASS, f->home));
    }
    if (!general) {
        for (int i = 0; i < total; i++)
            env_define(env, d->params[i], i < argc ? argv[i] : eval(d->kids2[i], env));
    } else {
        Value vals[total + 1];
        bool set[total + 1];
        for (int i = 0; i < total; i++) set[i] = false;
        List *restl = d->rest ? list_new(0) : NULL;
        Dict *kwd = d->kwrest ? dict_new() : NULL;
        for (int i = 0; i < argc; i++) {
            if (i < np) { vals[i] = argv[i]; set[i] = true; }
            else if (restl) list_push(restl, argv[i]);
            else arity_error(fname, d->op, np, argc);
        }
        for (int j = 0; kw && j < kw->n; j++) {
            int k = -1;
            for (int m = 0; m < total; m++) if (d->params[m] == kw->names[j]) { k = m; break; }
            if (k >= 0) {
                if (set[k]) sage_error("%s() got more than one value for '%s'", fname, kw->names[j]->s);
                vals[k] = kw->vals[j]; set[k] = true;
            } else if (kwd) dict_set(kwd, v_str(kw->names[j]), kw->vals[j]);
            else sage_error("%s() has no parameter called '%s'", fname, kw->names[j]->s);
        }
        for (int i = 0; i < total; i++) {
            if (set[i]) env_define(env, d->params[i], vals[i]);
            else if (d->kids2[i]) env_define(env, d->params[i], eval(d->kids2[i], env));
            else sage_error("%s() is missing a value for '%s'", fname, d->params[i]->s);
        }
        if (d->rest) env_define(env, d->rest, v_obj(T_LIST, restl));
        if (d->kwrest) env_define(env, d->kwrest, v_obj(T_DICT, kwd));
    }
    Value result = v_nothing();
    if (d->kind == N_LAMBDA) result = eval(d->a, env);
    else if (exec(d->b, env) == S_RETURN) result = g_ret;
    call_depth--;
    return result;
}

static Value call_method_kw(Value self, Value fn, int argc, Value *argv, KW *kw) {
    if (fn.t == T_FUNC) return call_func(AS_FUNC(fn), true, self, argc, argv, kw);
    if (fn.t == T_NATIVE) return call_native(AS_NATIVE(fn), true, self, argc, argv, kw);
    return call_value_kw(fn, argc, argv, kw);
}
Value call_method(Value self, Value fn, int argc, Value *argv) { return call_method_kw(self, fn, argc, argv, NULL); }

static Value instantiate(Class *c, int argc, Value *argv, KW *kw) {
    Inst *in = gc_alloc(sizeof(Inst), GC_INST);
    in->cls = c; in->fields = dict_new();
    Value self = v_obj(T_INST, in), init;
    if (class_find(c, S_init, &init)) call_method_kw(self, init, argc, argv, kw);
    else if (argc > 0 || (kw && kw->n)) sage_error("%s() takes no arguments but some were given", c->name->s);
    return self;
}

Value call_value_kw(Value f, int argc, Value *argv, KW *kw) {
    switch (f.t) {
    case T_FUNC: return call_func(AS_FUNC(f), false, v_nothing(), argc, argv, kw);
    case T_NATIVE: return call_native(AS_NATIVE(f), false, v_nothing(), argc, argv, kw);
    case T_BOUND: return call_method_kw(AS_BOUND(f)->self, AS_BOUND(f)->fn, argc, argv, kw);
    case T_CLASS: return instantiate(AS_CLASS(f), argc, argv, kw);
    case T_INST: {
        Value m;
        if (!AS_INST(f)->extra && class_find(AS_INST(f)->cls, intern("__call__", 8), &m))
            return call_method_kw(f, m, argc, argv, kw);
        sage_error("a %s object is not callable", AS_INST(f)->cls->name->s);
    }
    default: sage_error("a %s is not callable", type_name(f));
    }
}
Value call_value(Value f, int argc, Value *argv) { return call_value_kw(f, argc, argv, NULL); }

/* Call a special method such as __add__ on an instance, if its class defines it. */
bool inst_dunder(Value self, const char *name, int argc, Value *argv, Value *out) {
    Value fn;
    if (self.t != T_INST || AS_INST(self)->extra) return false;
    if (!class_find(AS_INST(self)->cls, intern(name, (int)strlen(name)), &fn)) return false;
    *out = call_method_kw(self, fn, argc, argv, NULL);
    return true;
}

/* ---------- attributes, indexing ---------- */
static Value get_attr(Value obj, Str *name) {
    Value v;
    switch (obj.t) {
    case T_INST:
        if (AS_INST(obj)->extra) {
            if (env_lookup_local(AS_INST(obj)->extra, name, &v)) return v;
            sage_error("the module has no name '%s'", name->s);
        }
        if (dict_get(AS_INST(obj)->fields, v_str(name), &v)) return v;
        if (class_find(AS_INST(obj)->cls, name, &v)) return make_bound(obj, v);
        sage_error("'%s' object has no attribute '%s'", AS_INST(obj)->cls->name->s, name->s);
    case T_CLASS:
        if (class_find(AS_CLASS(obj), name, &v)) return v;
        sage_error("class '%s' has no method '%s'", AS_CLASS(obj)->name->s, name->s);
    case T_STR: case T_LIST: case T_DICT: case T_TUPLE: case T_SET: {
        Native *nat = find_method(obj.t, name);
        if (!nat) sage_error("a %s has no method '%s'", type_name(obj), name->s);
        return make_bound(obj, v_obj(T_NATIVE, nat));
    }
    default: sage_error("a %s has no attributes", type_name(obj));
    }
}

static long norm_index(Value iv, long len) {
    if (iv.t != T_NUM) sage_error("an index must be a number, not a %s", type_name(iv));
    if (iv.u.n != floor(iv.u.n)) sage_error("an index must be a whole number");
    long i = (long)iv.u.n, orig = i;
    if (i < 0) i += len;
    if (i < 0 || i >= len) sage_error("index %ld is out of range (length %ld)", orig, len);
    return i;
}

static Value index_get(Value obj, Value idx) {
    switch (obj.t) {
    case T_LIST: case T_TUPLE: return AS_LIST(obj)->items[norm_index(idx, AS_LIST(obj)->len)];
    case T_STR: {
        Str *s = AS_STR(obj);
        long off = str_offset(s, norm_index(idx, s->ulen));
        int n = u8len((unsigned char)s->s[off]);
        if (off + n > s->len) n = s->len - (int)off;
        return v_str(str_new(s->s + off, n));
    }
    case T_DICT: {
        Value v;
        if (!dict_get(AS_DICT(obj), idx, &v)) sage_error("key %s not found", repr_str(idx)->s);
        return v;
    }
    case T_INST: {
        Value r;
        if (inst_dunder(obj, "__getitem__", 1, &idx, &r)) return r;
        sage_error("a %s object cannot be indexed (it has no __getitem__)", AS_INST(obj)->cls->name->s);
    }
    default: sage_error("a %s cannot be indexed", type_name(obj));
    }
}

static long slice_bound(Value v, long len, long dflt) {
    if (v.t == T_NOTHING) return dflt;
    if (v.t != T_NUM || v.u.n != floor(v.u.n)) sage_error("slice bounds must be whole numbers");
    long i = (long)v.u.n;
    if (i < 0) i += len;
    return i < 0 ? 0 : i > len ? len : i;
}

static Value do_slice(Value obj, Value from, Value to) {
    if (obj.t == T_STR) {
        Str *s = AS_STR(obj);
        long len = s->ulen, a = slice_bound(from, len, 0), b = slice_bound(to, len, len);
        if (b < a) b = a;
        long oa = str_offset(s, a), ob = str_offset(s, b);
        return v_str(str_new(s->s + oa, (int)(ob - oa)));
    }
    if (obj.t == T_LIST || obj.t == T_TUPLE) {
        long len = AS_LIST(obj)->len, a = slice_bound(from, len, 0), b = slice_bound(to, len, len);
        List *r = list_new(b > a ? (int)(b - a) : 0);
        for (long i = a; i < b; i++) list_push(r, AS_LIST(obj)->items[i]);
        return v_obj(obj.t, r);
    }
    sage_error("a %s cannot be sliced", type_name(obj));
}

Value iter_items(Value v) {
    if (v.t == T_LIST) return v;
    if (v.t == T_TUPLE) return v_obj(T_LIST, v.u.p);
    List *r = list_new(0);
    if (v.t == T_STR) {
        Str *s = AS_STR(v);
        for (int i = 0; i < s->len;) {
            int n = u8len((unsigned char)s->s[i]);
            if (i + n > s->len) n = s->len - i;
            list_push(r, v_str(str_new(s->s + i, n)));
            i += n;
        }
    } else if (v.t == T_DICT || v.t == T_SET) {
        Dict *d = AS_DICT(v);
        DICT_EACH(d, i) list_push(r, d->e[i].k);
    } else if (v.t == T_INST) {
        Value it;
        if (inst_dunder(v, "__iter__", 0, NULL, &it)) return iter_items(it);
        sage_error("a %s object cannot be looped over (it has no __iter__)", AS_INST(v)->cls->name->s);
    } else sage_error("cannot loop over a %s", type_name(v));
    return v_obj(T_LIST, r);
}

/* ---------- operators ---------- */
static const char *OPNAMES[] = { "", "+", "-", "*", "/", "//", "%", "**", "==", "!=", "<", ">", "<=", ">=", "in", "not in", "|", "&" };

static Value concat_str(Value a, Value b) {
    Str *x = to_str(a), *y = to_str(b);
    SB sb; sb_init(&sb);
    sb_add(&sb, x->s, x->len);
    sb_add(&sb, y->s, y->len);
    return v_str(sb_finish(&sb));
}

static bool contains(Value container, Value item) {
    if (container.t == T_LIST || container.t == T_TUPLE) {
        List *l = AS_LIST(container);
        for (int i = 0; i < l->len; i++) if (values_equal(l->items[i], item)) return true;
        return false;
    }
    if (container.t == T_STR) {
        if (item.t != T_STR) sage_error("can only look for text inside text, not a %s", type_name(item));
        return strstr(AS_STR(container)->s, AS_STR(item)->s) != NULL;
    }
    if (container.t == T_DICT || container.t == T_SET) return dict_get(AS_DICT(container), item, NULL);
    sage_error("cannot use 'in' with a %s", type_name(container));
}

static bool inst_binop(int op, Value a, Value b, Value *out) {
    static const char *fwd[] = { "", "__add__", "__sub__", "__mul__", "__truediv__", "__floordiv__", "__mod__", "__pow__",
                                 "__eq__", "__ne__", "__lt__", "__gt__", "__le__", "__ge__" };
    static const char *rev[] = { "", "__radd__", "__rsub__", "__rmul__", "__rtruediv__", "__rfloordiv__", "__rmod__", "__rpow__",
                                 "__eq__", "__ne__", "__gt__", "__lt__", "__ge__", "__le__" };
    if (op == OP_IN || op == OP_NOTIN) {
        if (!inst_dunder(b, "__contains__", 1, &a, out)) return false;
        if (op == OP_NOTIN) *out = v_bool(!truthy(*out));
        return true;
    }
    if (op == OP_UNION || op == OP_INTER) {
        const char *nm = op == OP_UNION ? "__or__" : "__and__";
        Value arg2 = b;
        return a.t == T_INST && inst_dunder(a, nm, 1, &arg2, out);
    }
    Value arg = b;
    if (a.t == T_INST && inst_dunder(a, fwd[op], 1, &arg, out)) return true;
    arg = a;
    if (b.t == T_INST && inst_dunder(b, rev[op], 1, &arg, out)) return true;
    if (op == OP_NE && a.t == T_INST && inst_dunder(a, "__eq__", 1, &b, out)) { *out = v_bool(!truthy(*out)); return true; }
    return false;
}

static Value binop(int op, Value a, Value b) {
    if (a.t == T_INST || b.t == T_INST) { Value r; if (inst_binop(op, a, b, &r)) return r; }
    if (a.t == T_SET && b.t == T_SET && (op == OP_UNION || op == OP_INTER || op == OP_SUB)) {
        Dict *x = AS_DICT(a), *y = AS_DICT(b), *r = dict_new();
        if (op == OP_UNION) {
            DICT_EACH(x, i) dict_set(r, x->e[i].k, v_bool(true));
            DICT_EACH(y, i) dict_set(r, y->e[i].k, v_bool(true));
        } else if (op == OP_INTER) {
            DICT_EACH(x, i) if (dict_get(y, x->e[i].k, NULL)) dict_set(r, x->e[i].k, v_bool(true));
        } else {
            DICT_EACH(x, i) if (!dict_get(y, x->e[i].k, NULL)) dict_set(r, x->e[i].k, v_bool(true));
        }
        return v_obj(T_SET, r);
    }
    if (a.t == T_TUPLE && b.t == T_TUPLE && op == OP_ADD) {
        List *r = list_new(AS_LIST(a)->len + AS_LIST(b)->len);
        for (int i = 0; i < AS_LIST(a)->len; i++) list_push(r, AS_LIST(a)->items[i]);
        for (int i = 0; i < AS_LIST(b)->len; i++) list_push(r, AS_LIST(b)->items[i]);
        return v_obj(T_TUPLE, r);
    }
    if (op == OP_MUL && ((a.t == T_TUPLE && b.t == T_NUM) || (a.t == T_NUM && b.t == T_TUPLE))) {
        Value t = a.t == T_TUPLE ? a : b;
        int cnt = (a.t == T_NUM ? a.u.n : b.u.n) < 0 ? 0 : (int)(a.t == T_NUM ? a.u.n : b.u.n);
        List *r = list_new(0);
        for (int i = 0; i < cnt; i++) for (int j = 0; j < AS_LIST(t)->len; j++) list_push(r, AS_LIST(t)->items[j]);
        return v_obj(T_TUPLE, r);
    }
    bool nums = a.t == T_NUM && b.t == T_NUM;
    switch (op) {
    case OP_EQ: return v_bool(values_equal(a, b));
    case OP_NE: return v_bool(!values_equal(a, b));
    case OP_LT: return v_bool(compare_values(a, b) < 0);
    case OP_GT: return v_bool(compare_values(a, b) > 0);
    case OP_LE: return v_bool(compare_values(a, b) <= 0);
    case OP_GE: return v_bool(compare_values(a, b) >= 0);
    case OP_IN: return v_bool(contains(b, a));
    case OP_NOTIN: return v_bool(!contains(b, a));
    case OP_ADD:
        if (nums) return v_num(a.u.n + b.u.n);
        if (a.t == T_STR || b.t == T_STR) return concat_str(a, b);
        if (a.t == T_LIST && b.t == T_LIST) {
            List *r = list_new(AS_LIST(a)->len + AS_LIST(b)->len);
            for (int i = 0; i < AS_LIST(a)->len; i++) list_push(r, AS_LIST(a)->items[i]);
            for (int i = 0; i < AS_LIST(b)->len; i++) list_push(r, AS_LIST(b)->items[i]);
            return v_obj(T_LIST, r);
        }
        break;
    case OP_SUB: if (nums) return v_num(a.u.n - b.u.n); break;
    case OP_MUL:
        if (nums) return v_num(a.u.n * b.u.n);
        if ((a.t == T_STR || a.t == T_LIST) && b.t == T_NUM) { Value t = a; a = b; b = t; }
        if (a.t == T_NUM && (b.t == T_STR || b.t == T_LIST)) {
            int cnt = a.u.n < 0 ? 0 : (int)a.u.n;
            if (b.t == T_STR) {
                SB sb; sb_init(&sb);
                for (int i = 0; i < cnt; i++) sb_add(&sb, AS_STR(b)->s, AS_STR(b)->len);
                return v_str(sb_finish(&sb));
            }
            List *r = list_new(0);
            for (int i = 0; i < cnt; i++)
                for (int j = 0; j < AS_LIST(b)->len; j++) list_push(r, AS_LIST(b)->items[j]);
            return v_obj(T_LIST, r);
        }
        break;
    case OP_DIV:
        if (nums) { if (b.u.n == 0) sage_error("division by zero"); return v_num(a.u.n / b.u.n); }
        break;
    case OP_IDIV:
        if (nums) { if (b.u.n == 0) sage_error("division by zero"); return v_num(floor(a.u.n / b.u.n)); }
        break;
    case OP_MOD:
        if (nums) {
            if (b.u.n == 0) sage_error("modulo by zero");
            double r = fmod(a.u.n, b.u.n);
            if (r != 0 && ((r < 0) != (b.u.n < 0))) r += b.u.n;
            return v_num(r);
        }
        break;
    case OP_POW: if (nums) return v_num(pow(a.u.n, b.u.n)); break;
    }
    sage_error("cannot use '%s' with a %s and a %s", OPNAMES[op], type_name(a), type_name(b));
}

/* ---------- expressions ---------- */
static void assign_target(Node *t, Value v, Env *env) {
    cur_line = t->line;
    if (t->kind == N_VAR) {
        env_set(env, t->name, v);
    } else if (t->kind == N_INDEX) {
        Value obj = eval(t->a, env), idx = eval(t->b, env);
        cur_line = t->line;
        if (obj.t == T_LIST) AS_LIST(obj)->items[norm_index(idx, AS_LIST(obj)->len)] = v;
        else if (obj.t == T_DICT) dict_set(AS_DICT(obj), idx, v);
        else if (obj.t == T_INST) {
            Value av[2] = { idx, v }, r;
            if (!inst_dunder(obj, "__setitem__", 2, av, &r))
                sage_error("a %s object does not support item assignment (it has no __setitem__)", AS_INST(obj)->cls->name->s);
        }
        else sage_error("a %s does not support item assignment", type_name(obj));
    } else {
        Value obj = eval(t->a, env);
        cur_line = t->line;
        if (obj.t != T_INST) sage_error("cannot set an attribute on a %s", type_name(obj));
        if (AS_INST(obj)->extra) env_set(AS_INST(obj)->extra, t->name, v);
        else dict_set(AS_INST(obj)->fields, v_str(t->name), v);
    }
}

static void bind_targets(Node *n, Env *env, Value item) {
    if (n->nparams == 1) { env_set(env, n->params[0], item); return; }
    if ((item.t != T_LIST && item.t != T_TUPLE) || AS_LIST(item)->len != n->nparams)
        sage_error("cannot unpack %s into %d names", repr_str(item)->s, n->nparams);
    for (int i = 0; i < n->nparams; i++) env_set(env, n->params[i], AS_LIST(item)->items[i]);
}

static Value get_attr(Value obj, Str *name);

/* obj.name(args) without building a bound-method object */
static Value call_attr(Value obj, Str *name, int argc, Value *argv, KW *kw) {
    Value fn;
    if (obj.t == T_INST) {
        if (AS_INST(obj)->extra) return call_value_kw(get_attr(obj, name), argc, argv, kw);
        if (dict_get(AS_INST(obj)->fields, v_str(name), &fn)) return call_value_kw(fn, argc, argv, kw);
        if (class_find(AS_INST(obj)->cls, name, &fn)) return call_method_kw(obj, fn, argc, argv, kw);
        sage_error("'%s' object has no method '%s'", AS_INST(obj)->cls->name->s, name->s);
    }
    if (obj.t == T_STR || obj.t == T_LIST || obj.t == T_DICT || obj.t == T_TUPLE || obj.t == T_SET) {
        Native *nat = find_method(obj.t, name);
        if (!nat) sage_error("a %s has no method '%s'", type_name(obj), name->s);
        return call_native(nat, true, obj, argc, argv, kw);
    }
    return call_value_kw(get_attr(obj, name), argc, argv, kw);
}

/* Calls that use *spread, name=value or **spread arguments. */
static Value eval_call_complex(Node *n, Env *env) {
    Node *cn = n->a;
    bool is_method = cn->kind == N_ATTR;
    Value obj = v_nothing(), fn = v_nothing();
    if (is_method) obj = eval(cn->a, env); else fn = eval(cn, env);
    int nk = n->nkids, npos = 0, nkw = 0;
    Value ev[nk + 1];
    for (int i = 0; i < nk; i++) {
        Node *k = n->kids[i];
        if (k->kind == N_SPREAD) {
            ev[i] = iter_items(eval(k->a, env));
            npos += AS_LIST(ev[i])->len;
        } else if (k->kind == N_KWSPREAD) {
            ev[i] = eval(k->a, env);
            cur_line = n->line;
            if (ev[i].t != T_DICT) sage_error("'**' needs a dict, not a %s", type_name(ev[i]));
            nkw += AS_DICT(ev[i])->len;
        } else if (k->kind == N_KWARG) {
            ev[i] = eval(k->a, env); nkw++;
        } else { ev[i] = eval(k, env); npos++; }
    }
    cur_line = n->line;
    if (npos > 4096 || nkw > 4096) sage_error("too many arguments in one call");
    Value *pos = alloca(sizeof(Value) * (npos + 1));
    Value *kv = alloca(sizeof(Value) * (nkw + 1));
    Str **kn = alloca(sizeof(Str *) * (nkw + 1));
    int pi = 0, ki = 0;
    for (int i = 0; i < nk; i++) {
        Node *k = n->kids[i];
        if (k->kind == N_SPREAD) {
            List *l = AS_LIST(ev[i]);
            for (int j = 0; j < l->len; j++) pos[pi++] = l->items[j];
        } else if (k->kind == N_KWSPREAD) {
            Dict *d = AS_DICT(ev[i]);
            DICT_EACH(d, j) {
                if (d->e[j].k.t != T_STR) sage_error("'**' keys must be text, not a %s", type_name(d->e[j].k));
                kn[ki] = intern(AS_STR(d->e[j].k)->s, AS_STR(d->e[j].k)->len);
                kv[ki++] = d->e[j].v;
            }
        } else if (k->kind == N_KWARG) {
            kn[ki] = k->name; kv[ki++] = ev[i];
        } else pos[pi++] = ev[i];
    }
    KW kw = { nkw, kn, kv };
    KW *kwp = nkw ? &kw : NULL;
    Value r = is_method ? call_attr(obj, cn->name, npos, pos, kwp) : call_value_kw(fn, npos, pos, kwp);
    cur_line = n->line;
    cur_file = n->file;
    return r;
}

static Value eval_call(Node *n, Env *env) {
    if (n->op) return eval_call_complex(n, env);
    int argc = n->nkids;
    Value argv[argc + 1], r;
    Node *cn = n->a;
    if (cn->kind == N_ATTR) {
        Value obj = eval(cn->a, env);
        for (int i = 0; i < argc; i++) argv[i] = eval(n->kids[i], env);
        cur_line = n->line;
        r = call_attr(obj, cn->name, argc, argv, NULL);
    } else {
        Value fn = eval(cn, env);
        for (int i = 0; i < argc; i++) argv[i] = eval(n->kids[i], env);
        cur_line = n->line;
        r = call_value(fn, argc, argv);
    }
    cur_line = n->line;
    cur_file = n->file;
    return r;
}

static Value eval(Node *n, Env *env) {
    switch (n->kind) {
    case N_LIT: return n->val;
    case N_VAR: {
        Value v;
        if (!env_get(env, n->name, &v)) { cur_line = n->line; sage_error("undefined variable '%s'", n->name->s); }
        return v;
    }
    case N_LIST: {
        List *l = list_new(n->nkids);
        for (int i = 0; i < n->nkids; i++) list_push(l, eval(n->kids[i], env));
        return v_obj(T_LIST, l);
    }
    case N_TUPLE: {
        List *l = list_new(n->nkids);
        for (int i = 0; i < n->nkids; i++) list_push(l, eval(n->kids[i], env));
        return v_obj(T_TUPLE, l);
    }
    case N_SETLIT: {
        Dict *d = dict_new();
        for (int i = 0; i < n->nkids; i++) {
            Value k = eval(n->kids[i], env);
            cur_line = n->line;
            dict_set(d, k, v_bool(true));
        }
        return v_obj(T_SET, d);
    }
    case N_DICT: {
        Dict *d = dict_new();
        for (int i = 0; i < n->nkids; i++) {
            Value k = eval(n->kids[i], env), v = eval(n->kids2[i], env);
            cur_line = n->line;
            dict_set(d, k, v);
        }
        return v_obj(T_DICT, d);
    }
    case N_BIN: {
        Value a = eval(n->a, env), b = eval(n->b, env);
        cur_line = n->line;
        return binop(n->op, a, b);
    }
    case N_AND: { Value l = eval(n->a, env); return truthy(l) ? eval(n->b, env) : l; }
    case N_OR:  { Value l = eval(n->a, env); return truthy(l) ? l : eval(n->b, env); }
    case N_NOT: return v_bool(!truthy(eval(n->a, env)));
    case N_NEG: {
        Value v = eval(n->a, env);
        cur_line = n->line;
        if (v.t == T_INST) { Value r; if (inst_dunder(v, "__neg__", 0, NULL, &r)) return r; }
        if (v.t != T_NUM) sage_error("cannot negate a %s", type_name(v));
        return v_num(-v.u.n);
    }
    case N_CALL: return eval_call(n, env);
    case N_INDEX: {
        Value o = eval(n->a, env), i = eval(n->b, env);
        cur_line = n->line;
        return index_get(o, i);
    }
    case N_SLICE: {
        Value o = eval(n->a, env);
        Value from = n->b ? eval(n->b, env) : v_nothing(), to = n->c ? eval(n->c, env) : v_nothing();
        cur_line = n->line;
        return do_slice(o, from, to);
    }
    case N_ATTR: {
        Value o = eval(n->a, env);
        cur_line = n->line;
        return get_attr(o, n->name);
    }
    case N_LAMBDA: return make_func(n, env, NULL);
    case N_TERN: return truthy(eval(n->a, env)) ? eval(n->b, env) : eval(n->c, env);
    case N_COMP: {
        Value src = eval(n->b, env);
        cur_line = n->line;
        List *items = AS_LIST(iter_items(src));
        List *out = list_new(0);
        Dict *dd = n->op ? dict_new() : NULL;
        Value result = n->op ? v_obj(n->op == 1 ? T_SET : T_DICT, dd) : v_obj(T_LIST, out);
        Env *ce = env_new(env);
        for (int i = 0; i < items->len; i++) {
            bind_targets(n, ce, items->items[i]);
            if (n->c && !truthy(eval(n->c, ce))) continue;
            if (n->op == 1) { Value k = eval(n->a, ce); cur_line = n->line; dict_set(dd, k, v_bool(true)); }
            else if (n->op == 2) { Value k = eval(n->a, ce), vv = eval(n->kids[0], ce); cur_line = n->line; dict_set(dd, k, vv); }
            else list_push(out, eval(n->a, ce));
        }
        return result;
    }
    case N_FSTR: {
        SB sb; sb_init(&sb);
        for (int i = 0; i < n->nkids; i++) {
            Str *s = to_str(eval(n->kids[i], env));
            sb_add(&sb, s->s, s->len);
        }
        return v_str(sb_finish(&sb));
    }
    case N_SUPER: {
        Value home, self, m;
        cur_line = n->line;
        if (!env_get(env, S_home, &home) || !env_get(env, S_self, &self))
            sage_error("'super' can only be used inside a method");
        Class *par = AS_CLASS(home)->parent;
        if (!par) sage_error("class '%s' has no parent class", AS_CLASS(home)->name->s);
        if (!class_find(par, n->name, &m)) sage_error("the parent class has no method '%s'", n->name->s);
        return make_bound(self, m);
    }
    default: break;
    }
    sage_error("internal error: cannot evaluate node %d", n->kind);
}

/* Apply @decorators (bottom one first) to a function or class. */
static Value decorate(Node *n, Value v, Env *env) {
    if (!n->c) return v;
    for (int i = n->c->nkids - 1; i >= 0; i--) {
        Value d = eval(n->c->kids[i], env);
        cur_line = n->line;
        v = call_value(d, 1, &v);
    }
    return v;
}

/* ---------- statements ---------- */
/* Which kind of error is this message? Runtime errors are plain text; this lets
   "catch ZeroDivisionError" and friends work on them. */
static const char *classify(const char *m) {
    if (strstr(m, "division by zero") || strstr(m, "modulo by zero")) return "ZeroDivisionError";
    if (!strncmp(m, "key ", 4) && strstr(m, "not found")) return "KeyError";
    if (strstr(m, "index") && strstr(m, "out of")) return "IndexError";
    if (strstr(m, "cannot open") || strstr(m, "cannot read") || strstr(m, "cannot write")) return "IOError";
    if (strstr(m, "cannot find module") || strstr(m, "has no name")) return "ImportError";
    if (!strncmp(m, "assertion failed", 16)) return "AssertionError";
    if (strstr(m, "cannot convert") || strstr(m, "invalid") || strstr(m, "bad pattern") || strstr(m, "json.parse")) return "ValueError";
    if (strstr(m, "cannot use") || strstr(m, "does not work") || strstr(m, "not callable") || strstr(m, "needs a") ||
        strstr(m, "cannot be indexed") || strstr(m, "cannot loop") || strstr(m, "does not support") || strstr(m, "cannot negate"))
        return "TypeError";
    return "RuntimeError";
}

static bool exc_matches(Value exc, Value spec) {
    if (spec.t == T_LIST || spec.t == T_TUPLE) {
        for (int i = 0; i < AS_LIST(spec)->len; i++) if (exc_matches(exc, AS_LIST(spec)->items[i])) return true;
        return false;
    }
    if (spec.t != T_CLASS) sage_error("'catch' needs an error class (like ValueError), not a %s", type_name(spec));
    if (exc.t == T_INST) return class_is(AS_INST(exc)->cls, AS_CLASS(spec));
    if (exc.t == T_STR) {
        const char *want = AS_CLASS(spec)->name->s;
        return !strcmp(want, "Error") || !strcmp(want, classify(AS_STR(exc)->s));
    }
    return false;
}

static Status exec_try(Node *n, Env *env) {
    bool volatile thrown = false;
    Status volatile st = S_NORMAL;
    Value exc = v_nothing();
    int volatile line = 0, file = 0;
    Handler h;
    h.prev = handlers; h.depth = call_depth;
    handlers = &h;
    if (setjmp(h.jb) == 0) {
        st = exec(n->a, env);
        handlers = h.prev;
    } else {
        handlers = h.prev;
        call_depth = h.depth;
        thrown = true;
        exc = exc_value; line = exc_line; file = exc_file;
    }
    if (thrown && n->nkids) {
        int volatile hit = -1;
        Handler hm;                                  /* evaluating a clause's class can fail too */
        hm.prev = handlers; hm.depth = call_depth;
        handlers = &hm;
        if (setjmp(hm.jb) == 0) {
            for (int i = 0; i < n->nkids; i++)
                if (!n->kids[i] || exc_matches(exc, eval(n->kids[i], env))) { hit = i; break; }
            handlers = hm.prev;
        } else {
            handlers = hm.prev;
            call_depth = hm.depth;
            exc = exc_value; line = exc_line; file = exc_file;
        }
        if (hit >= 0) {
            thrown = false;
            if (n->params[hit]) env_set(env, n->params[hit], exc);
            if (n->c) {
                Handler h2;
                h2.prev = handlers; h2.depth = call_depth;
                handlers = &h2;
                if (setjmp(h2.jb) == 0) {
                    st = exec(n->kids2[hit], env);
                    handlers = h2.prev;
                } else {
                    handlers = h2.prev;
                    call_depth = h2.depth;
                    thrown = true;
                    exc = exc_value; line = exc_line; file = exc_file;
                }
            } else st = exec(n->kids2[hit], env);
        }
    }
    if (n->c) {
        Value saved = g_ret;
        Status fs = exec(n->c, env);
        if (fs != S_NORMAL) return fs;               /* return/break inside finally wins */
        g_ret = saved;
    }
    if (thrown) { cur_line = line; cur_file = file; sage_throw(exc); }
    return st;
}

static Status exec_with(Node *n, Env *env) {
    Value mgr = eval(n->a, env);
    cur_line = n->line;
    Value bound = mgr, tmp;
    if (!inst_dunder(mgr, "__enter__", 0, NULL, &tmp))
        sage_error("'with' needs an object that has __enter__ and __exit__ methods, not a %s", type_name(mgr));
    bound = tmp;
    if (n->name) env_set(env, n->name, bound);
    Status volatile st = S_NORMAL;
    Handler h;
    h.prev = handlers; h.depth = call_depth;
    handlers = &h;
    if (setjmp(h.jb) == 0) {
        st = exec(n->b, env);
        handlers = h.prev;
        Value arg = v_nothing(), r;
        cur_line = n->line;
        if (!inst_dunder(mgr, "__exit__", 1, &arg, &r)) sage_error("the object has no __exit__ method");
        return st;
    }
    handlers = h.prev;
    call_depth = h.depth;
    Value exc = exc_value;
    int line = exc_line, file = exc_file;
    Value r;
    cur_line = n->line;
    if (inst_dunder(mgr, "__exit__", 1, &exc, &r) && truthy(r)) return S_NORMAL;   /* error handled */
    cur_line = line; cur_file = file;
    sage_throw(exc);
}

static Status exec_for(Node *n, Env *env) {
    Node *it = n->a;
    if (n->nparams == 1 && it->kind == N_CALL && it->a->kind == N_VAR && it->a->name == S_range &&
        it->nkids >= 1 && it->nkids <= 3) {
        Value f;
        if (env_get(env, S_range, &f) && f.t == T_NATIVE && AS_NATIVE(f)->fn == native_range) {
            double a[3];
            for (int i = 0; i < it->nkids; i++) {
                Value v = eval(it->kids[i], env);
                cur_line = n->line;
                if (v.t != T_NUM) sage_error("range() needs numbers, not a %s", type_name(v));
                a[i] = v.u.n;
            }
            double start = 0, stop, step = 1;
            if (it->nkids == 1) stop = a[0]; else { start = a[0]; stop = a[1]; if (it->nkids == 3) step = a[2]; }
            if (step == 0) sage_error("range() step cannot be zero");
            for (double x = start; step > 0 ? x < stop : x > stop; x += step) {
                env_set(env, n->params[0], v_num(x));
                Status s = exec(n->b, env);
                if (s == S_BREAK) break;
                if (s == S_RETURN) return s;
            }
            return S_NORMAL;
        }
    }
    Value src = eval(it, env);
    cur_line = n->line;
    List *l = AS_LIST(iter_items(src));
    for (int i = 0; i < l->len; i++) {
        bind_targets(n, env, l->items[i]);
        Status s = exec(n->b, env);
        if (s == S_BREAK) break;
        if (s == S_RETURN) return s;
    }
    return S_NORMAL;
}

static char *included[64];
static int n_included;

/* ---------- modules ---------- */
Class *module_class;
static Value module_cache;
static char *search_dirs[24];
static int n_search;

void add_search_dir(const char *dir) {
    for (int i = 0; i < n_search; i++) if (!strcmp(search_dirs[i], dir)) return;
    if (n_search < 24) search_dirs[n_search++] = strdup(dir);
}
static bool file_exists_at(const char *p) { return access(p, R_OK) == 0; }

static char *find_module_file(const char *dotted) {
    char rel[512];
    size_t k = 0;
    for (const char *c = dotted; *c && k < sizeof rel - 1; c++) rel[k++] = *c == '.' ? '/' : *c;
    rel[k] = 0;
    char path[1200];
    for (int i = 0; i < n_search; i++) {
        snprintf(path, sizeof path, "%s/%s.sage", search_dirs[i], rel);
        if (file_exists_at(path)) return strdup(path);
        snprintf(path, sizeof path, "%s/%s/init.sage", search_dirs[i], rel);
        if (file_exists_at(path)) return strdup(path);
    }
    return NULL;
}

Value make_module_value(Dict *fields) {
    Inst *in = gc_alloc(sizeof(Inst), GC_INST);
    in->cls = module_class; in->fields = fields; in->extra = NULL;
    return v_obj(T_INST, in);
}

static Value load_module(Str *name) {
    Value cached;
    if (dict_get(AS_DICT(module_cache), v_str(name), &cached)) return cached;
    Value mv = stdlib_module(name->s);
    if (mv.t == T_INST) { dict_set(AS_DICT(module_cache), v_str(name), mv); return mv; }

    char *path = find_module_file(name->s);
    if (!path) {
        SB sb; sb_init(&sb);
        for (int i = 0; i < n_search; i++) { if (i) sb_adds(&sb, ", "); sb_adds(&sb, search_dirs[i]); }
        sage_error("cannot find module '%s' (looked in: %s)", name->s, sb.s);
    }
    char *src = read_file(path);
    Env *menv = env_new(builtins);
    Inst *in = gc_alloc(sizeof(Inst), GC_INST);
    in->cls = module_class; in->fields = dict_new(); in->extra = menv;
    mv = v_obj(T_INST, in);
    dict_set(AS_DICT(module_cache), v_str(name), mv);       /* before running, so circular imports see it */
    env_define(menv, intern("__name__", 8), v_str(name));
    gc_perm++;
    Str *pathstr = str_cstr(path);
    gc_perm--;
    env_define(menv, intern("__file__", 8), v_str(pathstr));

    int saved_parse = parse_file, saved_file = cur_file, saved_line = cur_line;
    parse_file = register_file(path);
    Handler h;
    h.prev = handlers; h.depth = call_depth;
    handlers = &h;
    if (setjmp(h.jb) == 0) {
        Node *prog = parse_program(src);
        parse_file = saved_parse;
        for (int i = 0; i < prog->nkids; i++) exec(prog->kids[i], menv);
        handlers = h.prev;
    } else {
        handlers = h.prev;
        call_depth = h.depth;
        parse_file = saved_parse;
        dict_del(AS_DICT(module_cache), v_str(name));
        sage_throw(exc_value);
    }
    free(src); free(path);
    cur_file = saved_file; cur_line = saved_line;
    return mv;
}

static bool module_attr(Value m, Str *name, Value *out) {
    Inst *in = AS_INST(m);
    if (in->extra) return env_lookup_local(in->extra, name, out);
    return dict_get(in->fields, v_str(name), out);
}

static Status exec_import(Node *n, Env *env) {
    Value m = (!n->op && n->rest) ? v_nothing() : load_module(AS_STR(n->val));
    cur_line = n->line;
    if (!n->op && n->rest) {                                   /* import a.b.c */
        const char *full = AS_STR(n->val)->s;
        Value parent = v_nothing(), top = v_nothing();
        for (const char *dot = full;; ) {
            const char *next = strchr(dot, '.');
            int plen = next ? (int)(next - full) : (int)strlen(full);
            Str *prefix = intern(full, plen);
            Value mod;
            if (plen < (int)strlen(full) && !dict_get(AS_DICT(module_cache), v_str(prefix), &mod) &&
                stdlib_module(prefix->s).t != T_INST) {
                char *f = find_module_file(prefix->s);
                if (f) { free(f); mod = load_module(prefix); }
                else { mod = make_module_value(dict_new()); dict_set(AS_DICT(module_cache), v_str(prefix), mod); }
            } else mod = load_module(prefix);
            if (parent.t == T_INST) {
                const char *cs = dot;
                Str *cname = intern(cs, (int)(next ? next - cs : (int)strlen(cs)));
                if (AS_INST(parent)->extra) env_define(AS_INST(parent)->extra, cname, mod);
                else dict_set(AS_INST(parent)->fields, v_str(cname), mod);
            }
            if (top.t == T_NOTHING) top = mod;
            parent = mod;
            if (!next) break;
            dot = next + 1;
        }
        cur_line = n->line;
        env_set(env, n->rest, top);
        return S_NORMAL;
    }
    if (!n->op) { env_set(env, n->name, m); return S_NORMAL; }
    for (int i = 0; i < n->nparams; i += 2) {
        Value v;
        if (!module_attr(m, n->params[i], &v))
            sage_error("module '%s' has no name '%s'", AS_STR(n->val)->s, n->params[i]->s);
        env_set(env, n->params[i + 1], v);
    }
    return S_NORMAL;
}

static Status exec_use(Node *n, Env *env) {
    Value p = eval(n->a, env);
    cur_line = n->line;
    if (p.t != T_STR) sage_error("'use' needs a file name in quotes");
    for (int i = 0; i < n_included; i++)
        if (strcmp(included[i], AS_STR(p)->s) == 0) return S_NORMAL;
    char *src = read_file(AS_STR(p)->s);
    if (!src) sage_error("cannot open file '%s'", AS_STR(p)->s);
    if (n_included < 64) included[n_included++] = strdup(AS_STR(p)->s);
    Node *prog = parse_program(src);
    free(src);
    Env *root = module_root(env);
    for (int i = 0; i < prog->nkids; i++) exec(prog->kids[i], root);
    return S_NORMAL;
}

static Status exec(Node *n, Env *env) {
    gc_safepoint();
    cur_line = n->line;
    cur_file = n->file;
    switch (n->kind) {
    case N_BLOCK:
        for (int i = 0; i < n->nkids; i++) {
            Status s = exec(n->kids[i], env);
            if (s != S_NORMAL) return s;
        }
        return S_NORMAL;
    case N_EXPR: eval(n->a, env); return S_NORMAL;
    case N_SAY:
        {
            Str *parts[n->nkids + 1];              /* evaluate everything first, then print */
            for (int i = 0; i < n->nkids; i++) parts[i] = to_str(eval(n->kids[i], env));
            for (int i = 0; i < n->nkids; i++) {
                if (i) fputc(' ', stdout);
                fwrite(parts[i]->s, 1, parts[i]->len, stdout);
            }
            fputc('\n', stdout);
        }
        return S_NORMAL;
    case N_LET: env_define(env, n->name, eval(n->a, env)); return S_NORMAL;
    case N_ASSIGN: {
        if (n->op && n->a->kind == N_VAR && !env_has_local(env, n->a->name)) {
            Value outer;
            if (env_get(env, n->a->name, &outer))
                sage_error("'%s' belongs to an outer scope; write 'global %s' or 'nonlocal %s' inside this function before changing it",
                           n->a->name->s, n->a->name->s, n->a->name->s);
        }
        Value v = eval(n->b, env);
        if (n->op) { Value cur = eval(n->a, env); cur_line = n->line; v = binop(n->op, cur, v); }
        assign_target(n->a, v, env);
        return S_NORMAL;
    }
    case N_IF:
        for (int i = 0; i < n->nkids; i++)
            if (truthy(eval(n->kids[i], env))) return exec(n->kids2[i], env);
        return n->c ? exec(n->c, env) : S_NORMAL;
    case N_WHILE:
        while (truthy(eval(n->a, env))) {
            Status s = exec(n->b, env);
            if (s == S_BREAK) break;
            if (s == S_RETURN) return s;
        }
        return S_NORMAL;
    case N_FOR: return exec_for(n, env);
    case N_REPEAT: {
        Value c = eval(n->a, env);
        cur_line = n->line;
        if (c.t != T_NUM) sage_error("'repeat' needs a number, not a %s", type_name(c));
        for (long i = 0; i < (long)c.u.n; i++) {
            Status s = exec(n->b, env);
            if (s == S_BREAK) break;
            if (s == S_RETURN) return s;
        }
        return S_NORMAL;
    }
    case N_UNPACK: {
        Value src = eval(n->a, env);
        cur_line = n->line;
        List *items = AS_LIST(iter_items(src));
        if (items->len != n->nkids) sage_error("cannot unpack %d value%s into %d name%s", items->len, items->len == 1 ? "" : "s", n->nkids, n->nkids == 1 ? "" : "s");
        Value tmp[n->nkids + 1];
        for (int i = 0; i < n->nkids; i++) tmp[i] = items->items[i];
        for (int i = 0; i < n->nkids; i++) {
            if (n->op) env_define(env, n->kids[i]->name, tmp[i]);
            else assign_target(n->kids[i], tmp[i], env);
        }
        return S_NORMAL;
    }
    case N_GLOBAL: {
        for (int i = 0; i < n->nparams; i++) {
            Str *nm = n->params[i];
            Value marker;
            marker.t = T_ALIAS; marker.u.n = 0;
            if (n->op == 0) {
                if (env == module_root(env)) continue;
                marker.u.b = true;
            } else {
                if (env == module_root(env)) sage_error("'nonlocal' can only be used inside a function");
                bool found = false;
                for (Env *e = env->parent; e && e != module_root(env); e = e->parent)
                    if (env_has_local(e, nm)) { found = true; break; }
                if (!found) sage_error("no variable '%s' in an enclosing function to share", nm->s);
                marker.u.b = false;
            }
            env_define(env, nm, marker);
        }
        return S_NORMAL;
    }
    case N_DEF: env_define(env, n->name, decorate(n, make_func(n, env, NULL), env)); return S_NORMAL;
    case N_CLASS: {
        Class *parent = NULL;
        if (n->a) {
            Value pv = eval(n->a, env);
            cur_line = n->line;
            if (pv.t != T_CLASS) sage_error("a class can only extend another class, not a %s", type_name(pv));
            parent = AS_CLASS(pv);
        }
        Class *c = gc_alloc(sizeof(Class), GC_CLASS);
        c->name = n->name; c->parent = parent; c->methods = dict_new();
        for (int i = 0; i < n->nkids; i++)
            dict_set(c->methods, v_str(n->kids[i]->name), decorate(n->kids[i], make_func(n->kids[i], env, c), env));
        env_define(env, n->name, decorate(n, v_obj(T_CLASS, c), env));
        return S_NORMAL;
    }
    case N_RETURN: g_ret = n->a ? eval(n->a, env) : v_nothing(); return S_RETURN;
    case N_BREAK: return S_BREAK;
    case N_CONTINUE: return S_CONTINUE;
    case N_PASS: return S_NORMAL;
    case N_TRY: return exec_try(n, env);
    case N_RAISE: {
        Value v = eval(n->a, env);
        cur_line = n->line;
        sage_throw(v);
    }
    case N_USE: return exec_use(n, env);
    case N_IMPORT: return exec_import(n, env);
    case N_WITH: return exec_with(n, env);
    case N_ASSERT:
        if (!truthy(eval(n->a, env))) {
            cur_line = n->line;
            if (n->b) sage_error("assertion failed: %s", to_str(eval(n->b, env))->s);
            sage_error("assertion failed");
        }
        return S_NORMAL;
    default:
        eval(n, env);
        return S_NORMAL;
    }
}

/* ---------- entry points ---------- */
void interp_init(void) {
    init_names();
    builtins = env_new(NULL);
    gc_root_ptr((void **)&builtins);
    globals = env_new(builtins);
    gc_root_ptr((void **)&globals);
    module_cache = v_obj(T_DICT, dict_new());
    gc_root_value(&module_cache);
    module_class = gc_alloc(sizeof(Class), GC_CLASS);
    module_class->name = intern("module", 6);
    module_class->methods = dict_new();
    gc_root_ptr((void **)&module_class);
    gc_root_value(&g_ret);
    gc_root_value(&exc_value);
    register_builtins();
    load_prelude();
}

Value sage_getattr(Value o, Str *name) { return get_attr(o, name); }
Value sage_import(Str *name) { return load_module(name); }

extern const char *SAGE_PRELUDE;
void load_prelude(void) {
    Node *prog = parse_program(SAGE_PRELUDE);
    for (int i = 0; i < prog->nkids; i++) exec(prog->kids[i], builtins);
}

int run_source(const char *src, bool repl) {
    Handler h;
    h.prev = handlers; h.depth = call_depth;
    handlers = &h;
    if (setjmp(h.jb) == 0) {
        Node *prog = parse_program(src);
        for (int i = 0; i < prog->nkids; i++) {
            Node *s = prog->kids[i];
            if (repl && s->kind == N_EXPR) {
                cur_line = s->line;
                Value v = eval(s->a, globals);
                if (v.t != T_NOTHING) printf("%s\n", repr_str(v)->s);
            } else exec(s, globals);
        }
        handlers = h.prev;
        return 0;
    }
    handlers = h.prev;
    call_depth = h.depth;
    fflush(stdout);
    if (exc_file > 0 && file_names[exc_file])
        fprintf(stderr, "Error in %s on line %d: %s\n", file_names[exc_file], exc_line, to_str(exc_value)->s);
    else
        fprintf(stderr, "Error on line %d: %s\n", exc_line, to_str(exc_value)->s);
    return 1;
}
