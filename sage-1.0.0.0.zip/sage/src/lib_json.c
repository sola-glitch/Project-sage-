/* json and csv modules. */
#include "sage.h"
#include <ctype.h>

#define NATIVE(name) static Value name(__attribute__((unused)) int argc, __attribute__((unused)) Value *argv)

/* ---------- json.stringify ---------- */
static void js_string(SB *b, Str *s) {
    sb_addc(b, '"');
    for (int i = 0; i < s->len; i++) {
        unsigned char c = (unsigned char)s->s[i];
        switch (c) {
        case '"': sb_adds(b, "\\\""); break;
        case '\\': sb_adds(b, "\\\\"); break;
        case '\n': sb_adds(b, "\\n"); break;
        case '\r': sb_adds(b, "\\r"); break;
        case '\t': sb_adds(b, "\\t"); break;
        default:
            if (c < 0x20) { char u[8]; snprintf(u, sizeof u, "\\u%04x", c); sb_adds(b, u); }
            else sb_addc(b, (char)c);
        }
    }
    sb_addc(b, '"');
}
static void newline(SB *b, int indent, int level) {
    if (!indent) return;
    sb_addc(b, '\n');
    for (int i = 0; i < indent * level; i++) sb_addc(b, ' ');
}
static void js_write(SB *b, Value v, int indent, int level) {
    if (level > 100) sage_error("json.stringify(): the data is nested too deeply");
    switch (v.t) {
    case T_NOTHING: sb_adds(b, "null"); break;
    case T_BOOL: sb_adds(b, v.u.b ? "true" : "false"); break;
    case T_NUM:
        if (isnan(v.u.n) || isinf(v.u.n)) sb_adds(b, "null");
        else sb_adds(b, to_str(v)->s);
        break;
    case T_STR: js_string(b, AS_STR(v)); break;
    case T_LIST: case T_TUPLE: {
        List *l = AS_LIST(v);
        if (l->len == 0) { sb_adds(b, "[]"); break; }
        sb_addc(b, '[');
        for (int i = 0; i < l->len; i++) {
            if (i) sb_adds(b, indent ? "," : ", ");
            newline(b, indent, level + 1);
            js_write(b, l->items[i], indent, level + 1);
        }
        newline(b, indent, level);
        sb_addc(b, ']');
        break;
    }
    case T_SET: {
        Dict *d = AS_DICT(v);
        bool first = true;
        sb_addc(b, '[');
        DICT_EACH(d, i) {
            if (!first) sb_adds(b, ", ");
            first = false;
            js_write(b, d->e[i].k, indent, level + 1);
        }
        sb_addc(b, ']');
        break;
    }
    case T_DICT: {
        Dict *d = AS_DICT(v);
        if (d->len == 0) { sb_adds(b, "{}"); break; }
        bool first = true;
        sb_addc(b, '{');
        DICT_EACH(d, i) {
            if (!first) sb_adds(b, indent ? "," : ", ");
            first = false;
            newline(b, indent, level + 1);
            js_string(b, to_str(d->e[i].k));
            sb_adds(b, ": ");
            js_write(b, d->e[i].v, indent, level + 1);
        }
        newline(b, indent, level);
        sb_addc(b, '}');
        break;
    }
    default: sage_error("json.stringify() cannot convert a %s", type_name(v));
    }
}
NATIVE(j_stringify) {
    int indent = argc > 1 && argv[1].t == T_NUM ? (int)argv[1].u.n : 0;
    SB b; sb_init(&b);
    js_write(&b, argv[0], indent, 0);
    return v_str(sb_finish(&b));
}

/* ---------- json.parse ---------- */
typedef struct { const char *s; int i, n; } JP;
static void jfail(JP *p, const char *msg) { sage_error("json.parse(): %s at position %d", msg, p->i); }
static void jspace(JP *p) { while (p->i < p->n && isspace((unsigned char)p->s[p->i])) p->i++; }
static void put_utf8(SB *b, unsigned c) {
    if (c < 0x80) sb_addc(b, (char)c);
    else if (c < 0x800) { sb_addc(b, (char)(0xC0 | (c >> 6))); sb_addc(b, (char)(0x80 | (c & 0x3F))); }
    else if (c < 0x10000) { sb_addc(b, (char)(0xE0 | (c >> 12))); sb_addc(b, (char)(0x80 | ((c >> 6) & 0x3F))); sb_addc(b, (char)(0x80 | (c & 0x3F))); }
    else { sb_addc(b, (char)(0xF0 | (c >> 18))); sb_addc(b, (char)(0x80 | ((c >> 12) & 0x3F))); sb_addc(b, (char)(0x80 | ((c >> 6) & 0x3F))); sb_addc(b, (char)(0x80 | (c & 0x3F))); }
}
static unsigned hex4(JP *p) {
    unsigned v = 0;
    for (int k = 0; k < 4; k++) {
        if (p->i >= p->n || !isxdigit((unsigned char)p->s[p->i])) jfail(p, "bad \\u escape");
        char c = p->s[p->i++];
        v = v * 16 + (unsigned)(isdigit((unsigned char)c) ? c - '0' : (tolower(c) - 'a' + 10));
    }
    return v;
}
static Value jstring(JP *p) {
    SB b; sb_init(&b);
    p->i++;
    for (;;) {
        if (p->i >= p->n) jfail(p, "unterminated string");
        char c = p->s[p->i++];
        if (c == '"') break;
        if (c != '\\') { sb_addc(&b, c); continue; }
        if (p->i >= p->n) jfail(p, "unterminated string");
        c = p->s[p->i++];
        switch (c) {
        case 'n': sb_addc(&b, '\n'); break;
        case 't': sb_addc(&b, '\t'); break;
        case 'r': sb_addc(&b, '\r'); break;
        case 'b': sb_addc(&b, '\b'); break;
        case 'f': sb_addc(&b, '\f'); break;
        case 'u': {
            unsigned u = hex4(p);
            if (u >= 0xD800 && u < 0xDC00 && p->i + 1 < p->n && p->s[p->i] == '\\' && p->s[p->i + 1] == 'u') {
                p->i += 2;
                unsigned lo = hex4(p);
                u = 0x10000 + ((u - 0xD800) << 10) + (lo - 0xDC00);
            }
            put_utf8(&b, u);
            break;
        }
        default: sb_addc(&b, c);
        }
    }
    return v_str(sb_finish(&b));
}
static Value jvalue(JP *p, int depth) {
    if (depth > 200) jfail(p, "data nested too deeply");
    jspace(p);
    if (p->i >= p->n) jfail(p, "unexpected end");
    char c = p->s[p->i];
    if (c == '"') return jstring(p);
    if (c == '[') {
        List *l = list_new(0);
        Value lv = v_obj(T_LIST, l);
        p->i++; jspace(p);
        if (p->i < p->n && p->s[p->i] == ']') { p->i++; return lv; }
        for (;;) {
            list_push(l, jvalue(p, depth + 1));
            jspace(p);
            if (p->i < p->n && p->s[p->i] == ',') { p->i++; continue; }
            if (p->i < p->n && p->s[p->i] == ']') { p->i++; break; }
            jfail(p, "expected ',' or ']'");
        }
        return lv;
    }
    if (c == '{') {
        Dict *d = dict_new();
        Value dv = v_obj(T_DICT, d);
        p->i++; jspace(p);
        if (p->i < p->n && p->s[p->i] == '}') { p->i++; return dv; }
        for (;;) {
            jspace(p);
            if (p->i >= p->n || p->s[p->i] != '"') jfail(p, "expected a text key");
            Value k = jstring(p);
            jspace(p);
            if (p->i >= p->n || p->s[p->i] != ':') jfail(p, "expected ':'");
            p->i++;
            dict_set(d, k, jvalue(p, depth + 1));
            jspace(p);
            if (p->i < p->n && p->s[p->i] == ',') { p->i++; continue; }
            if (p->i < p->n && p->s[p->i] == '}') { p->i++; break; }
            jfail(p, "expected ',' or '}'");
        }
        return dv;
    }
    if (!strncmp(p->s + p->i, "true", 4)) { p->i += 4; return v_bool(true); }
    if (!strncmp(p->s + p->i, "false", 5)) { p->i += 5; return v_bool(false); }
    if (!strncmp(p->s + p->i, "null", 4)) { p->i += 4; return v_nothing(); }
    if (c == '-' || isdigit((unsigned char)c)) {
        char *end;
        double d = strtod(p->s + p->i, &end);
        if (end == p->s + p->i) jfail(p, "bad number");
        p->i = (int)(end - p->s);
        return v_num(d);
    }
    jfail(p, "unexpected character");
    return v_nothing();
}
NATIVE(j_parse) {
    if (argv[0].t != T_STR) sage_error("json.parse() needs text, not a %s", type_name(argv[0]));
    JP p = { AS_STR(argv[0])->s, 0, AS_STR(argv[0])->len };
    Value v = jvalue(&p, 0);
    jspace(&p);
    if (p.i < p.n) jfail(&p, "extra text after the value");
    return v;
}
Native json_natives[] = { {"stringify", j_stringify, 1, 2}, {"parse", j_parse, 1, 1}, {NULL, NULL, 0, 0} };

/* ---------- csv ---------- */
static char csv_sep(int argc, Value *argv, int idx) {
    if (argc > idx) {
        if (argv[idx].t != T_STR || AS_STR(argv[idx])->len != 1) sage_error("the csv separator must be one character");
        return AS_STR(argv[idx])->s[0];
    }
    return ',';
}
NATIVE(c_parse) {
    if (argv[0].t != T_STR) sage_error("csv.parse() needs text, not a %s", type_name(argv[0]));
    Str *s = AS_STR(argv[0]);
    char sep = csv_sep(argc, argv, 1);
    List *rows = list_new(0);
    Value rv = v_obj(T_LIST, rows);
    List *row = list_new(0);
    list_push(rows, v_obj(T_LIST, row));
    SB field; sb_init(&field);
    bool quoted = false, any = false;
    for (int i = 0; i <= s->len; i++) {
        char c = i < s->len ? s->s[i] : '\0';
        if (quoted) {
            if (i >= s->len) sage_error("csv.parse(): a quoted field is not closed");
            if (c == '"' && i + 1 < s->len && s->s[i + 1] == '"') { sb_addc(&field, '"'); i++; }
            else if (c == '"') quoted = false;
            else sb_addc(&field, c);
            continue;
        }
        if (c == '"' && field.len == 0) { quoted = true; any = true; continue; }
        if (c == sep || c == '\n' || c == '\0') {
            bool end_of_input = i >= s->len;
            if (!(end_of_input && field.len == 0 && row->len == 0 && !any)) {
                Str *f = str_new(field.s, field.len);
                list_push(row, v_str(f));
            }
            field.len = 0; field.s[0] = 0; any = false;
            if (c == '\n') { row = list_new(0); list_push(rows, v_obj(T_LIST, row)); }
            continue;
        }
        if (c == '\r') continue;
        sb_addc(&field, c);
    }
    free(field.s);
    if (rows->len && AS_LIST(rows->items[rows->len - 1])->len == 0) rows->len--;
    return rv;
}
NATIVE(c_stringify) {
    List *rows = AS_LIST(iter_items(argv[0]));
    char sep = csv_sep(argc, argv, 1);
    SB b; sb_init(&b);
    for (int r = 0; r < rows->len; r++) {
        List *row = AS_LIST(iter_items(rows->items[r]));
        for (int i = 0; i < row->len; i++) {
            if (i) sb_addc(&b, sep);
            Str *f = to_str(row->items[i]);
            bool need = false;
            for (int k = 0; k < f->len; k++) if (f->s[k] == sep || f->s[k] == '"' || f->s[k] == '\n') need = true;
            if (need) {
                sb_addc(&b, '"');
                for (int k = 0; k < f->len; k++) { if (f->s[k] == '"') sb_addc(&b, '"'); sb_addc(&b, f->s[k]); }
                sb_addc(&b, '"');
            } else sb_add(&b, f->s, f->len);
        }
        sb_addc(&b, '\n');
    }
    return v_str(sb_finish(&b));
}
NATIVE(c_dicts) {                      /* first row = header -> list of dicts */
    List *rows = AS_LIST(iter_items(argv[0]));
    List *out = list_new(rows->len);
    Value ov = v_obj(T_LIST, out);
    if (rows->len == 0) return ov;
    List *head = AS_LIST(iter_items(rows->items[0]));
    for (int r = 1; r < rows->len; r++) {
        List *row = AS_LIST(iter_items(rows->items[r]));
        Dict *d = dict_new();
        list_push(out, v_obj(T_DICT, d));
        for (int i = 0; i < head->len; i++) dict_set(d, head->items[i], i < row->len ? row->items[i] : v_nothing());
    }
    return ov;
}
Native csv_natives[] = {
    {"parse", c_parse, 1, 2}, {"stringify", c_stringify, 1, 2}, {"dicts", c_dicts, 1, 1}, {NULL, NULL, 0, 0}
};
