# Sage Language for VS Code

Language support for **Sage**, a plain-English, multi-paradigm programming language.

## Features

- Syntax highlighting for `.sage` files (keywords, f-strings, classes, functions, pipes)
- Smart indentation after lines that end with `:`
- Snippets: type `class`, `define`, `kwargs`, `for`, `try`, `pipe`, `comp` and press Tab
- Run commands:
  - **Sage: Run File** (play button in the editor title bar, or `Ctrl+Alt+R`)
  - **Sage: Run Selection (or Current Line)** (`Ctrl+Alt+Enter`)
  - **Sage: Open REPL**

## Requirements

The `sage` interpreter must be built and either on your `PATH` or set in the
`sage.executablePath` setting. See `docs/EDITOR_SETUP.md` in the Sage project.

## Settings

| Setting | Default | Meaning |
|---|---|---|
| `sage.executablePath` | `sage` | Path to the interpreter |
| `sage.clearTerminalBeforeRun` | `true` | Clear the terminal before each run |
