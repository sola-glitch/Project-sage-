// Sage Language extension: run commands. No dependencies.
const vscode = require('vscode');
const fs = require('fs');
const os = require('os');
const path = require('path');

let runTerminal;
let replTerminal;

function sageExe() {
  const configured = vscode.workspace.getConfiguration('sage').get('executablePath');
  return (configured && configured.trim()) || 'sage';
}

function quote(s) {
  return '"' + s.replace(/"/g, '\\"') + '"';
}

// PowerShell needs "& " in front of a quoted program path.
function command(file) {
  const shell = (vscode.env.shell || '').toLowerCase();
  const ps = shell.includes('powershell') || shell.includes('pwsh');
  return (ps ? '& ' : '') + quote(sageExe()) + ' ' + quote(file);
}

function getRunTerminal() {
  if (!runTerminal || runTerminal.exitStatus !== undefined) {
    runTerminal = vscode.window.createTerminal('Sage');
  }
  return runTerminal;
}

function runPath(file) {
  const term = getRunTerminal();
  term.show(true);
  if (vscode.workspace.getConfiguration('sage').get('clearTerminalBeforeRun')) {
    vscode.commands.executeCommand('workbench.action.terminal.clear');
  }
  term.sendText(command(file));
}

async function runFile() {
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    vscode.window.showWarningMessage('Open a .sage file first.');
    return;
  }
  if (editor.document.isUntitled) {
    vscode.window.showWarningMessage('Save the file as something.sage before running it.');
    return;
  }
  await editor.document.save();
  runPath(editor.document.fileName);
}

function runSelection() {
  const editor = vscode.window.activeTextEditor;
  if (!editor) return;
  const sel = editor.selection;
  const text = sel.isEmpty
    ? editor.document.lineAt(sel.active.line).text
    : editor.document.getText(sel);
  if (!text.trim()) return;
  const tmp = path.join(os.tmpdir(), 'sage-selection-' + process.pid + '.sage');
  fs.writeFileSync(tmp, text + '\n', 'utf8');
  runPath(tmp);
}

function openRepl() {
  if (!replTerminal || replTerminal.exitStatus !== undefined) {
    replTerminal = vscode.window.createTerminal({ name: 'Sage REPL', shellPath: sageExe() });
  }
  replTerminal.show();
}

function activate(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand('sage.runFile', runFile),
    vscode.commands.registerCommand('sage.runSelection', runSelection),
    vscode.commands.registerCommand('sage.openRepl', openRepl),
    vscode.window.onDidCloseTerminal((t) => {
      if (t === runTerminal) runTerminal = undefined;
      if (t === replTerminal) replTerminal = undefined;
    })
  );
}

function deactivate() {}

module.exports = { activate, deactivate };
