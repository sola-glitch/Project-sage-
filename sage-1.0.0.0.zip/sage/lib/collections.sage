# collections: Stack, Queue and Counter.
class Stack:
    define init():
        self.items = []
    define push(x):
        self.items.add(x)
    define pop():
        if len(self.items) == 0:
            raise IndexError("pop from an empty Stack")
        return self.items.pop()
    define peek():
        if len(self.items) == 0:
            raise IndexError("peek at an empty Stack")
        return self.items[len(self.items) - 1]
    define __len__():
        return len(self.items)
    define __iter__():
        return reversed(self.items)
    define to_text():
        return f"Stack({self.items})"

class Queue:
    define init():
        self.items = []
        self.head = 0
    define push(x):
        self.items.add(x)
    define pop():
        if self.head >= len(self.items):
            raise IndexError("pop from an empty Queue")
        let x = self.items[self.head]
        self.head += 1
        if self.head > 64 and self.head * 2 > len(self.items):
            self.items = self.items[self.head:]
            self.head = 0
        return x
    define __len__():
        return len(self.items) - self.head
    define __iter__():
        return self.items[self.head:]
    define to_text():
        return f"Queue({self.items[self.head:]})"

class Counter:
    define init(items=[]):
        self.counts = {}
        for x in items:
            self.add(x)
    define add(x, n=1):
        self.counts[x] = self.counts.get(x, 0) + n
    define get(x):
        return self.counts.get(x, 0)
    define most_common(n=3):
        let pairs = sorted(items(self.counts), key=lambda p: -p[1])
        return pairs[0:n]
    define __getitem__(x):
        return self.counts.get(x, 0)
    define __len__():
        return len(self.counts)
    define to_text():
        return f"Counter({self.counts})"
