# log: leveled messages with a timestamp.   log.info("started")  log.set_level("debug")
import time

let LEVELS = {"debug": 10, "info": 20, "warn": 30, "error": 40}
let state = {"level": 20, "stamp": true}

define set_level(name):
    if name not in LEVELS:
        raise ValueError(f"unknown log level '{name}' (use debug, info, warn or error)")
    state["level"] = LEVELS[name]

define show_time(on):
    state["stamp"] = on

define emit(name, parts):
    if LEVELS[name] < state["level"]:
        return nothing
    let line = ""
    for p in parts:
        line = line + str(p) + " "
    line = line.strip()
    if state["stamp"]:
        say f"{time.format()} [{name.upper()}] {line}"
    else:
        say f"[{name.upper()}] {line}"

define debug(*parts):
    emit("debug", parts)
define info(*parts):
    emit("info", parts)
define warn(*parts):
    emit("warn", parts)
define error(*parts):
    emit("error", parts)
