# testing: assertions and the engine behind `sage test`.
import os

define assert_equal(actual, expected, message=""):
    if actual != expected:
        let extra = ""
        if message != "":
            extra = " (" + message + ")"
        raise AssertionError(f"expected {expected} but got {actual}{extra}")

define assert_true(value, message="expected a true value"):
    if not value:
        raise AssertionError(message)

define assert_false(value, message="expected a false value"):
    if value:
        raise AssertionError(message)

# Run fn and require that it raises. Returns the error that was caught.
define assert_raises(fn, kind=Error):
    try:
        fn()
    catch kind as e:
        return e
    raise AssertionError("expected an error, but none was raised")

define run_module(name):
    let module = import_module(name)
    let failed = 0
    let passed = 0
    for fname in sorted(dir(module)):
        if fname.starts_with("test_"):
            try:
                getattr(module, fname)()
                say f"  ok    {fname}"
                passed += 1
            catch e:
                say f"  FAIL  {fname} - {e}"
                failed += 1
    return (passed, failed)

define find_tests(path):
    let found = []
    if os.is_dir(path):
        for entry in os.listdir(path):
            let full = os.join(path, entry)
            if os.is_dir(full):
                if not entry.starts_with("."):
                    found.extend(find_tests(full))
            elif entry.ends_with(".sage") and (entry.starts_with("test_") or entry.ends_with("_test.sage")):
                found.add(full)
    elif os.exists(path):
        found.add(path)
    else:
        raise IOError(f"no such file or folder: {path}")
    return found

define main():
    let targets = args
    if len(targets) == 0:
        targets = ["."]
    let files = []
    for t in targets:
        files.extend(find_tests(t))
    let total_pass = 0
    let total_fail = 0
    for f in files:
        say f
        _add_path(os.dirname(f))
        let name = os.basename(f)
        name = name.replace(".sage", "")
        let result = run_module(name)
        total_pass += result[0]
        total_fail += result[1]
    say f"{total_pass} passed, {total_fail} failed in {len(files)} file(s)"
    if total_fail > 0:
        exit(1)
