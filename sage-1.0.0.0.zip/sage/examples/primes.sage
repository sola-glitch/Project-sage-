# Sieve of Eratosthenes
define primes_up_to(n):
    let is_prime = [true] * (n + 1)
    is_prime[0] = false
    is_prime[1] = false
    for i in range(2, n + 1):
        if is_prime[i]:
            for j in range(i * i, n + 1, i):
                is_prime[j] = false
    return [i for i in range(n + 1) if is_prime[i]]

let p = primes_up_to(60)
say p
say f"{len(p)} primes, sum {sum(p)}"
