# A tour of Sage: one language, three styles.

# --- procedural ---------------------------------------------------
define fizzbuzz(limit):
    for i in range(1, limit + 1):
        if i % 15 == 0:
            say "FizzBuzz"
        else if i % 3 == 0:
            say "Fizz"
        else if i % 5 == 0:
            say "Buzz"
        else:
            say i
fizzbuzz(15)

# --- object-oriented ----------------------------------------------
class Account:
    define init(owner, balance = 0):
        self.owner = owner
        self.balance = balance
        self.history = []

    define deposit(amount):
        if amount <= 0:
            raise "deposit must be positive"
        self.balance += amount
        self.history.add(f"+{amount}")
        return self

    define withdraw(amount):
        if amount > self.balance:
            raise f"{self.owner} has only {self.balance}"
        self.balance -= amount
        self.history.add(f"-{amount}")
        return self

    define to_text():
        return f"{self.owner}: {self.balance}"

class Savings extends Account:
    define init(owner, rate):
        super.init(owner)
        self.rate = rate

    define add_interest():
        self.deposit(self.balance * self.rate)

let acct = Savings("Ada", 0.1)
acct.deposit(100).withdraw(30)
acct.add_interest()
say acct, acct.history
try:
    acct.withdraw(1000)
catch problem:
    say "Refused:", problem

# --- functional ---------------------------------------------------
let words = "the quick brown fox jumps over the lazy dog".split()
let lengths = words |> map(lambda w: len(w))
say lengths
say words |> filter(lambda w: len(w) > 3) |> map(lambda w: w.title())
say reduce(lengths, lambda a, b: a + b)
say sorted(words, lambda w: -len(w))[:3]

define counter_from(start):
    let n = start
    define next():
        nonlocal n
        n += 1
        return n
    return next
let tick = counter_from(10)
say tick(), tick(), tick()
