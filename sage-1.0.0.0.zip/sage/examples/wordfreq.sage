# Count word frequencies and show the most common ones.
let text = "the cat and the hat and the bat sat on the mat"
let counts = {}
for w in text.split():
    counts[w] = counts.get(w, 0) + 1

let ranked = sorted(items(counts), lambda pair: -pair[1])
for pair in ranked[:3]:
    say f"{pair[0]}: {'#' * pair[1]} ({pair[1]})"
