;;; sage-mode.el --- Major mode for the Sage programming language  -*- lexical-binding: t; -*-
;; Install: put this file in ~/.emacs.d/lisp/ and add to your init file:
;;   (add-to-list 'load-path "~/.emacs.d/lisp")
;;   (require 'sage-mode)
;; C-c C-c runs the current file with the `sage` program.

(defvar sage-keywords
  '("let" "if" "else" "elif" "while" "for" "in" "repeat" "times" "define" "return" "break" "continue"
    "pass" "class" "extends" "try" "catch" "finally" "raise" "assert" "use" "import" "from" "as" "with"
    "global" "nonlocal" "lambda" "and" "or" "not" "is" "say" "super"))
(defvar sage-constants '("true" "false" "nothing" "self"))
(defvar sage-errors
  '("Error" "ValueError" "TypeError" "KeyError" "IndexError" "IOError" "ImportError" "RuntimeError"
    "ZeroDivisionError" "AssertionError" "NotImplementedError"))

(defvar sage-font-lock-keywords
  `((,(regexp-opt sage-keywords 'symbols) . font-lock-keyword-face)
    (,(regexp-opt sage-constants 'symbols) . font-lock-constant-face)
    (,(regexp-opt sage-errors 'symbols) . font-lock-type-face)
    ("\\_<define\\s-+\\([A-Za-z_][A-Za-z0-9_]*\\)" 1 font-lock-function-name-face)
    ("\\_<class\\s-+\\([A-Za-z_][A-Za-z0-9_]*\\)" 1 font-lock-type-face)
    ("^\\s-*\\(@[A-Za-z_][A-Za-z0-9_.]*\\)" 1 font-lock-preprocessor-face)))

(defvar sage-mode-syntax-table
  (let ((st (make-syntax-table)))
    (modify-syntax-entry ?# "<" st)
    (modify-syntax-entry ?\n ">" st)
    (modify-syntax-entry ?\" "\"" st)
    (modify-syntax-entry ?' "\"" st)
    (modify-syntax-entry ?_ "_" st)
    st))

(defun sage-run-file ()
  "Run the current file with the sage program."
  (interactive)
  (save-buffer)
  (compile (concat "sage " (shell-quote-argument buffer-file-name))))

(define-derived-mode sage-mode prog-mode "Sage"
  "Major mode for editing Sage programs."
  :syntax-table sage-mode-syntax-table
  (setq-local font-lock-defaults '(sage-font-lock-keywords))
  (setq-local comment-start "# ")
  (setq-local comment-start-skip "#+\\s-*")
  (setq-local indent-tabs-mode nil)
  (setq-local tab-width 4)
  (setq-local standard-indent 4)
  (local-set-key (kbd "C-c C-c") #'sage-run-file))

(add-to-list 'auto-mode-alist '("\\.sage\\'" . sage-mode))
(provide 'sage-mode)
;;; sage-mode.el ends here
