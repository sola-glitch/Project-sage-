" Vim syntax file for Sage
if exists("b:current_syntax") | finish | endif

syn keyword sageKeyword let if else elif while for in repeat times define return break continue pass
syn keyword sageKeyword class try catch finally raise assert use import from as with global nonlocal lambda
syn keyword sageKeyword extends give back
syn keyword sageOperator and or not is
syn keyword sageBool true false nothing
syn keyword sageSelf self super
syn keyword sageSay say
syn keyword sageBuiltin len str num int bool list tuple set type isinstance hasattr getattr dir range print ask
syn keyword sageBuiltin abs min max sum round floor ceil sqrt pow sorted reversed map filter reduce each any all
syn keyword sageBuiltin zip enumerate keys values items fixed chr ord read_file write_file append_file file_exists open
syn keyword sageBuiltin exit gc import_module
syn keyword sageError Error ValueError TypeError KeyError IndexError IOError ImportError RuntimeError
syn keyword sageError ZeroDivisionError AssertionError NotImplementedError
syn match   sageNumber "\<\d\+\(\.\d\+\)\?\([eE][+-]\?\d\+\)\?\>"
syn match   sageDefine "\(\<define\s\+\)\@<=\h\w*"
syn match   sageClass  "\(\<class\s\+\)\@<=\h\w*"
syn match   sageDecorator "^\s*@\h[A-Za-z0-9_.]*"
syn match   sageOp "|>\|\*\*\|//\|==\|!=\|<=\|>=\|[-+*/%<>=|&]"
syn region  sageString start=+"+ skip=+\\.+ end=+"+ contains=sageEscape
syn region  sageString start=+'+ skip=+\\.+ end=+'+ contains=sageEscape
syn region  sageString start=+"""+ end=+"""+ contains=sageEscape
syn region  sageFString start=+\<f"+ skip=+\\.+ end=+"+ contains=sageEscape,sageInterp
syn region  sageFString start=+\<f'+ skip=+\\.+ end=+'+ contains=sageEscape,sageInterp
syn match   sageEscape "\\." contained
syn region  sageInterp matchgroup=sageDelim start="{" end="}" contained contains=sageNumber,sageBool,sageBuiltin
syn match   sageComment "#.*$"

hi def link sageKeyword Keyword
hi def link sageOperator Operator
hi def link sageOp Operator
hi def link sageBool Constant
hi def link sageSelf Identifier
hi def link sageSay Statement
hi def link sageBuiltin Function
hi def link sageError Type
hi def link sageNumber Number
hi def link sageDefine Function
hi def link sageClass Type
hi def link sageDecorator PreProc
hi def link sageString String
hi def link sageFString String
hi def link sageEscape SpecialChar
hi def link sageDelim Delimiter
hi def link sageComment Comment
let b:current_syntax = "sage"
