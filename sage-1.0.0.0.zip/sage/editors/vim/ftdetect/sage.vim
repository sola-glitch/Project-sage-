autocmd BufNewFile,BufRead *.sage setfiletype sage
