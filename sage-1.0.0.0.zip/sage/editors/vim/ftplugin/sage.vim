" Sage: 4 spaces, no tabs, '#' comments. Press F5 to run the current file.
setlocal expandtab shiftwidth=4 softtabstop=4 tabstop=4
setlocal commentstring=#\ %s
setlocal autoindent
setlocal indentkeys+=0=elif,0=else,0=catch,0=finally
nnoremap <buffer> <F5> :w<CR>:!sage %<CR>
