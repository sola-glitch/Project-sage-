#!/usr/bin/env python3
"""Build docs/TUTORIAL.md from TUTORIAL.src.md: run every ```sage block with the real
interpreter and put its output in the place of each <!--out--> marker.
Usage: python3 docs/build_tutorial.py   (run `make` first)"""
import os, re, subprocess, sys, tempfile
here = os.path.dirname(os.path.abspath(__file__))
sage = os.path.join(here, "..", "sage")
src = open(os.path.join(here, "TUTORIAL.src.md"), encoding="utf-8").read()

pattern = re.compile(r"```sage\n(.*?)```\n<!--out-->", re.S)
problems = []

def run(m):
    code = m.group(1)
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "example.sage")
        open(path, "w", encoding="utf-8").write(code)
        r = subprocess.run([sage, path], cwd=d, stdin=subprocess.DEVNULL,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, timeout=20)
    out = r.stdout.rstrip("\n")
    out = out.replace(path, "example.sage")
    if "Error on line" in out and "# expect-error" not in code and "say 10 / 0\nsay \"never" not in code:
        problems.append((code, out))
    return "```sage\n" + code + "```\n\n<sub>Output</sub>\n```text\n" + out + "\n```"

result = pattern.sub(run, src)
open(os.path.join(here, "TUTORIAL.md"), "w", encoding="utf-8").write(result)
print("blocks run:", len(pattern.findall(src)))
for code, out in problems:
    print("---- UNEXPECTED ERROR in block:\n" + code + "\n" + out)
sys.exit(1 if problems else 0)
